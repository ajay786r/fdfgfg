package com.Gateway.GlobalParameters;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelData {
		XSSFWorkbook wb;
		XSSFSheet sh1;	
	public void GetExcelData() throws Exception
	{
		
			
		//Read data from excel using POI
		
		File f = new File ("C:\\Users\\rchanda\\Desktop\\TestData\\TestData1.xlsx");
		FileInputStream fis = new FileInputStream(f);
		wb = new XSSFWorkbook (fis);
		sh1 = wb.getSheet("Sheet1");
		//System.out.println(sh1);
		int rowcount = sh1.getLastRowNum() - sh1.getFirstRowNum();
		System.out.println(rowcount);
		int columnCount = sh1.getRow(0).getLastCellNum();
		System.out.println(columnCount);
		String url = sh1.getRow(1).getCell(0).getStringCellValue();	
		System.out.println(url);
		String Brow = sh1.getRow(1).getCell(2).getStringCellValue();
		System.out.println(Brow);
		String uName = sh1.getRow(1).getCell(3).getRawValue();
		System.out.println(uName);
		String Pwd = sh1.getRow(1).getCell(4).getStringCellValue();
		System.out.println(Pwd);
	}

}
