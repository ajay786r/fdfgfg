package com.Gateway.GlobalParameters;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

public class GlobalParameters {

	public static void main(String[] args) {
		
		File src = new File("./Configuration/ConfigurationPage");
		
		try {
			FileInputStream fis = new FileInputStream(src);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Properties prop = new Properties();
		
		prop.load("./ConfigurationPage");
		
	 
 
	}

}
