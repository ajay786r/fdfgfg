/**
 * 
 */
package com.Gatewaytr.Testcases;

import org.testng.annotations.Test;

import com.Gatewaytr.pages.LoginPage;

/**
 * @author rchanda
 *
 */
public class VerifyLogin {

	@Test
	public void test1()
	{
		LoginPage lp = new LoginPage();
		lp.Login();
		
	}
	
}
