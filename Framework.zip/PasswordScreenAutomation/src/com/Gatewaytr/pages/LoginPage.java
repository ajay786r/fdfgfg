package com.Gatewaytr.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LoginPage {
	WebDriver driver;
	By Username = By.name("userID");
	By Password = By.name("password");
	By LoginButton = By.xpath(".//*[@id='login']");	
	public void Login() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\WealthAutomation\\DriverWorkspace\\SeleniumKeywordDriver\\lib\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://gatewaytr.bmonesbittburns.ca/");
		//driver.manage().window().maximize();
		driver.findElement(Username).sendKeys("33609746");
		driver.findElement(Password).sendKeys("15779365");
		driver.findElement(LoginButton).click();
		
	}
	
}
