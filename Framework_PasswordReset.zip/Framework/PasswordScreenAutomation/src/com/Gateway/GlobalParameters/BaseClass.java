package com.Gateway.GlobalParameters;

import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class BaseClass {
	
	public static WebDriver driver=null;

	
	public static String filePath="C:\\GatewayPasswordReset\\TestData\\ExcelSample.xlsx";

	public static String sheetName="English";
	
	public static String GatewayTrainingURL="https://gatewaytr.bmonesbittburns.ca/client/";
	
	public static String fileName="C:\\Users\\craja01\\Downloads\\Framework\\PasswordScreenAutomation\\Configuration\\ConfigurationPage.property";
		
	public static FetchingOR obj = null;
	 public static String testBrowserName=null;
	 public static String testLanguage=null;
	
	
	

}
