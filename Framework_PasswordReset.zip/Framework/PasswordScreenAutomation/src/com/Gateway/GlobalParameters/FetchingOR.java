package com.Gateway.GlobalParameters;



import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

public class FetchingOR {
	public String RepositoryFile;
	
	Properties prop;
	
	public FetchingOR(String fileName) throws Exception
	{
		this.RepositoryFile = fileName;
		//File src = new File("C:\\Users\\craja01\\Downloads\\Framework\\PasswordScreenAutomation\\Configuration\\ConfigurationPage.property");
		
		FileInputStream fis = new FileInputStream(fileName);
		
		prop = new Properties();
		
		prop.load(fis);
		
	}
	
	public String getbrowser()
	{
	
		return prop.getProperty("CHROME");
	}

	
	public String geturl()
	{
		
		return prop.getProperty("URL");
	}
	
	public String getUserName()
	{
	
		return prop.getProperty("User_Id");
	}
	public String getPassword()
	{
		
		return prop.getProperty("Password");
	}
	public String getLoginButton()
	{
		
		return prop.getProperty("Sign_In");
	}

} 