package com.Gatewaytr.ExcelFile;

import java.io.File;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class ExcelJXL {
	public Workbook Workb;
	public String password;
	static String ExecutedTestCasesSheet;
	static boolean status;
	static Workbook wbook;
    static WritableWorkbook wwbCopy;
    //static String ExecutedTestCasesSheet;
    static WritableSheet shSheet;
	public static void outPut(int Sheet, int columnNumber, int rowNumber, String Data) 
	{
		try{
    	    wbook = Workbook.getWorkbook(new File("C:\\Users\\craja01\\Desktop\\DriveSheetSample.xls"));
    	    wwbCopy = Workbook.createWorkbook(new File("C:\\Users\\craja01\\Desktop\\DriveSheetSample.xls"), wbook);
    	    //shSheet = wwbCopy.getSheet(0);
    	    }
    	    catch(Exception e)
    	    {
    	        e.printStackTrace();
    	    }
    	WritableSheet wshTemp = wwbCopy.getSheet(Sheet);
        Label labTemp = new Label(columnNumber, rowNumber, Data);
                  
       try {
            wshTemp.addCell(labTemp);
            } 
            catch (Exception e) 
            {
                e.printStackTrace();
            }
       try {
           // Closing the writable work book
           wwbCopy.write();
           wwbCopy.close();

           // Closing the original work book
           wbook.close();
       } catch (Exception e)

       {
           e.printStackTrace();
       }
    }

}
