/**
 * 
 */
package com.Gatewaytr.Testcases;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.Gateway.GlobalParameters.BaseClass;
import com.Gateway.GlobalParameters.FetchingOR;


import com.Gatewaytr.ExcelFile.ExcelJXL;
import com.Gatewaytr.ExcelFile.ReadExcelFile;
import com.Gatewaytr.pages.GeneralFunctions;
import com.Gatewaytr.pages.LoginPage;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

/**
 * @author craja01
 *
 */
public class ExtentReport extends BaseClass{
ExtentReports extent;
	
	 ExtentTest logger;
	
	public FetchingOR obj=null;
	public String fileName="C:\\Users\\craja01\\Downloads\\Framework\\PasswordScreenAutomation\\Configuration\\ConfigurationPage.property";
	
	int rowNumber;
	@DataProvider(name="DriverSheet")
	public Object[][] driverSheetData() {
		Object[][] arrayObject = getExcelData("C:\\GatewayPasswordReset\\DriverSheet\\DriveSheetSample.xls","Sheet1");
		return arrayObject;
	}

	/**
	 * @param File Name
	 * @param Sheet Name
	 * @return
	 */
	public String[][] getExcelData(String fileName, String sheetName) {
		String[][] arrayExcelData = null;
		try {
			FileInputStream fs = new FileInputStream(fileName);
			Workbook wb = Workbook.getWorkbook(fs);
			Sheet sh = wb.getSheet(sheetName);

			int totalNoOfCols = sh.getColumns();
			int totalNoOfRows = sh.getRows();
			
			arrayExcelData = new String[totalNoOfRows-1][totalNoOfCols];
			
			for (int i= 1 ; i < totalNoOfRows; i++) 
			{
				
				for (int j=0; j < totalNoOfCols; j++) {
					arrayExcelData[i-1][j] = sh.getCell(j, i).getContents();
					
				}

			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			e.printStackTrace();
		} catch (BiffException e) {
			e.printStackTrace();
		}
		return arrayExcelData;
	}	

 
 @BeforeSuite
public void beforeSuite() throws Exception
{
	 DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
	 Date date = new Date();
	 System.out.println(dateFormat.format(date)); 
	
	extent = new ExtentReports("C:\\GatewayPasswordReset\\TestReports\\AutomationReport"+dateFormat.format(date)+".html", true);
    extent.loadConfig(new File("C:\\GatewayPasswordReset\\extent-config.xml"));
    ReadExcelFile.setExcelFile(filePath, sheetName);
   
    
	LoginPage.LaunchBrowser();
  
}

@BeforeTest
public void beforeTest() throws Exception
{
	obj = new FetchingOR(fileName);
	
}
	
	@Test(dataProvider="DriverSheet")
	public void test1(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC002")&&Execution.equalsIgnoreCase("Y"))
		{
			LoginPage.LaunchURL(obj.geturl());
		//System.out.println("Inside Login Test:"+obj.geturl());
		logger=extent.startTest("Test_Name1");
		System.out.println("test script:"+ReadExcelFile.getTestData("TC002","PasswordReset2","p_Password_Eng"));
		LoginPage.Login(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
		logger.log(LogStatus.PASS, "Logged in sucessfully");
		//String TestDataContents=ReadExcelFile.getTestData("TC002","PasswordReset2","p_ErrorMsg_Eng");
		//System.out.println("***************Test Data Contents***************:"+TestDataContents);
		logger.log(LogStatus.PASS, "Logged second test case sucessfully");
	
		ExcelJXL.outPut(0, 5, rowNumber, "PASS");
		extent.endTest(logger);
	
		
		}
	}
	
	@Test(dataProvider="DriverSheet")
	public void test2(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC001")&&Execution.equalsIgnoreCase("Y"))
		{
			LoginPage.LaunchURL("http://www.google.com");
		//System.out.println("Inside Login Test:"+obj.geturl());
		logger=extent.startTest("Test_Name2");
		System.out.println("test script:"+ReadExcelFile.getTestData("TC001","PasswordReset2","p_Password_Eng"));
		LoginPage.Login(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
		logger.log(LogStatus.PASS, "Logged in sucessfully");
		//String TestDataContents=ReadExcelFile.getTestData("TC002","PasswordReset2","p_ErrorMsg_Eng");
		//System.out.println("***************Test Data Contents***************:"+TestDataContents);
		logger.log(LogStatus.PASS, "Logged second test case sucessfully");
	
		ExcelJXL.outPut(0, 5, rowNumber, "PASS");
		extent.endTest(logger);
	
		
		}
	}
	
	
	
}
