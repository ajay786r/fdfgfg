package com.Gatewaytr.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.Gateway.GlobalParameters.BaseClass;
import com.Gateway.GlobalParameters.FetchingOR;

public class LoginPage extends BaseClass{

	
	
	
	public static void LaunchBrowser() 
	{
		try{
			
			System.setProperty("webdriver.chrome.driver", "C:\\WealthAutomation\\DriverWorkspace\\SeleniumKeywordDriver\\lib\\chromedriver.exe");
			driver = new ChromeDriver();
			
			System.out.println("Launched Browser:Chrome");
		
			
		}
			
			catch(Exception e)
			{
				System.out.println("Exceptuion caught in LaunchBrowser"+e.getMessage());
			}
			
		}

	public static void LaunchURL(String URL) {
		
		driver.get(URL);
		
		System.out.println("Launched URL");
		//driver.manage().window().maximize();
		
	}

		

	public static void Login(String userName,String password) {
	try{
		
		obj = new FetchingOR(fileName);
		driver.findElement(By.xpath(obj.getUserName())).sendKeys(userName);
			driver.findElement(By.xpath(obj.getPassword())).sendKeys(password);
			driver.findElement(By.xpath(obj.getLoginButton())).click();
			System.out.println("Login Successful");	
		}
	
	catch(Exception e)
	{
		System.out.println("Exception caught in Login Function:"+ e.getMessage());
	}
	}
	
}
