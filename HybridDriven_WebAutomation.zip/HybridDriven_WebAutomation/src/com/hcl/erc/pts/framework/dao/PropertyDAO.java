package com.hcl.erc.pts.framework.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.hcl.erc.pts.framework.interfaces.IPropertyConfigurer;
import static com.hcl.erc.pts.framework.test.testdriver.TestDriver.CONFIG;

public class PropertyDAO implements IPropertyConfigurer {

	public Properties OR = null;

	public FileInputStream fisOR = null;

	public PropertyDAO() {
		try {
			fisOR = new FileInputStream(System.getProperty("user.dir")+CONFIG.getProperty("objectRepositoryPath"));
			OR = new Properties();
			OR.load(fisOR);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException ie) {
			ie.printStackTrace();
		}

	}

	@Override
	public String getObjectData(String key) {
		return OR.getProperty(key);
	}
}
