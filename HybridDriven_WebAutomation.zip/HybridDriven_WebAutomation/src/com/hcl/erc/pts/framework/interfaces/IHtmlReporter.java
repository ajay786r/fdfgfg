package com.hcl.erc.pts.framework.interfaces;

public interface IHtmlReporter {

	public void GenerateTestcaseReport(String testcaseName, String result, String totalTime);

	public void generateHeaderReport();

	public void generateFooterReport();
	
	public void totalTestCaseTime(String totalTime);
}
