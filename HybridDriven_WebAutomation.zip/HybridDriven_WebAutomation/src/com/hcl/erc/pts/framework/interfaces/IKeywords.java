package com.hcl.erc.pts.framework.interfaces;

public interface IKeywords {
	public String openBrowser(String URL, String browser);

	public String mouseHover(String object, String data);

	public String enterText(String object, String data);

	public String navigate(String object, String data);

	public void DymamicWait();

	public String click(String object, String data);

	public String waitForPageload(String object, String data);

	public String closeBrowser(String object, String data);

	public String verifyAllListItems(String object, String data);

	public boolean waitUntilExists(String object, String mode);

	public String verifyText(String object, String data);

	public String selectList(String object, String data);

	public String selectListItem(String object, String data);

	public void captureScreenshot(String filename,
			String keyword_execution_result);

	public String scrollingToBottomofAPage(String object, String data);

	public String scrollingToElementofAPage(String object, String data);

	public String scrollingByCoordinatesofAPage(String object, String data);

	public String switchToWindowPopup(String object, String data);

	public String verifyTitleText(String object, String data);

	public String verifyGetAttributeText(String object, String data);
}
