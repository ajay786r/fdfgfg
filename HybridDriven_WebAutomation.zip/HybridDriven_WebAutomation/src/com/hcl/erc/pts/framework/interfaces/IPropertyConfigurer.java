package com.hcl.erc.pts.framework.interfaces;

public interface IPropertyConfigurer {

	/** To get the data from properties file */
	
	public String getObjectData(String key);
	
	
}
