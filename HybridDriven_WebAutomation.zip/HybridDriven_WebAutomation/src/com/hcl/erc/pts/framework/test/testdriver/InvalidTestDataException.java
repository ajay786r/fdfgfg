package com.hcl.erc.pts.framework.test.testdriver;
/**
 * The class is Invalid test data exception
 *
 */
@SuppressWarnings("serial")
public class InvalidTestDataException extends Exception {
	String message = "****Configure valid TestData | Current TestData entry keys must be match with previous TestData entry keys****";
	public String toString(){
		return message;
	}
}
