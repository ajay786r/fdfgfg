package com.hcl.erc.pts.framework.test.testdriver;

import static com.hcl.erc.pts.framework.test.testdriver.TestDriver.APP_LOGS;

import java.util.List;
import java.util.Random;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class KeyActions {
	
	WebDriver driver;
	
	/*************************************************************************.
	# 3
	**************************************************************************
	'* Keyword Name         : enterText
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : enter the data into text field
	'* Input Parameters     : object , data
	'* Output Parameters    : PASS or FAIL
	'* Usage				: enterText(object, data)
		 					object:=id or className or name or CSS or xpath of the object 
		 					data  :=data is taken from xml file 	
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/
	
	public String enterTextById(String object, String data) {
		try {
			APP_LOGS.debug("Writing in text box by id"+data);
			WebElement element = driver.findElement(By.id(object));
			element.clear();
			element.sendKeys(data);
		} catch (Exception e) {
			APP_LOGS.debug("Unable to writing in text box by id");
			return "FAIL <br>" + "Unable to write in the Input box "
					+ e.getMessage().substring(0, 40) + "</br>";
		}
		return "PASS Entered input " + data + " in " + object
				+ "</br>";
	}

	public String enterTextByName(String object, String data) {
		try {
			APP_LOGS.debug("Writing in text box by name "+data);
			WebElement element = driver.findElement(By.name(object));
			element.clear();
			element.sendKeys(data);
		} catch (Exception e) {
			APP_LOGS.debug("Unable to writing in text box by name");
			return "FAIL <br>" + "Unable to write in the Input box "
					+ e.getMessage().substring(0, 40) + "</br>";
		}
		return "PASS <br>" + "Entered input " + data + " in " + object
				+ "</br>";
	}

	public String enterTextByClassName(String object, String data) {
		try {
			APP_LOGS.debug("Writing in text box by classname "+data);
			WebElement element = driver.findElement(By.className(object));
			element.clear();
			element.sendKeys(data);
		} catch (Exception e) {
			APP_LOGS.debug("Unable to writing in text box by class name");
			return "FAIL <br>" + "Unable to write in the Input box "
					+ e.getMessage().substring(0, 40) + "</br>";
		}
		return "PASS <br>" + "Entered input " + data + " in " + object
				+ "</br>";
	}

	public String enterTextByCSS(String object, String data) {
		try {
			APP_LOGS.debug("Writing in text box by CSS "+data);
			WebElement element = driver.findElement(By.cssSelector(object));
			element.clear();
			element.sendKeys(data);
		} catch (Exception e) {
			APP_LOGS.debug("Unable to writing in text box by CSS");
			return "FAIL <br>" + "Unable to write in the Input box "
					+ e.getMessage().substring(0, 40) + "</br>";
		}
		return "PASS <br>" + "Entered input " + data + " in " + object
				+ "</br>";
	}

	public String enterTextByXpath(String object, String data) {
		try {
			APP_LOGS.debug("Writing in text box by xpath "+data);
			WebElement element = driver.findElement(By.xpath(object));
			element.clear();
			element.sendKeys(data);
		} catch (Exception e) {
			APP_LOGS.debug("Unable to writing in text box by xpath");
			return "FAIL <br>" + "Unable to write in the Input box "
					+ e.getMessage().substring(0, 40) + "</br>";
		}
		return "PASS <br>" + "Entered input " + data + " in " + object
				+ "</br>";
	}

	
	
	/*************************************************************************.
	# 12
	**************************************************************************
	'* Keyword Name         : select
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Find value in list
	'* Input Parameters     : object and data
	'* Output Parameters    : PASS or FAIL
	'* Usage				: select(object, data)
			 				object:=id or className or name or CSS or xpath of the object
			 				data  :=Data will be taken from the Xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/
	
	public String selectById(String object, String data) {
		APP_LOGS.debug("Select a dropdown option by id " + data);
		try {
			Select select = new Select(driver.findElement(By.id(object)));
			select.selectByVisibleText(data);
		} catch (Exception e) {
			APP_LOGS.debug("Unable to select a dropdown option by id "+data);
			return "FAIL <br>" + "Unable to select the " + data + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 40);
		}
		return "PASS <br>" + "Selected " + data + " from the " + object
				+ " dropdown list" + "</br>";
	}

	public String selectByName(String object, String data) {
		APP_LOGS.debug("Select a dropdown option by name " + data);
		try {
			Select select = new Select(driver.findElement(By.name(object)));
			select.selectByVisibleText(data);
		} catch (Exception e) {
			APP_LOGS.debug("Unable to select a dropdown option by name "+data);
			return "FAIL <br>" + "Unable to select the " + data + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 40);
		}
		return "PASS <br>" + "Selected " + data + " from the " + object
				+ " dropdown list" + "</br>";
	}

	public String selectByClassName(String object, String data) {
		APP_LOGS.debug("Select a dropdown option by className " + data);
		try {
			Select select = new Select(driver.findElement(By.className(object)));
			select.selectByVisibleText(data);
		} catch (Exception e) {
			APP_LOGS.debug("Unable to select a dropdown option by classname "+data);
			return "FAIL <br>" + "Unable to select the " + data + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 40);
		}
		return "PASS <br>" + "Selected " + data + " from the " + object
				+ " dropdown list" + "</br>";
	}

	public String selectByTagName(String object, String data) {
		APP_LOGS.debug("Select a dropdown option by tagName " + data);
		try {
			Select select = new Select(driver.findElement(By.tagName(object)));
			select.selectByVisibleText(data);
		} catch (Exception e) {
			APP_LOGS.debug("Unable to select a dropdown option by tagName "+data);
			return "FAIL <br>" + "Unable to select the " + data + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 40);
		}
		return "PASS <br>" + "Selected " + data + " from the " + object
				+ " dropdown list" + "</br>";
	}

	public String selectByCSS(String object, String data) {
		APP_LOGS.debug("Select a dropdown option by CSS " + data);
		try {
			Select select = new Select(driver.findElement(By.cssSelector(object)));
			select.selectByVisibleText(data);
		} catch (Exception e) {
			APP_LOGS.debug("Unable to select a dropdown option by CSS "+data);
			return "FAIL <br>" + "Unable to select the " + data + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 40);
		}
		return "PASS <br>" + "Selected " + data + " from the " + object
				+ " dropdown list" + "</br>";
	}

	public String selectByXpath(String object, String data) {
		APP_LOGS.debug("Select a dropdown option by id " + data);
		try {
			Select select = new Select(driver.findElement(By.xpath(object)));
			select.selectByVisibleText(data);
		} catch (Exception e) {
			APP_LOGS.debug("Unable to select a dropdown option by xpath "+data);
			return "FAIL <br>" + "Unable to select the " + data + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 40);
		}
		return "PASS <br>" + "Selected " + data + " from the " + object
				+ " dropdown list" + "</br>";
	}

	/*************************************************************************.
	# 1
	**************************************************************************
	'* Keyword Name         : scrollingToElementofAPage
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Scrolling to element of a page
	'* Input Parameters     : object and data
	'* Output Parameters    : NA
	'* Usage				: scrollingToElementofAPage(object, data)
							object:= object is required to identifying an element 
							data  := not required
	'* Revision History     :
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'* Comment  :
	**************************************************************************/

	public String scrollById(String object, String data) {
		APP_LOGS.debug("Scrolling to a page by id " + object);
		try {
			WebElement element = driver.findElement(By.id(object));
			if (element != null) {
				((JavascriptExecutor) driver).executeScript(
						"arguments[0].scrollIntoView();", element);
			}
			return "PASS Scrolling to a page successfully by id "
					+ object;
		} catch (Exception e) {
			APP_LOGS.debug("Unable to scrolling to a page by id " + object);
			e.printStackTrace();
			return "FAIL <br>" + "Unable to scrolling to element of a page by id "
					+ object+"</br>";
		}
	}

	public String scrollByName(String object, String data) {
		APP_LOGS.debug("Scrolling to a page by name "+object);
		try {
			WebElement element = driver.findElement(By.name(object));
			if (element != null) {
				((JavascriptExecutor) driver).executeScript(
						"arguments[0].scrollIntoView();", element);
			}
			return "PASS Scrolling to element of a page successfully by name "
					+ object;
		} catch (Exception e) {
			APP_LOGS.debug("Unable to scrolling of a page by name " + object);
			e.printStackTrace();
			return "FAIL </br>"+"Unable to scrolling to element of a page by name </br>"
					+ object+"</br>";
		}
	}

	public String scrollByClassName(String object, String data) {
		APP_LOGS.debug("Scrolling to a page by className "+object);
		try {
			WebElement element = driver.findElement(By.className(object));
			if (element != null) {
				((JavascriptExecutor) driver).executeScript(
						"arguments[0].scrollIntoView();", element);
			}
			return "PASS Scrolling to element of a page successfully by className "
					+ object;
		} catch (Exception e) {
			APP_LOGS.debug("Unable to scrolling of a page by className " + object);
			e.printStackTrace();
			return "FAIL </br>"+"Unable to scrolling to element of a page by className "
					+ object+"</br>";
		}
	}

	public String scrollByTagName(String object, String data) {
		APP_LOGS.debug("Scrolling to a page by tagName "+object);
		try {
			WebElement element = driver.findElement(By.tagName(object));
			if (element != null) {
				((JavascriptExecutor) driver).executeScript(
						"arguments[0].scrollIntoView();", element);
			}
			return "PASS Scrolling to element of a page successfully by tagName "
					+ object;
		} catch (Exception e) {
			APP_LOGS.debug("Unable to scrolling of a page by tagName " + object);
			e.printStackTrace();
			return "FAIL <br>"+"Unable to scrolling to element of a page by tagName "
					+ object+"</br>";
		}
	}

	public String scrollByLinkText(String object, String data) {
		APP_LOGS.debug("Scrolling to a page by linkText "+object);
		try {
			WebElement element = driver.findElement(By.linkText(object));
			if (element != null) {
				((JavascriptExecutor) driver).executeScript(
						"arguments[0].scrollIntoView();", element);
			}
			return "PASS Scrolling to element of a page successfully by linkText "
					+ object;
		} catch (Exception e) {
			APP_LOGS.debug("Unable to scrolling of a page by linkText " + object);
			e.printStackTrace();
			return "FAIL <br>"+"Unable to scrolling to element of a page by linkText "
					+ object+"</br>";
		}
	}

	public String scrollByPartialLinkText(String object, String data) {
		APP_LOGS.debug("Scrolling to a page by partialLinkText "+object);
		try {
			WebElement element = driver.findElement(By.partialLinkText(object));
			if (element != null) {
				((JavascriptExecutor) driver).executeScript(
						"arguments[0].scrollIntoView();", element);
			}
			return "PASS Scrolling to element of a page successfully by partialLinkText "
					+ object;
		} catch (Exception e) {
			APP_LOGS.debug("Unable to scrolling of a page by partialLinkText " + object);
			e.printStackTrace();
			return "FAIL <br>"+"Unable to scrolling to element of a page by partialLinkText "
					+ object+"</br>";
		}
	}

	public String scrollByCSS(String object, String data) {
		APP_LOGS.debug("Scrolling to a page by CSS "+object);
		try {
			WebElement element = driver.findElement(By.cssSelector(object));
			if (element != null) {
				((JavascriptExecutor) driver).executeScript(
						"arguments[0].scrollIntoView();", element);
			}
			return "PASS Scrolling to element of a page successfully by CSS "
					+ object;
		} catch (Exception e) {
			APP_LOGS.debug("Unable to scrolling of a page by CSS " + object);
			e.printStackTrace();
			return "FAIL <br>"+"Unable to scrolling to element of a page by CSS "
					+ object+"</br>";
		}
	}

	public String scrollByXpath(String object, String data) {
		
		APP_LOGS.debug("Scrolling to a page by xpath "+object);
		try {
			WebElement element = driver.findElement(By.xpath(object));
			if (element != null) {
				((JavascriptExecutor) driver).executeScript(
						"arguments[0].scrollIntoView();", element);
			}
			return "PASS Scrolling to element of a page successfully by xpath "
					+ object;
		} catch (Exception e) {
			APP_LOGS.debug("Unable to scrolling of a page by xpath " + object);
			e.printStackTrace();
			return "FAIL <br>"+" Unable to scrolling to element of a page by xpath "
					+ object+"</br>";
		}
	}
	
	public String selectRandomValue(String object, String data) {
		APP_LOGS.debug("Find a random value in list");
		try {
			if (!data.equals("Random_value")) {
				driver.findElement(By.xpath(object)).sendKeys(
						data);
			} else {
				// logic to find a random value in list
				WebElement droplist = driver.findElement(By.xpath(object));
				List<WebElement> droplist_cotents = droplist.findElements(By
						.tagName("option"));
				Random num = new Random();
				int index = num.nextInt(droplist_cotents.size());
				String selectedVal = droplist_cotents.get(index).getText();
				driver.findElement(By.xpath(object)).sendKeys(
						selectedVal);
				return "PASS <br>" + "Selected " + selectedVal + " from the "
						+ object + " dropdown list" + "</br>";
			}
		} catch (Exception e) {
			APP_LOGS.debug("Unable to find a random value in list");
			return "FAIL <br>" + "Unable to select the " + data + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 40);
		}
		return "PASS <br>" + "Selected " + data + " from the " + object
				+ " dropdown list" + "</br>";
	}
	
	public String selectListItem(String object, String data) {
		APP_LOGS.debug("Selecting List item from drop-down list");
		try {
			if (data.equals("Rundom_value")) {
				driver.findElement(By.xpath(object)).sendKeys(
						data);
			} else {
				// logic to find a random value in list
				WebElement droplist = driver.findElement(By.xpath(object));
				droplist.findElement(
						By.xpath("//option[contains(text(),'" + data + "')]"))
						.click();
				return "PASS <br>" + "Selected" + data + " from  the " + object
						+ " dropdown list" + "</br>";
			}
		} catch (Exception e) {
			APP_LOGS.debug("Unable to selecting List item from drop-down list");
			return "FAIL <br>" + "Unable to select the " + data + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 20);
		}
		return "PASS <br>" + "Selected " + data + " from the " + object
				+ "list" + "</br>";
	}
	
	public String containsById(String object, String id) {
		APP_LOGS.debug("Selecting List item from drop-down list");
		try {
				// logic to find a random value in list
				WebElement droplist = driver.findElement(By.xpath(object));
				droplist.findElement(
						By.xpath("//option[contains(@id,'" + id + "')]"))
						.click();
				return "PASS <br>" + "Selected" + id + " from  the " + object
						+ " dropdown list" + "</br>";
			
		} catch (Exception e) {
			APP_LOGS.debug("Unable to selecting List item from drop-down list");
			return "FAIL <br>" + "Unable to select the " + id + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 20);
		}
		
	}
	
	public String containsByName(String object, String name) {
		APP_LOGS.debug("Selecting List item from drop-down list");
		try {
				// logic to find a random value in list
				WebElement droplist = driver.findElement(By.xpath(object));
				droplist.findElement(
						By.xpath("//option[contains(@name,'" + name + "')]"))
						.click();
				return "PASS <br>" + "Selected" + name + " from  the " + object
						+ " dropdown list" + "</br>";
			
		} catch (Exception e) {
			APP_LOGS.debug("Unable to selecting List item from drop-down list");
			return "FAIL <br>" + "Unable to select the " + name + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 20);
		}
		
	}
	
	public String containsByClassName(String object, String className) {
		APP_LOGS.debug("Selecting List item from drop-down list");
		try {
				// logic to find a random value in list
				WebElement droplist = driver.findElement(By.xpath(object));
				droplist.findElement(
						By.xpath("//option[contains(@className,'" + className + "')]"))
						.click();
				return "PASS <br>" + "Selected" + className + " from  the " + object
						+ " dropdown list" + "</br>";
			
		} catch (Exception e) {
			APP_LOGS.debug("Unable to selecting List item from drop-down list");
			return "FAIL <br>" + "Unable to select the " + className + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 20);
		}
	
	}
	
	public String containsByTagName(String object, String tagName) {
		APP_LOGS.debug("Selecting List item from drop-down list");
		try {
				// logic to find a random value in list
				WebElement droplist = driver.findElement(By.xpath(object));
				droplist.findElement(
						By.xpath("//option[contains(@tagName,'" + tagName + "')]"))
						.click();
				return "PASS <br>" + "Selected" + tagName + " from  the " + object
						+ " dropdown list" + "</br>";
			
		} catch (Exception e) {
			APP_LOGS.debug("Unable to selecting List item from drop-down list");
			return "FAIL <br>" + "Unable to select the " + tagName + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 20);
		}
		
	}
	
	public String containsByLinkText(String object, String linkText) {
		APP_LOGS.debug("Selecting List item from drop-down list");
		try {
				// logic to find a random value in list
				WebElement droplist = driver.findElement(By.xpath(object));
				droplist.findElement(
						By.xpath("//option[contains(@linkText,'" + linkText + "')]"))
						.click();
				return "PASS <br>" + "Selected" + linkText + " from  the " + object
						+ " dropdown list" + "</br>";
			
		} catch (Exception e) {
			APP_LOGS.debug("Unable to selecting List item from drop-down list");
			return "FAIL <br>" + "Unable to select the " + linkText + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 20);
		}
		
	}

	public String containsByPartialLinkText(String object, String partialLinkText) {
		APP_LOGS.debug("Selecting List item from drop-down list");
		try {
				// logic to find a random value in list
				WebElement droplist = driver.findElement(By.xpath(object));
				droplist.findElement(
						By.xpath("//option[contains(@partialLinkText,'" + partialLinkText + "')]"))
						.click();
				return "PASS <br>" + "Selected" + partialLinkText + " from  the " + object
						+ " dropdown list" + "</br>";
			
		} catch (Exception e) {
			APP_LOGS.debug("Unable to selecting List item from drop-down list");
			return "FAIL <br>" + "Unable to select the " + partialLinkText + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 20);
		}
		
	}
	
	public String startsWithById(String object, String id) {
		APP_LOGS.debug("Selecting List item from drop-down list");
		try {
				// logic to find a random value in list
				WebElement droplist = driver.findElement(By.xpath(object));
				droplist.findElement(
						By.xpath("//option[starts-with(@id,'" + id + "')]"))
						.click();
				return "PASS <br>" + "Selected" + id + " from  the " + object
						+ " dropdown list" + "</br>";
			
		} catch (Exception e) {
			APP_LOGS.debug("Unable to selecting List item from drop-down list");
			return "FAIL <br>" + "Unable to select the " + id + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 20);
		}
	
	}
	
	public String startsWithByName(String object, String name) {
		APP_LOGS.debug("Selecting List item from drop-down list");
		try {
				// logic to find a random value in list
				WebElement droplist = driver.findElement(By.xpath(object));
				droplist.findElement(
						By.xpath("//option[starts-with(@name,'" + name + "')]"))
						.click();
				return "PASS <br>" + "Selected" + name + " from  the " + object
						+ " dropdown list" + "</br>";
			
		} catch (Exception e) {
			APP_LOGS.debug("Unable to selecting List item from drop-down list");
			return "FAIL <br>" + "Unable to select the " + name + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 20);
		}
		
	}
	
	public String startsWithByClassName(String object, String className) {
		APP_LOGS.debug("Selecting List item from drop-down list");
		try {
				// logic to find a random value in list
				WebElement droplist = driver.findElement(By.xpath(object));
				droplist.findElement(
						By.xpath("//option[starts-with(@className,'" + className + "')]"))
						.click();
				return "PASS <br>" + "Selected" + className + " from  the " + object
						+ " dropdown list" + "</br>";
			
		} catch (Exception e) {
			APP_LOGS.debug("Unable to selecting List item from drop-down list");
			return "FAIL <br>" + "Unable to select the " + className + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 20);
		}
		
	}
	
	public String startsWithByTagName(String object, String tagName) {
		APP_LOGS.debug("Selecting List item from drop-down list");
		try {
				// logic to find a random value in list
				WebElement droplist = driver.findElement(By.xpath(object));
				droplist.findElement(
						By.xpath("//option[starts-with(@tagName,'" + tagName + "')]"))
						.click();
				return "PASS <br>" + "Selected" + tagName + " from  the " + object
						+ " dropdown list" + "</br>";
			
		} catch (Exception e) {
			APP_LOGS.debug("Unable to selecting List item from drop-down list");
			return "FAIL <br>" + "Unable to select the " + tagName + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 20);
		}
		
	}
	
	public String startsWithByLinkText(String object, String linkText) {
		APP_LOGS.debug("Selecting List item from drop-down list");
		try {
				// logic to find a random value in list
				WebElement droplist = driver.findElement(By.xpath(object));
				droplist.findElement(
						By.xpath("//option[starts-with(@linkText,'" + linkText + "')]"))
						.click();
				return "PASS <br>" + "Selected" + linkText + " from  the " + object
						+ " dropdown list" + "</br>";
			
		} catch (Exception e) {
			APP_LOGS.debug("Unable to selecting List item from drop-down list");
			return "FAIL <br>" + "Unable to select the " + linkText + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 20);
		}
		
	}

	public String startsWithByPartialLinkText(String object, String partialLinkText) {
		APP_LOGS.debug("Selecting List item from drop-down list");
		try {
				// logic to find a random value in list
				WebElement droplist = driver.findElement(By.xpath(object));
				droplist.findElement(
						By.xpath("//option[starts-with(@partialLinkText,'" + partialLinkText + "')]"))
						.click();
				return "PASS <br>" + "Selected" + partialLinkText + " from  the " + object
						+ " dropdown list" + "</br>";
		
		} catch (Exception e) {
			APP_LOGS.debug("Unable to selecting List item from drop-down list");
			return "FAIL <br>" + "Unable to select the " + partialLinkText + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 20);
		}
		
	}
	
	public String acceptAlerts(String object, String partialLinkText) {
		APP_LOGS.debug("accepting the alerts");
		try {
			Alert alert = driver.switchTo().alert();
			alert.accept();
			return "PASS <br> accepted the alerts</br>";
		
		} catch (Exception e) {
			APP_LOGS.debug("Unable to accept the alert");
			return "FAIL <br> Unable to accept the alert </br>"
					+ e.getMessage().substring(0, 20);
		}
	}
	
	public String dismissAlerts(String object, String partialLinkText) {
		APP_LOGS.debug("dismiss the alerts");
		try {
			Alert alert = driver.switchTo().alert();
			alert.dismiss();
			return "PASS <br> dismiss the alerts</br>";
		
		} catch (Exception e) {
			APP_LOGS.debug("Unable to dismiss the alert");
			return "FAIL <br> Unable to dismiss the alert </br>"
					+ e.getMessage().substring(0, 20);
		}
	}
	
	public String getTextOfAlert(String object, String partialLinkText) {
		APP_LOGS.debug("getting the alert text");
		String alertText = null;
		try {
			Alert alert = driver.switchTo().alert();
			alertText = alert.getText();
			return "PASS <br> get the alert text "+alertText+"</br>";
		
		} catch (Exception e) {
			APP_LOGS.debug("Unable to get the alert text");
			return "FAIL <br> Unable to get the alert text "+alertText+"</br>"
					+ e.getMessage().substring(0, 20);
		}
	}
	
	public String getCookies(String object, String cookie) {
		APP_LOGS.debug("getting the cookies");
		String alertText = null;
		Set<Cookie> cookies = null;
		try {
			//Get all the cookies for the current domain
			cookies = driver.manage().getCookies();
			return "PASS <br> get the cookies "+cookies.size()+"</br>";
		
		} catch (Exception e) {
			APP_LOGS.debug("Unable to get the cookies");
			return "FAIL <br> Unable to get the cookies "+cookies.size()+"</br>"
					+ e.getMessage().substring(0, 20);
		}
	}
	
	public String addCookie(String object, String cooki) {
		APP_LOGS.debug("adding the cookies");
		Set<Cookie> cookies = null;
		try {
			cookies = driver.manage().getCookies();
			for(Cookie cookie : cookies){
				if(cookie.getName().equalsIgnoreCase(cooki)){
					driver.manage().addCookie(cookie);
				}
			}
			return "PASS <br> add the cookies "+cookies.size()+"</br>";
		
		} catch (Exception e) {
			APP_LOGS.debug("Unable to add the cookies");
			return "FAIL <br> Unable to add the cookies "+cookies.size()+"</br>"
					+ e.getMessage().substring(0, 20);
		}
	}
	
	public String deleteCookie(String object, String cooki) {
		APP_LOGS.debug("deleting the cookies");
		Set<Cookie> cookies = null;
		try {
			for(Cookie cookie : cookies){
				if(cookie.getName().equalsIgnoreCase(cooki)){
					driver.manage().deleteCookie(cookie);					
				}
			}
			return "PASS <br> deleted the cookie "+cookies.size()+"</br>";
		
		} catch (Exception e) {
			APP_LOGS.debug("Unable to delete the cookie");
			return "FAIL <br> Unable to delete the cookies "+cookies.size()+"</br>"
					+ e.getMessage().substring(0, 20);
		}
	}
	
	public String webTableById(String object, String cooki) {
		APP_LOGS.debug("iterating the table data");
		List<WebElement> tdlist = null;
		try {
			tdlist = driver.findElements(By.id(object));
			for(WebElement el: tdlist)  {
			    System.out.println(el.getText());   
			}
			return "PASS <br> iterate the table data "+tdlist.size()+"</br>";
		
		} catch (Exception e) {
			APP_LOGS.debug("Unable to iterate the table data");
			return "FAIL <br> Unable to iterate the table data "+tdlist.size()+"</br>"
					+ e.getMessage().substring(0, 20);
		}
	}
	
	public String webTableByName(String object, String cooki) {
		APP_LOGS.debug("iterate the table data");
		List<WebElement> tdlist = null;
		try {
			tdlist = driver.findElements(By.name(object));
			for(WebElement el: tdlist)  {
			    System.out.println(el.getText());   
			}
			return "PASS <br> iterate the table data "+tdlist.size()+"</br>";
		
		} catch (Exception e) {
			APP_LOGS.debug("Unable to iterate the table data");
			return "FAIL <br> Unable to iterate the table data "+tdlist.size()+"</br>"
					+ e.getMessage().substring(0, 20);
		}
	}
	
	public String webTableByClassName(String object, String cooki) {
		APP_LOGS.debug("iterate the table data");
		List<WebElement> tdlist = null;
		try {
			tdlist = driver.findElements(By.className(object));
			for(WebElement el: tdlist)  {
			    System.out.println(el.getText());   
			}
			return "PASS <br> iterate the table data "+tdlist.size()+"</br>";
		
		} catch (Exception e) {
			APP_LOGS.debug("Unable to iterate the table data");
			return "FAIL <br> Unable to iterate the table data "+tdlist.size()+"</br>"
					+ e.getMessage().substring(0, 20);
		}
	}
	
	public String webTableBYTagName(String object, String cooki) {
		APP_LOGS.debug("iterate the table data");
		List<WebElement> tdlist = null;
		try {
			tdlist = driver.findElements(By.tagName(object));
			for(WebElement el: tdlist)  {
			    System.out.println(el.getText());   
			}
			return "PASS <br> iterate the table data "+tdlist.size()+"</br>";
		
		} catch (Exception e) {
			APP_LOGS.debug("Unable to iterate the table data");
			return "FAIL <br> Unable to iterate the table data "+tdlist.size()+"</br>"
					+ e.getMessage().substring(0, 20);
		}
	}
	
	public String webTableByCSS(String object, String cooki) {
		APP_LOGS.debug("iterate the table data");
		List<WebElement> tdlist = null;
		try {
			tdlist = driver.findElements(By.cssSelector(object));
			for(WebElement el: tdlist)  {
			    System.out.println(el.getText());   
			}
			return "PASS <br> iterate the table data "+tdlist.size()+"</br>";
		
		} catch (Exception e) {
			APP_LOGS.debug("Unable to iterate the table data");
			return "FAIL <br> Unable to iterate the table data "+tdlist.size()+"</br>"
					+ e.getMessage().substring(0, 20);
		}
	}
	
	public String webTableByXpath(String object, String cooki) {
		APP_LOGS.debug("iterate the table data");
		List<WebElement> tdlist = null;
		try {
			tdlist = driver.findElements(By.xpath(object));
			for(WebElement el: tdlist)  {
			    System.out.println(el.getText());   
			}
			return "PASS <br> iterate the table data "+tdlist.size()+"</br>";
		
		} catch (Exception e) {
			APP_LOGS.debug("Unable to iterate the table data");
			return "FAIL <br> Unable to iterate the table data "+tdlist.size()+"</br>"
					+ e.getMessage().substring(0, 20);
		}
	}
}
