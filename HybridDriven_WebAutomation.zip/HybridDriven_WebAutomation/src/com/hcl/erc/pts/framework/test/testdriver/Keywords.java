package com.hcl.erc.pts.framework.test.testdriver;

import static com.hcl.erc.pts.framework.test.testdriver.TestDriver.APP_LOGS;
import static com.hcl.erc.pts.framework.test.testdriver.TestDriver.CONFIG;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.opera.OperaDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * The Class Keywords.
 */
public class Keywords {

	/** The driver. */
	public static WebDriver driver;

	/** The s handle before. */
	public String sHandleBefore = "";

	/** The filename. - Screen shot name */
	public String filename;

	/** The keyword_execution_result. - Execution result of the keyword */
	public String keyword_execution_result;

	/** The browser version. - Browser version of the current executed keyword */
	public static String browserVersion;

	/** The var. */
	public static String var = null;

	/** The platform. */
	public static Platform platfrom = null;

	public static String browserName = null;
	
	public static Keywords keywords;

	private enum Mode {
		xpath, id, linkText, value, name, cssSel;
	}

	public Keywords getKeywords(){
		if(keywords==null)keywords = new Keywords();
		return keywords;
	}
	
	
	/*************************************************************************.
	# 1
	**************************************************************************
	'* Keyword Name         : openBrowser
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Opening the browser
	'* Input Parameters     : data
	'* Output Parameters    : PASS or FAIL
	'* Usage				: openBrowser(object, data)
		 					object:=Not required
		 					data  :=data is taken from xml file 	
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/

	public String openBrowser(String URL, String browser) {
		try {
			APP_LOGS.debug("Opening browser");
			Platform Exeplatfrom = null;
	        if(System.getProperty("os.name").toLowerCase().substring(0, 3).equals("mac")){ 
	        	if (browser.equals("Mozilla")) {
					File pathToBinary = new File(CONFIG.getProperty("browserPathFirefox"));
					FirefoxBinary ffBinary = new FirefoxBinary(pathToBinary);
					FirefoxProfile firefoxProfile = new FirefoxProfile();
					firefoxProfile.setPreference("network.proxy.type", 1);
					firefoxProfile.setPreference("network.proxy.http",
							"noida-sez-v10k.hclt.corp.hcl.in");
					firefoxProfile.setPreference("network.proxy.http_port", 8080);
					firefoxProfile.setPreference("network.proxy.ssl",
							"noida-sez-v10k.hclt.corp.hcl.in");
					firefoxProfile.setPreference("network.proxy.ssl_port", 8080);
					// download file path
					//firefoxProfile.setPreference("browser.download.dir","d:\\downloads");
					driver = new FirefoxDriver(ffBinary, firefoxProfile);
					
					
					Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
					browserName = caps.getBrowserName();
					browserVersion = caps.getVersion();
					var = browserVersion;
					Exeplatfrom = caps.getPlatform();
					platfrom = Exeplatfrom;

					//driver.get(URL);
					DymamicWait();
					
				} else if (browser.equalsIgnoreCase("IE")) {
					System.setProperty("webdriver.ie.driver",System.getProperty("user.dir")+CONFIG.getProperty("browserPathIE"));
					driver = new InternetExplorerDriver();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

					Capabilities caps = ((RemoteWebDriver) driver)
							.getCapabilities();
					browserName = caps.getBrowserName();
					browserVersion = caps.getVersion();
					var = browserVersion;
					Exeplatfrom = caps.getPlatform();
					platfrom = Exeplatfrom;
					
				//	driver.get(URL);
					DymamicWait();

				} else if (browser.equals("Chrome")) {
					System.setProperty("chrome.binary","/usr/local/bin/chromedriver.exe");
					driver = new ChromeDriver();
					Capabilities caps = ((RemoteWebDriver) driver)
							.getCapabilities();
					browserName = caps.getBrowserName();
					browserVersion = caps.getVersion();
					var = browserVersion;
					Exeplatfrom = caps.getPlatform();
					platfrom = Exeplatfrom;
					
				//	driver.get(URL);
					DymamicWait();
					
				} else if (browser.equals("Opera")) {
					DesiredCapabilities capabilities = DesiredCapabilities.opera();
					capabilities.setCapability("opera.binary",
							" Absolute Path of Opera browser ");
					driver = new OperaDriver(capabilities);
					Capabilities caps = ((RemoteWebDriver) driver)
							.getCapabilities();
					browserName = caps.getBrowserName();
					browserVersion = caps.getVersion();
					var = browserVersion;
					Exeplatfrom = caps.getPlatform();
					platfrom = Exeplatfrom;
					
				//	driver.get(URL);
					DymamicWait();
				} else if (browser.equals("Safari")) {
					driver = new SafariDriver();
					Capabilities caps = ((RemoteWebDriver) driver)
							.getCapabilities();
					browserName = caps.getBrowserName();
					browserVersion = caps.getVersion();
					var = browserVersion;
					Exeplatfrom = caps.getPlatform();
					platfrom = Exeplatfrom;
					
				//	driver.get(URL);
					DymamicWait();
	        }
	        }else{
			if (browser.equals("Mozilla")) {
				/*File pathToBinary = new File(CONFIG.getProperty("browserPathFirefox"));
				FirefoxBinary ffBinary = new FirefoxBinary(pathToBinary);
				FirefoxProfile firefoxProfile = new FirefoxProfile();
				firefoxProfile.setPreference("network.proxy.type", 1);
				firefoxProfile.setPreference("network.proxy.http",
						"noida-sez-v10k.hclt.corp.hcl.in");
				firefoxProfile.setPreference("network.proxy.http_port", 8080);
				firefoxProfile.setPreference("network.proxy.ssl",
						"noida-sez-v10k.hclt.corp.hcl.in");
				firefoxProfile.setPreference("network.proxy.ssl_port", 8080);
				// download file path
				//firefoxProfile.setPreference("browser.download.dir","d:\\downloads");
				driver = new FirefoxDriver(ffBinary, firefoxProfile);*/
				
			/*	FirefoxBinary binary = new FirefoxBinary(new File(CONFIG.getProperty("browserPathFirefox")));
				FirefoxProfile profile = new FirefoxProfile();
				driver = new FirefoxDriver(binary, profile);
			*/	
				driver = new FirefoxDriver();
				
				Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
				browserName = caps.getBrowserName();
				browserVersion = caps.getVersion();
				var = browserVersion;
				Exeplatfrom = caps.getPlatform();
				platfrom = Exeplatfrom;

				//driver.get(URL);
				DymamicWait();
				
			} else if (browser.equalsIgnoreCase("IE")) {
				System.setProperty("webdriver.ie.driver",System.getProperty("user.dir")+CONFIG.getProperty("browserPathIE"));
				driver = new InternetExplorerDriver();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

				Capabilities caps = ((RemoteWebDriver) driver)
						.getCapabilities();
				browserName = caps.getBrowserName();
				browserVersion = caps.getVersion();
				var = browserVersion;
				Exeplatfrom = caps.getPlatform();
				platfrom = Exeplatfrom;
				
			//	driver.get(URL);
				DymamicWait();

			} else if (browser.equals("Chrome")) {
//				System.setProperty("webdriver.chrome.driver","D:\\Indra\\workspace\\Feb\\HybridDriven_WebAutomation\\drivers\\chromedriver.exe");
				System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+CONFIG.getProperty("browserPathChrome"));
				driver = new ChromeDriver();
				Capabilities caps = ((RemoteWebDriver) driver)
						.getCapabilities();
				browserName = caps.getBrowserName();
				browserVersion = caps.getVersion();
				var = browserVersion;
				Exeplatfrom = caps.getPlatform();
				platfrom = Exeplatfrom;
				
			//	driver.get(URL);
				DymamicWait();
				
			} else if (browser.equals("Opera")) {
				DesiredCapabilities capabilities = DesiredCapabilities.opera();
				capabilities.setCapability("opera.binary",
						" Absolute Path of Opera browser ");
				driver = new OperaDriver(capabilities);
				Capabilities caps = ((RemoteWebDriver) driver)
						.getCapabilities();
				browserName = caps.getBrowserName();
				browserVersion = caps.getVersion();
				var = browserVersion;
				Exeplatfrom = caps.getPlatform();
				platfrom = Exeplatfrom;
				
			//	driver.get(URL);
				DymamicWait();
			} else if (browser.equals("Safari")) {
				driver = new SafariDriver();
				Capabilities caps = ((RemoteWebDriver) driver)
						.getCapabilities();
				browserName = caps.getBrowserName();
				browserVersion = caps.getVersion();
				var = browserVersion;
				Exeplatfrom = caps.getPlatform();
				platfrom = Exeplatfrom;
				
			//	driver.get(URL);
				DymamicWait();
			}
	        }
	        
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			return "PASS" + "<br>" + "Sucessfully opened the " +browser+" browser "
					+ "<FONT COLOR=0000FF>" + "<B>  Browser = </B>" + "<B>"
					+ browser + "</B>" + " ,<B> Version = " + "</B>"
					+ "<B>" + browserVersion + "</B>" + "</br>" + "</FONT>";
	        }catch (Exception e) {
			APP_LOGS.info("Unable to find the "+browser+".exe file path in config.properties");
			e.getMessage();
			System.exit(0);
			return "FAIL" + "<br>" + "Unable to Open " + browser + "-"
					+ browserVersion + " Brower"
					+ e.getMessage().substring(0, 40) + "</br>";
		}
	}

	/*************************************************************************.
	# 2
	**************************************************************************
	'* Keyword Name         : mouseHover
	'* Developed Date 		:
	'* Author              	: HCL
	'* Purpose              : Perform Mouse Hover operation
	'* Input Parameters     : xpath of the object 
	'* Output Parameters    : PASS or FAIL
	'* Usage				: mouseHover(object,  data)
							object:=Xpath of the object
							data  :=Data is not required
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/
	
	public String mouseHover(String object, String data) {
		try {
			APP_LOGS.debug("Perform Mouse Hover operation");
			WebElement element = driver.findElement(By.xpath(object));
			Actions builder = new Actions(driver);
			builder.moveToElement(element).build().perform();
			return "PASS <br>" + " Mouse hover on the " + object
					+ " object was successful" + "</br>";
		} catch (Exception e) {
			APP_LOGS.debug("Unable to perform Mouse Hover operation");
			return "FAIL <br>" + " Unable to hover on the " + object
					+ " object -- " + e.getMessage().substring(0, 40) + "</br>";
		}

	}

	/*************************************************************************.
	# 3
	**************************************************************************
	'* Keyword Name         : enterText
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : enter the data into text field
	'* Input Parameters     : object , data
	'* Output Parameters    : PASS or FAIL
	'* Usage				: enterText(object, data)
		 					object:=Xpath of the object
		 					data  :=data is taken from xml file 	
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/
	
	public String enterText(String object, String data) {
		try {
			APP_LOGS.debug("Writing in text box");
			WebElement element = driver.findElement(By.xpath(object));
			element.clear();
			element.sendKeys(data);
			element.sendKeys("");
		} catch (Exception e) {
			APP_LOGS.debug("Unable to writing in text box");
			return "FAIL <br>" + "Unable to write in the Input box "
					+ e.getMessage().substring(0, 40) + "</br>";
		}
		return "PASS <br>" + "Entered input " + data + " in " + object
				+ "</br>";
	}

	/*************************************************************************.
	# 4
	**************************************************************************
	'* Keyword Name         : navigate
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Navigate to the specified URL
	'* Input Parameters     : data
	'* Output Parameters    : PASS or FAIL
	'* Usage				: navigate(object,  data)
							object:=object is not required
							data  :=Data will be taken from the xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/
	
	public String navigate(String object, String data) {
		APP_LOGS.debug("Navigating to URL");
		try {
			//driver.get(data);
			driver.navigate().to(data);
			DymamicWait();
			return "PASS <br>" + "Able to navigate to the " + data
					+ " URL successfully" + "</br>";
		} catch (Exception e) {
			APP_LOGS.debug("Unable to navigating to URL");
			return "FAIL <br>" + "Unable to navigate to the " + data + " URL "
					+ e.getMessage().substring(0, 20) + "</br>";
		}
	}

	/*************************************************************************.
	# 5
	**************************************************************************
	'* Keyword Name         : DymamicWait
	'* Developed Date 		: 
	'* Author               : HCL
	'* Purpose              : This method will wait till the ajax and page is loaded completely
	'* Input Parameters     : data
	'* Output Parameters    :
	'* Usage				: Give maximum wait time in config.properties
							Ex: DynamicWaitTime=120
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	**************************************************************************/
	
	public void DymamicWait() {
		try {
			String getWaitTime;
			getWaitTime = CONFIG.getProperty("DynamicWaitTime");
			int maxWaitTime = Integer.parseInt(getWaitTime);
			for (int j = 0; j < maxWaitTime; j++) {
				String ajaxComplete = ((org.openqa.selenium.JavascriptExecutor) driver)
						.executeScript("return jQuery.active == 0").toString();
				if (ajaxComplete.equalsIgnoreCase("true")) {
					break;
				}
				Thread.sleep(1000);
			}
			for (int j = 0; j < maxWaitTime; j++) {
				
				String pageLoad = ((org.openqa.selenium.JavascriptExecutor) driver)
						.executeScript("return document.readyState").toString();
				if (pageLoad.equalsIgnoreCase("complete")) {
					break;
				}
				Thread.sleep(1000);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	/*************************************************************************.
	# 6
	**************************************************************************
	'* Keyword Name         : click
	'* Developed Date 		:
	'* Author              	: HCL
	'* Purpose              : Clicking on specified object
	'* Input Parameters     : Xpath of the object
	'* Output Parameters    : PASS or FAIL
	'* Usage				: click(object,  data)
							object:=Xpath of the object
							data  :=Data is not required
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/
	
	public String click(String object, String data) {
		APP_LOGS.debug("Clicking on specified object");
		try {
			driver.findElement(By.xpath(object)).click();
			return "PASS <br>" + "Successfully clicked on the " + object
					+ " object" + "</br>";
		} catch (Exception e) {
			APP_LOGS.debug("Unable to clicking on specified object");
			return "FAIL <br>" + "Unable to click on the " + object
					+ " Object --" + e.getMessage().substring(0, 40) + "</br>";
		}

	}
	
	public String clickAndEnterText(String object, String data) {
		APP_LOGS.debug("Clicking on specified object");
		try {
			WebElement click = driver.findElement(By.xpath(object));
			click.click();
			Thread.sleep(2000);
			System.out.println(data+" 111111111111111111");
			click.sendKeys(data);
			return "PASS <br>" + "Successfully clicked on the " + object
					+ " object" + "</br>";
		} catch (Exception e) {
			APP_LOGS.debug("Unable to clicking on specified object");
			return "FAIL <br>" + "Unable to click on the " + object
					+ " Object --" + e.getMessage().substring(0, 40) + "</br>";
		}

	}

	/*************************************************************************.
	# 7
	**************************************************************************
	'* Keyword Name         : waitForPageload
	'* Developed Date 		:
	'* Author              	: HCL
	'* Purpose              : waiting upto page is loaded
	'* Input Parameters     : data
	'* Output Parameters    : PASS or FAIL
	'* Usage				: waitForPageload(object,  data)
							object:=Object is not required
							data  :=giving some time to loading the page
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/
	
	public String waitForPageload(String object, String data) {

		try {
			APP_LOGS.debug("Waiting for page loading");
			try {
				// CONFIG.getProperty("DynamicWaitTime");
				int maxWaitTime = Integer.parseInt(data);
				for (int j = 0; j < maxWaitTime; j++) {
					String ajaxComplete = ((org.openqa.selenium.JavascriptExecutor) driver)
							.executeScript("return jQuery.active == 0")
							.toString();
					if (ajaxComplete.equalsIgnoreCase("true")) {
						break;
					}
					Thread.sleep(5000);
				}
				for (int j = 0; j < maxWaitTime; j++) {
					String pageLoad = ((org.openqa.selenium.JavascriptExecutor) driver)
							.executeScript("return document.readyState")
							.toString();
					if (pageLoad.equalsIgnoreCase("complete")) {
						break;
					}
					Thread.sleep(5000);
				}
				Thread.sleep(Integer.parseInt(data)*100);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			// Thread.sleep(80000);
		} catch (Exception e) {
			APP_LOGS.debug("Unable to wait for page loading");
			return "FAIL <br>" + "Object timeout "
					+ e.getMessage().substring(0, 40) + "</br>";
		}
		return "PASS <br>" + "Page Loaded Successfully " + data + " in "
				+ object + "</br>";
	}

	/*************************************************************************.
	# 8
	**************************************************************************
	'* Keyword Name         : closeBrowser
	'* Developed Date 		:
	'* Author              	: HCL
	'* Purpose              : Closing the browser
	'* Input Parameters     : NA
	'* Output Parameters    : PASS or FAIL
	'* Usage				: closeBrowser(object,  data)
							object:=object is not required
							data  :=Data is not required
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/
	
	public String closeBrowser(String object, String data) {
		APP_LOGS.debug("Closing the browser");
		try {
			driver.close();
		} catch (Exception e) {
			APP_LOGS.debug("Unable to closing the browser");
			return "FAIL <br>" + " Unable to close browser"
					+ e.getMessage().substring(0, 40) + "</br>";
		}
		return "PASS <br> Browser closed successfully" + "</br>";
	}

	public String quitBrowsers(String object, String data) {
		APP_LOGS.debug("Closing the browser");
		try {
			driver.quit();
		} catch (Exception e) {
			APP_LOGS.debug("Unable to closing the browser");
			return "FAIL <br>" + " Unable to close browser"
					+ e.getMessage().substring(0, 40) + "</br>";
		}
		return "PASS <br> Browser closed successfully" + "</br>";
	}
	/*************************************************************************.
	# 9
	**************************************************************************
	'* Keyword Name         : verifyAllListItems
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Verify the all the list items
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters    : PASS or FAIL
	'* Usage				: verifyAllListItems(object, data)
							object:=Xpath of the object
							data  :=Data will be taken from the Xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/
	
	public String verifyAllListItems(String object, String data) {
		APP_LOGS.debug("Verify All list item details"); 
		String isExists = "";
		try {
			if (waitUntilExists(object, "xpath")) {

				WebElement trElement = driver.findElement(By.xpath(object));
				String[] aArray = data.split("|");
				List<WebElement> td_collection = trElement.findElements(By
						.xpath("li"));
				for (WebElement tdElement : td_collection) {
					for (int i = 0; i < aArray.length; i++) {
						if (tdElement.getText().contains(aArray[i].trim())) {
							isExists = "true";
						} else {
							isExists = "false";
							break;
						}
					}
				}
			} else
				return "FAIL </br>" + object + " Dropdown List does not exist"
						+ "</br>";

		} catch (Exception e) {
			APP_LOGS.debug("Unable to verify All list item details");
			return "FAIL </br>" + " Unable to verify the " + object
					+ "dropdown List item. --"
					+ e.getMessage().substring(0, 40) + "</br>";
		}
		if (isExists.equalsIgnoreCase("true")) {
			return "PASS </br>"
					+ "All the specified List Items are verified in the "
					+ object + "dropdown" + "</br>";
		} else {
			APP_LOGS.debug("Unable to verify All list item details");
			return "FAIL </br>" + data + " Items not found in the " + object
					+ " dropdown List" + "</br>";
		}
	}

	/*************************************************************************.
	# 10
	**************************************************************************
	'* Keyword Name         : waitUntilExists
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Wait until the object is visible
	'* Input Parameters     : object and data
	'* Output Parameters    : true or false
	'* Usage				: waitUntilExists(object, mode)
							object:=object
							mode  :=To specify the Mode used for identification of the Object like xpath, ClassName, LinkText etc.
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/
	public boolean waitUntilExists(String object, String mode) {
		APP_LOGS.debug("Wait until the object is visible");
		boolean result = false;
		try {
			Mode accessBy = Mode.valueOf(mode);
			int count = 1;
			while (count < 2000) {
				Thread.sleep(1000);
				switch (accessBy) {
				case xpath:
					if (driver.findElement(By.xpath(object)) != null) {
						result = true;
						count = 2000;
					}
					break;
				case id:
					if (driver.findElement(By.xpath(object)) != null) {
						result = true;
						count = 2000;
					}
					break;
				case linkText:
					if (driver.findElement(By.linkText(object)) != null) {
						result = true;
						count = 2000;
					}
					break;
				case name:
					if (driver.findElement(By.name(object)) != null) {
						result = true;
						count = 2000;
					}
					break;
				case cssSel:
					if (driver.findElement(By.cssSelector(object)) != null) {
						result = true;
						count = 2000;
					}
					break;
				default:
					break;
				}
				count++;
			}

		} catch (InterruptedException ie) {
			APP_LOGS.debug("Unable to wait until the object is visible");
			ie.printStackTrace();
		}
		return result;
	}

	/*************************************************************************.
	# 11
	**************************************************************************
	'* Keyword Name         : verifyTextIgnoreCase
	'* Developed Date 		:
	'* Author              	: HCL
	'* Purpose              : Verifying the text
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters  	: PASS or FAIL
	'* Usage				: verifyText(object, data)
							object:= Xpath of the object
							data  := Data will be taken from the Xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/
	
	public String verifyTextIgnoreCase(String object, String data) {
		String expected = data;
		APP_LOGS.debug("Verifying the text"); 
		try {
			if (waitUntilExists(object, "xpath")) {
				String actual = driver.findElement(
						By.xpath(object)).getText();
				if (actual.equalsIgnoreCase(expected))
					return "PASS <br>   <B>  Expected text: " + "</B>"
							+ expected + "<B>" + " Actual text: " + "</B>"
							+ actual + "</br>";
				else
					APP_LOGS.debug("The expected and actual are not same");
					return "FAIL  <br>  <B>   Expected text: " + "</B>"
							+ expected + "<B>" + " Actual text: " + "</B>"
							+ actual + "</br>";
			} else
				return "FAIL <br>  " + expected
						+ "  text is not displayed in the application" + "<B>"
						+ "</br>";
		} catch (Exception e) {
			APP_LOGS.debug("Unable to verifying the text");
			return "FAIL <br> Unable to verify the text " + expected + "<br>"
					+ e.getMessage().substring(0, 40) + "<B>" + "</br>";
		}
	}
	
	public String verifyTextContains(String object, String data) {
		String expected = data;
		APP_LOGS.debug("Verifying the text"); 
		try {
			if (waitUntilExists(object, "xpath")) {
				String actual = driver.findElement(
						By.xpath(object)).getText();
				if (actual.contains(expected))
					return "PASS <br>   <B>  Expected text: " + "</B>"
							+ expected + "<B>" + " Actual text: " + "</B>"
							+ actual + "</br>";
				else
					APP_LOGS.debug("The expected and actual are not same");
					return "FAIL  <br>  <B>   Expected text: " + "</B>"
							+ expected + "<B>" + " Actual text: " + "</B>"
							+ actual + "</br>";
			} else
				return "FAIL <br>  " + expected
						+ "  text is not displayed in the application" + "<B>"
						+ "</br>";
		} catch (Exception e) {
			APP_LOGS.debug("Unable to verifying the text");
			return "FAIL <br> Unable to verify the text " + expected + "<br>"
					+ e.getMessage().substring(0, 40) + "<B>" + "</br>";
		}
	}

	/*************************************************************************.
	# 11
	**************************************************************************
	'* Keyword Name         : verifyText
	'* Developed Date 		:
	'* Author              	: HCL
	'* Purpose              : Verifying the text
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters  	: PASS or FAIL
	'* Usage				: verifyText(object, data)
							object:= Xpath of the object
							data  := Data will be taken from the Xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/
	
	public String verifyText(String object, String data) {
		String expected = data;
		APP_LOGS.debug("Verifying the text"); 
		try {
			if (waitUntilExists(object, "xpath")) {
				String actual = driver.findElement(
						By.xpath(object)).getText();
				if (actual.equals(expected))
					return "PASS <br>   <B>  Expected text: " + "</B>"
							+ expected + "<B>" + " Actual text: " + "</B>"
							+ actual + "</br>";
				else
					APP_LOGS.debug("The expected and actual are not same");
					return "FAIL  <br>  <B>   Expected text: " + "</B>"
							+ expected + "<B>" + " Actual text: " + "</B>"
							+ actual + "</br>";
			} else
				return "FAIL <br>  " + expected
						+ "  text is not displayed in the application" + "<B>"
						+ "</br>";
		} catch (Exception e) {
			APP_LOGS.debug("Unable to verifying the text");
			return "FAIL <br> Unable to verify the text " + expected + "<br>"
					+ e.getMessage().substring(0, 40) + "<B>" + "</br>";
		}
	}
	
	public String verifyContainsText(String object, String data) {
		String expected = data;
		APP_LOGS.debug("Verifying the text"); 
		try {
			if (waitUntilExists(object, "xpath")) {
				String actual = driver.findElement(
						By.xpath(object)).getText();
				if (actual.contains(expected))
					return "PASS <br>   <B>  Expected text: " + "</B>"
							+ expected + "<B>" + " Actual text: " + "</B>"
							+ actual + "</br>";
				else
					APP_LOGS.debug("The expected and actual are not same");
					return "FAIL  <br>  <B>   Expected text: " + "</B>"
							+ expected + "<B>" + " Actual text: " + "</B>"
							+ actual + "</br>";
			} else
				return "FAIL <br>  " + expected
						+ "  text is not displayed in the application" + "<B>"
						+ "</br>";
		} catch (Exception e) {
			APP_LOGS.debug("Unable to verifying the text");
			return "FAIL <br> Unable to verify the text " + expected + "<br>"
					+ e.getMessage().substring(0, 40) + "<B>" + "</br>";
		}
	}
	/*************************************************************************.
	# 12
	**************************************************************************
	'* Keyword Name         : selectList
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Find a random value in list
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters    : PASS or FAIL
	'* Usage				: selectList(object, data)
			 				object:=Xpath of the object
			 				data  :=Data will be taken from the Xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/
	
	public String selectList(String object, String data) {
		APP_LOGS.debug("Find a random value in list");
		try {
			if (!data.equals("Random_value")) {
				driver.findElement(By.xpath(object)).sendKeys(
						data);
			} else {
				// logic to find a random value in list
				WebElement droplist = driver.findElement(By.xpath(object));
				List<WebElement> droplist_cotents = droplist.findElements(By
						.tagName("option"));
				Random num = new Random();
				int index = num.nextInt(droplist_cotents.size());
				String selectedVal = droplist_cotents.get(index).getText();
				driver.findElement(By.xpath(object)).sendKeys(
						selectedVal);
				return "PASS <br>" + "Selected " + selectedVal + " from the "
						+ object + " dropdown list" + "</br>";
			}
		} catch (Exception e) {
			APP_LOGS.debug("Unable to find a random value in list");
			return "FAIL <br>" + "Unable to select the " + data + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 40);
		}
		return "PASS <br>" + "Selected " + data + " from the " + object
				+ " dropdown list" + "</br>";
	}

	/*************************************************************************.
	# 13
	**************************************************************************
	'* Keyword Name         : selectListItem
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Select the specified Item from the drop-down list
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters    : PASS or FAIL
	'* Usage				: selectListItem(object, data)
			 				object:=Xpath of the object
			 				data  :=Data will be taken from the Xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/
	
	public String selectListItem(String object, String data) {
		APP_LOGS.debug("Selecting List item from drop-down list");
		try {
			if (data.equals("Rundom_value")) {
				driver.findElement(By.xpath(object)).sendKeys(
						data);
			} else {
				// logic to find a random value in list
				WebElement droplist = driver.findElement(By.xpath(object));
				droplist.findElement(
						By.xpath("//option[contains(text(),'" + data + "')]"))
						.click();
				return "PASS <br>" + "Selected" + data + " from  the " + object
						+ " dropdown list" + "</br>";
			}
		} catch (Exception e) {
			APP_LOGS.debug("Unable to selecting List item from drop-down list");
			return "FAIL <br>" + "Unable to select the " + data + " from "
					+ object + " list" + "</br>"
					+ e.getMessage().substring(0, 20);
		}
		return "PASS <br>" + "Selected " + data + " from the " + object
				+ "list" + "</br>";
	}

	/*************************************************************************.
	# 14
	**************************************************************************
	'* Keyword Name         : captureScreenshot
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Capture Screenshot on failure
	'* Input Parameters     : Xpath and data
	'* Output Parameters    : NA
	'* Usage				: captureScreenshot(filename,  keyword_execution_result)
							filename:=filename of the screenshot
							keyword_execution_result  :=keyword_execution_result value is taken from the TestExecutionEngine file at runtime
	'* Revision History     :
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'* Comment  :
	**************************************************************************/
	
	public void captureScreenshot(String filename,String keyword_execution_result) {
		APP_LOGS.debug("Capture Screenshot on failure");
		try {
			// take screen shots
			if (keyword_execution_result.contains("FAIL")) {
				// capturescreen
				File scrFile = ((TakesScreenshot) driver)
						.getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile,
						new File(System.getProperty("user.dir")
								+ "\\screenshots\\" + filename + ".png"));
			}

		} catch (IOException ie) {
			APP_LOGS.debug("Unable to capture Screenshot on failure");
			ie.getMessage().substring(0, 40);
		} catch (Exception e) {
			APP_LOGS.debug("Unable to capture Screenshot on failure");
			e.getMessage().substring(0, 40);
		}
	}

	/*************************************************************************.
	# 15
	**************************************************************************
	'* Keyword Name         : scrollingToBottomofAPage
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Scrolling to bottom of a page
	'* Input Parameters     : xpath and data
	'* Output Parameters    : NA
	'* Usage				: scrollingToBottomofAPage(filename,  keyword_execution_result)
							object:= not required
							data  := not required
	'* Revision History     :
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'* Comment  :
	**************************************************************************/
	public String scrollingToBottomofAPage(String object,String data){
		APP_LOGS.debug("Scrolling to bottom of a page");
		try{
			((JavascriptExecutor) driver)
	         .executeScript("window.scrollTo(0, document.body.scrollHeight)");
			return "PASS <br>" + "Scrolling to bottom of a page successfully " + data + " in " + object
					+ "</br>";
		}catch(Exception e){
			APP_LOGS.debug("Unable to scrolling bottom of a page");
			e.printStackTrace();
			return "FAIL <br>" + "Unable to scrolling to bottom of a page" + data + " in "
			+ object + "</br>";
		}
	}
	
	/*************************************************************************.
	# 16
	**************************************************************************
	'* Keyword Name         : scrollingToElementofAPage
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Scrolling to element of a page
	'* Input Parameters     : xpath and data
	'* Output Parameters    : NA
	'* Usage				: scrollingToElementofAPage(object, data)
							object:= object is required to identifying an element 
							data  := not required
	'* Revision History     :
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'* Comment  :
	**************************************************************************/
	public String scrollingToElementofAPage(String object, String data){
		APP_LOGS.debug("Scrolling to element of a page");
		try{
			WebElement element = driver.findElement(By.xpath(object));
			if(element!=null){
			((JavascriptExecutor) driver).executeScript(
	                "arguments[0].scrollIntoView();", element);
			}
			return "PASS <br>" + "Scrolling to element of a page successfully " + data + " in " + object
					+ "</br>";
		}catch(Exception e){
			APP_LOGS.debug("Unable to scrolling element of a page");
			e.printStackTrace();
			return "FAIL <br>" + "Unable to scrolling to element of a page" + data + " in "
			+ object + "</br>";
		}
	}
	
	/*************************************************************************.
	# 17
	**************************************************************************
	'* Keyword Name         : scrollingByCoordinatesofAPage
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Scrolling by coordinates of a page
	'* Input Parameters     : xpath and data
	'* Output Parameters    : NA
	'* Usage				: scrollingByCoordinatesofAPage(object,data)
							object:= not required
							data  := not required
	'* Revision History     :
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'* Comment  :
	**************************************************************************/
	public String scrollingByCoordinatesofAPage(String object, String data){
		APP_LOGS.debug("Scrolling by coodinates of a page");
		try{
			((JavascriptExecutor) driver).executeScript("window.scrollBy(0,500)");
			return "PASS <br>" + "Scrolling by coordinates of a page successfully " + data + " in " + object
					+ "</br>";
		}catch(Exception e){
			APP_LOGS.debug("Unable to scrolling by coodinates of a page");
			e.printStackTrace();
			return "FAIL <br>" + "Unable to scrolling by coordinates of a page" + data + " in "
			+ object + "</br>";
		}
	}
	
	/*************************************************************************.
	# 18
	**************************************************************************
	'* Keyword Name         : switchToWindowPopup
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Switched to window popup 
	'* Input Parameters     : xpath and data
	'* Output Parameters    : NA
	'* Usage				: switchToWindowPopup(object,data)
							object:= not required
							data  := not required
	'* Revision History     :
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'* Comment  :
	'* @throws InterruptedException 
	**************************************************************************/
	public String switchToWindowPopup(String object, String data) {
		APP_LOGS.debug("Switch to window popup");
		String[] xpaths = object.split("#");
		String[] testData = data.split("#");
		try{
			// TODO 
			String mainWindow = driver.getWindowHandle();
			for(String winHandle:driver.getWindowHandles()){
				driver.switchTo().window(winHandle);
				if(driver.getTitle().equals(testData[0])){
					if(testData[testData.length-1]!=null&&testData[testData.length-1].equals("iframe")){
						driver.switchTo().frame(driver.findElement(By.xpath(xpaths[0])));
				        driver.findElement(By.xpath(xpaths[1])).click();
					}else{
						driver.findElement(By.xpath(xpaths[0])).click();
					}
				}
			}
			driver.switchTo().window(mainWindow);
			return "PASS <br>" + "Switched to window popup successfully " + data + " in " + object
					+ "</br>";
		}catch(Exception e){
			APP_LOGS.debug("Unable to switch to window popup");
			e.printStackTrace();
			return "FAIL <br>" + "Unable to switched to window popup " + data + " in "
			+ object + "</br>";
		}
	}
	/*************************************************************************.
	# 19
	**************************************************************************
	'* Keyword Name         : verifyTitleText
	'* Developed Date 		:
	'* Author              	: HCL
	'* Purpose              : Verifying the title text
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters  	: PASS or FAIL
	'* Usage				: verifyTitleText(object, data)
							object:= Xpath of the object
							data  := Data will be taken from the Xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/
	
	public String verifyTitleText(String object, String data) {
		String expected = data;
		APP_LOGS.debug("Verifying title text"); 
		try {
				String actual = driver.getTitle();
				if (actual.equalsIgnoreCase(expected))
					return "PASS <br>   <B>  Expected title text: " + "</B>"
							+ expected + "<B>" + " Actual title text: " + "</B>"
							+ actual + "</br>";
				else
					return "FAIL  <br>  <B>   Expected title text: " + "</B>"
							+ expected + "<B>" + " Actual title text: " + "</B>"
							+ actual + "</br>";
				
		} catch (Exception e) {
			APP_LOGS.debug("Unable to verifying title text"); 
			return "FAIL <br> Unable to verify the title text " + expected + "<br>"
					+ e.getMessage().substring(0, 40) + "<B>" + "</br>";
		}
	}
	
	/*************************************************************************.
	# 20
	**************************************************************************
	'* Keyword Name         : verifyGetAttributeText
	'* Developed Date 		:
	'* Author              	: HCL
	'* Purpose              : Verify and get the attribute text
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters  	: PASS or FAIL
	'* Usage				: verifyGetAttributeText(object, data)
							object:= Xpath of the object
							data  := Data will be taken from the Xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/
	
	public String verifyGetAttributeText(String object, String data) {
		String expected =data;
		String[] objects = object.split("#");
		APP_LOGS.debug("Verifying attribute text"); 
		try {
			WebElement attribute = driver.findElement(By.xpath(objects[0]));
			String attributeValue = attribute.getAttribute(objects[1]);
			if (attributeValue.equalsIgnoreCase(expected))
				return "PASS <br>   <B>  Expected attribute text: " + "</B>"
						+ expected + "<B>" + " Actual text: " + "</B>"
						+ attributeValue + "</br>";
			else
				return "FAIL  <br>  <B>   Expected attribute text: " + "</B>"
						+ expected + "<B>" + " Actual text: " + "</B>"
						+ attributeValue + "</br>";
			
		} catch (Exception e) {
			APP_LOGS.debug("Unable to verifying attribute text");
			return "FAIL <br> Unable to verify the attribute text " + expected + "<br>"
					+ e.getMessage().substring(0, 40) + "<B>" + "</br>";
		}
	}
	
	/*************************************************************************.
	# 21
	**************************************************************************
	'* Keyword Name         : handleAlerts
	'* Developed Date 		:
	'* Author              	: HCL
	'* Purpose              : Handling the popups 
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters  	: PASS or FAIL
	'* Usage				: handleAlerts(object, data)
							object:= Xpath of the object
							data  := Data will be taken from the Xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/
	
	public String handleAlerts(String object, String data) {
		APP_LOGS.debug("Handling the alerts");
		try {
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 2);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			alert.getText();
			// alert handling
			APP_LOGS.info("Alert detected: {}" + alert.getText());
			alert.accept();
		} catch (Exception e) {
			APP_LOGS.debug("Unable to verifying attribute text");
			return "FAIL <br> Unable to handle the Alerts<br>"
					+ e.getMessage().substring(0, 40) + "<B>" + "</br>";
		}
		return "PASS <br><B>Handle the Alerts </B></br>";
	}
	
	
	public String getTestcaseHTML(String object, String data) {
		APP_LOGS.debug("Handling the alerts");
		try {
				Desktop.getDesktop().browse(
						new File("D:\\Delete\\htmldir\\"+data).toURI());
				Thread.sleep(5000);
				Runtime.getRuntime().exec("taskkill /F /IM chrome.exe"); 
				
		} catch (Exception e) {
			APP_LOGS.debug("Unable to verifying attribute text");
			return "FAIL <br> Unable to handle the Alerts<br>"
					+ e.getMessage().substring(0, 40) + "<B>" + "</br>";
		}
		return "PASS <br><B>Handle the Alerts </B></br>";
	}
	
	public String switchToNextTab(String object, String data) {
		APP_LOGS.info("switching new tab");
		try {
			
			//TODO changes required
			/*Set<String> allWindowHandles = driver.getWindowHandles();
			for (String currentWindowHandle : allWindowHandles) {
				if (!currentWindowHandle.equals(openWindowHandle)) {
					driver.switchTo().window(currentWindowHandle);
					driver.close();
				}
			}*/
			
			ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		    driver.switchTo().window(tabs2.get(1));
		} catch (Exception e) {
			APP_LOGS.info("Unable to switching to new Tab");
			return "FAIL <br> Unable to switching to new Tab<br>"
					+ e.getMessage().substring(0, 40) + "<B>" + "</br>";
		}
		return "PASS <br><B>Switching to new Tab Successfully</B></br>";
	}
	
	public String closeChildTab(String object,String data){
		APP_LOGS.debug("closing the child window");
		try {
			
			// TODO changes required.
			/*Set<String> allWindowHandles = driver.getWindowHandles();
			for (String currentWindowHandle : allWindowHandles) {
				if (!currentWindowHandle.equals(openWindowHandle)) {
					driver.switchTo().window(currentWindowHandle);
					driver.close();
				}
			}*/
			
			ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		    driver.switchTo().window(tabs2.get(1));
		    driver.close();
		   // driver.switchTo().window(tabs2.get(0));
		} catch (Exception e) {
			APP_LOGS.debug("Unable to closing the child tab");
			return "FAIL <br> Unable to closing the child tab<br>"
					+ e.getMessage().substring(0, 40) + "<B>" + "</br>";
		}
		return "PASS <br><B>Closing the child tab success.</B></br>";
	}
	
	public String moveToParentTab(String object,String data){
		APP_LOGS.debug("closing the Parent tab");
		try {
			ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		    driver.switchTo().window(tabs2.get(0));
		} catch (Exception e) {
			APP_LOGS.debug("Unable to move to the parent tab");
			return "FAIL <br> Unable to move to the parent tab<br>"
					+ e.getMessage().substring(0, 40) + "<B>" + "</br>";
		}
		return "PASS <br><B>Moving to the parent tab success.</B></br>";
	}
	
	
	public String switchToMainTab(String object, String data) {
		APP_LOGS.debug("Handling the alerts");
		try {
			ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		    driver.switchTo().window(tabs2.get(2));
			APP_LOGS.info("Alert detected: {}");
		} catch (Exception e) {
			APP_LOGS.debug("Unable to verifying attribute text");
			return "FAIL <br> Unable to handle the Alerts<br>"
					+ e.getMessage().substring(0, 40) + "<B>" + "</br>";
		}
		return "PASS <br><B>Handle the Alerts </B></br>";
	}
	
	public String getAttributeValue(String object, String data) {
		APP_LOGS.debug("Handling the alerts");
		try {
			WebElement element = driver.findElement(By.xpath(object));
			String value = element.getAttribute("value");
			if(value.equalsIgnoreCase(data))
				return "PASS <br>   <B>  Expected text: " + "</B>"
						+ data + "<B>" + " Actual text: " + "</B>"
						+ value + "</br>";
			else
				APP_LOGS.debug("The expected and actual are not same");
				return "FAIL  <br>  <B>   Expected text: " + "</B>"
						+ value + "<B>" + " Actual text: " + "</B>"
						+ data + "</br>";
			
		} catch (Exception e) {
			APP_LOGS.debug("Unable to verifying attribute text");
			return "FAIL <br> Unable to handle the Alerts<br>"
					+ e.getMessage().substring(0, 40) + "<B>" + "</br>";
		}
	}
	
	public String selectDropDownlist(String object, String data) {
		APP_LOGS.debug("select the option from dropdown list");
		try {
			Select dropdown = new Select(driver.findElement(By.xpath(object)));
			dropdown.selectByVisibleText(data);
			return "PASS <br><B>selected option "+data +" from dropdown list </B></br>";
			
		} catch (Exception e) {
			APP_LOGS.debug("unable to selected value "+data +" from dropdown list");
			return "FAIL <br><B>unable to select value "+data +" from dropdown list "
					+ e.getMessage().substring(0, 40) + "</B></br>";
		}
	}
	
	public String selectDropDownByIndex(String object, String data) {
		APP_LOGS.debug("select the option from dropdown list");
		try {
			int index = Integer.parseInt(data);
			Select dropdown = new Select(driver.findElement(By.xpath(object)));
			dropdown.selectByIndex(index);
			return "PASS <br><B>selected option "+data +" from dropdown list </B></br>";
			
		} catch (Exception e) {
			APP_LOGS.debug("unable to selected index "+data +" from dropdown list");
			return "FAIL <br><B>unable to select index "+data +" from dropdown list "
					+ e.getMessage().substring(0, 40) + "</B></br>";
		}
	}
	
	public String addToExistingText(String object, String data) {
		APP_LOGS.debug("select the option from dropdown list");
		try {
			WebElement element = driver.findElement(By.xpath(object));
			element.sendKeys(Keys.CONTROL, Keys.HOME);
			element.sendKeys(data);
			return "PASS <br><B>selected option "+data +" from dropdown list </B></br>";
			
		} catch (Exception e) {
			APP_LOGS.debug("unable to selected index "+data +" from dropdown list");
			return "FAIL <br><B>unable to select index "+data +" from dropdown list "
					+ e.getMessage().substring(0, 40) + "</B></br>";
		}
	}

}