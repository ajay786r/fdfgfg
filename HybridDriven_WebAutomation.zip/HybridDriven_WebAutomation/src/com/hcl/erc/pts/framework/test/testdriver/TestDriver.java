package com.hcl.erc.pts.framework.test.testdriver;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.hcl.atf.taf.ConsoleWriter;
import com.hcl.erc.pts.framework.interfaces.IHtmlReporter;

/**
 * The Class is TestDriver
 * 
 */
public class TestDriver {

	public FileInputStream fisConfig = null;

	public static Properties CONFIG = null;

	public static Logger APP_LOGS = null;
	
	public IHtmlReporter report = null;

	public TestDriver() {
		APP_LOGS = Logger.getLogger(getClass());
		try {
			if (CONFIG == null) {
				APP_LOGS.info("Loading config properties");
				fisConfig = new FileInputStream(System.getProperty("user.dir")
						+ "/config/config.properties");
				CONFIG = new Properties();
				CONFIG.load(fisConfig);
			}
		} catch (FileNotFoundException fnf) {
			APP_LOGS.info("The config properties file is not found");
			fnf.printStackTrace();
		} catch (IOException ioe) {
			APP_LOGS.info("Unable to loading config properties");
			ioe.printStackTrace();
		}
	}

	/**
	 * The main method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		String testType = args[0].trim();
		String testTypeName = args[1].trim();
		String testRunId = args[2].trim();
		TestExecutionEngine.setRunListId(testRunId);

		TestDriver testDriver = new TestDriver();
		testDriver.start(testType, testTypeName);
		testDriver.end();
	}

	private void start(String testType, String testName) {
		APP_LOGS.info(getClass().getName() + "   start");
		try {
			ApplicationContext context = new FileSystemXmlApplicationContext(System.getProperty("user.dir")+CONFIG.getProperty("applicationContextPath"));
			TestExecutionEngine engine = context.getBean("testExecutionEngine",
					TestExecutionEngine.class);
			report = (IHtmlReporter) context.getBean("htmlReporter");
			report.generateHeaderReport();
			if (testType.compareToIgnoreCase("-tc") == 0) {
				engine.executeTest(testName);
			} else if (testType.compareToIgnoreCase("-suite") == 0) {
				engine.executeTestSuite(testName);
			} 
		System.out.println(ConsoleWriter.TAF.END);
		} catch (JAXBException jax) {
			jax.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void end() {
		report.generateFooterReport();
		APP_LOGS.info(getClass().getName() + "   end");
		try {
			if (fisConfig != null) {
				fisConfig.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
