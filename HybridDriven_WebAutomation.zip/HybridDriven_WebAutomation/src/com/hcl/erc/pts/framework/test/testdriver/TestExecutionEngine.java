package com.hcl.erc.pts.framework.test.testdriver;

import static com.hcl.erc.pts.framework.test.testdriver.Keywords.driver;
import static com.hcl.erc.pts.framework.test.testdriver.TestDriver.APP_LOGS;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Map.Entry;
import java.util.Set;

import javax.xml.bind.JAXBException;

import com.hcl.atf.taf.ConsoleWriter;
import com.hcl.atf.taf.TestStep;
import com.hcl.atf.taf.util.EvidenceCreation;
import com.hcl.erc.pts.framework.interfaces.IHtmlReporter;
import com.hcl.erc.pts.framework.interfaces.IPropertyConfigurer;
import com.hcl.erc.pts.framework.testcasedata.Parser;
import com.hcl.erc.pts.framework.testcasedata.Step;
import com.hcl.erc.pts.framework.testcasedata.TestCase;
import com.hcl.erc.pts.framework.testcasedata.TestData;
import com.hcl.erc.pts.framework.testcasedata.TestSteps;
import com.hcl.erc.pts.framework.util.Common;
import com.hcl.erc.pts.framework.util.EvidenceCapture;

/**
 * The Class TestExecutionEngine
 * 
 */
public class TestExecutionEngine {

	public long start;

	public long end;

	public long totalCount = 0;

	public String totalTimeCountNew = null;

	public long totalTime;

	public String totalTimenew = null;

	public long batchtotalTime;

	public String moduleTime = null;

	public String batchtotalTimenew = null;

	public boolean bResult = false;
	
	public IPropertyConfigurer iCONFIG = null;

	public int imageID = 0;
	
	public String modifiedTestcaseFile;

	public Method userDefinedMethods[];
	
//	public Method mobileUserDefinedMethod[];

	public Method genericMethods[];
	
//	public Method mobileMethods[];

	public Method capturescreenShot_method;

	public IHtmlReporter iReport;
	
	// TAF related
	public ConsoleWriter taf;
	
	public Date testStepStartTime;
	
	public String testCasePriority = "High";

	public Map<String, String> screenShots = new HashMap<String, String>();
	
	public ClassLoader classLoader = null;
	
	@SuppressWarnings("rawtypes")
	public Class keywords;

	public Object userDefinedKeywordObject;

	public String keywordsClass;
	
	public Keywords genericKeywords = null;
	
	public static String evidencePath;
	
	private static String runListId;
	
	public static String getRunListId() {
		return runListId;
	}

	public static void setRunListId(String testRunListId) {
		runListId = testRunListId;
	}

	public File file;
	
	public Properties properties;
	
	public String testStepScreenShotPath;

	public long testStepNum = 1;

	public TestExecutionEngine(String keywordsClass)
			throws InstantiationException, IllegalAccessException {

		try {
			classLoader = TestExecutionEngine.class.getClassLoader();
			keywords = classLoader.loadClass(keywordsClass);
			userDefinedKeywordObject = keywords.newInstance();
			userDefinedMethods = userDefinedKeywordObject.getClass().getMethods();
			//TAF related
			//taf = new ConsoleWriter();
			file = new File(Common.CONFIG_FILE);		
			properties  = new Properties();
			try {			
				properties.load(new FileInputStream(file));
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			evidencePath=properties.getProperty("EVIDENCE_PATH");
			
			EvidenceCreation.setdefaultTafEvidencePath(evidencePath);
			EvidenceCreation.setrunListId(getRunListId());
		} catch (ClassNotFoundException cnf) {
			cnf.printStackTrace();
		} catch (InstantiationException ie) {
			ie.printStackTrace();
		} catch (IllegalAccessException ile) {
			ile.printStackTrace();
		}
	}
	
	/**
	 * 
	 * @param genericKeywords
	 */
	public void setGenericKeywords(Keywords genericKeywords) {
		this.genericKeywords = genericKeywords;
		genericMethods = genericKeywords.getClass().getMethods();
	}

	/**
	 * @param iCONFIG
	 */
	public void setiCONFIG(IPropertyConfigurer iCONFIG) {
		this.iCONFIG = iCONFIG;
	}

	/**
	 * @param iReport
	 */
	public void setiReport(IHtmlReporter iReport) {
		this.iReport = iReport;
	}

	/**
	 * Execute suite file
	 * 
	 * @param testSuiteFile
	 * @return boolean result
	 * @throws JAXBException
	 * @throws IOException
	 * @throws InvalidTestDataException
	 */
	public boolean executeTestSuite(String testSuiteFile) throws JAXBException,
			IOException, InvalidTestDataException {
		APP_LOGS.info(getClass().getName() + "   executeTestSuite");
		List<String> testCaseList = Parser.getTestCasesList(testSuiteFile);
		for (String testCase : testCaseList) {
			bResult = executeTest(testCase);
		}
		long batchsecond1 = (totalCount / 1000) % 60;
		long batchminute1 = (totalCount / (1000 * 60)) % 60;
		long batchhour1 = (totalCount / (1000 * 60 * 60)) % 24;
		long batchdays1 = ((totalCount / (1000 * 60 * 60 * 24)) % 7);
		String bseconda1 = String.valueOf(batchsecond1);
		String bminutea1 = String.valueOf(batchminute1);
		String bhoura1 = String.valueOf(batchhour1);
		String batchdaysa1 = String.valueOf(batchdays1);
		if (bseconda1.length() == 1) {
			bseconda1 = "0" + bseconda1;
		}
		if (bminutea1.length() == 1) {
			bminutea1 = "0" + bminutea1;
		}
		if (bhoura1.length() == 1) {
			bhoura1 = "0" + bhoura1;
		}
		if (batchdaysa1.length() == 1) {
			batchdaysa1 = "0" + batchdaysa1;
		}
		totalTimeCountNew = batchdaysa1 + ":" + bhoura1 + ":" + bminutea1 + ":"
				+ bseconda1;
		APP_LOGS.info("Total batch time is " + totalTimeCountNew);
		iReport.totalTestCaseTime(totalTimeCountNew);
		return bResult;
	}

	/**
	 * Execute each testcase
	 * 
	 * @param testCaseFile
	 * @return
	 * @throws JAXBException
	 * @throws InvalidTestDataException
	 */
	public boolean executeTest(String testCaseFile) throws JAXBException,
			InvalidTestDataException {
		APP_LOGS.info(getClass().getName() + "   executeTest");
		testStepNum = 0;
		TestCase testCase = Parser.getTestCase(testCaseFile);
		APP_LOGS.info("executing the " + testCaseFile + " testcase");
		List<TestData> testDataList = testCase.getTestData();
		validateTestData(testDataList);
		TestSteps steps = testCase.getTeststeps();
		int testDataID = 0;
		for (TestData testData : testDataList) {
			// TODO 
			/*String browserName = CONFIG.getProperty("browserName");
			APP_LOGS.info("Browser Name = "+browserName);
			String URL = CONFIG.getProperty("URL");
			APP_LOGS.info("URL = " +URL);
			genericKeywords.openBrowser(URL, browserName);*/
			testDataID = testDataID + 1;
			testCaseFile = testCaseFile + "_" + testDataID;
			bResult = executeSingleTest(steps, testData, testCaseFile);
			Date date = new Date();
			long batchsecond = (batchtotalTime / 1000) % 60;
			long batchminute = (batchtotalTime / (1000 * 60)) % 60;
			long batchhour = (batchtotalTime / (1000 * 60 * 60)) % 24;
			long batchdays = ((batchtotalTime / (1000 * 60 * 60 * 24)) % 7);
			String bseconda = String.valueOf(batchsecond);
			String bminutea = String.valueOf(batchminute);
			String bhoura = String.valueOf(batchhour);
			String batchdaysa = String.valueOf(batchdays);
			
			if (bseconda.length() == 1) {
				bseconda = "0" + bseconda;
			}
			if (bminutea.length() == 1) {
				bminutea = "0" + bminutea;
			}
			if (bhoura.length() == 1) {
				bhoura = "0" + bhoura;
			}
			if (batchdaysa.length() == 1) {
				batchdaysa = "0" + batchdaysa;
			}
			batchtotalTimenew = batchdaysa + ":" + bhoura + ":" + bminutea
					+ ":" + bseconda;
			if (bResult) {
				if(testCaseFile.contains(".xml")){
					testCaseFile = testCaseFile.replace(".xml", "");
				}
				iReport.GenerateTestcaseReport(testCaseFile, "PASS",
						batchtotalTimenew);
			
				//taf.assertStep(testCaseName, testCaseDesc, testStepName, testStepDesc, testStepInput, testStepExpectedOutput, testStepObservedOutput,testStepScreenShotPath,isBrowserOpen,testStepStartTime, new Date(System.currentTimeMillis()), executionRemarks, failureReason, testStepScreenShotLabel, testCaseScriptQualifiedName, testCaseScriptFileName, testCasePriority);
				//taf.assertStep(testCaseFile, testCaseFile, "teststep","step_dec","input","output","path","totaloutput");
				batchtotalTime = 0;

			} else {
				String screenShot = screenShots.get(testCaseFile);
				if(testCaseFile.contains(".xml")){
					testCaseFile = testCaseFile.replace(".xml", "");
				}
				iReport.GenerateTestcaseReport(testCaseFile, screenShot,
						batchtotalTimenew);
				//taf.assertStep(testCaseName, testCaseDesc, testStepName, testStepDesc, testStepInput, testStepExpectedOutput, testStepObservedOutput,testStepScreenShotPath,isBrowserOpen,testStepStartTime, new Date(System.currentTimeMillis()), executionRemarks, failureReason, testStepScreenShotLabel, testCaseScriptQualifiedName, testCaseScriptFileName, testCasePriority);
				//taf.assertStep(testCaseFile, testCaseFile, "teststep", "step_dec", "input", "output", screenShot, "totalResult");
				batchtotalTime = 0;
			}
			if (testCaseFile.contains("_")) {
				int lastIndex = testCaseFile.lastIndexOf("_");
				String newTestCaseFile = testCaseFile.substring(0, lastIndex);
				testCaseFile = newTestCaseFile;
			}
		}

		return bResult;
	}

	/**
	 * 
	 * @param steps
	 * @param testData
	 * @param testCaseFile
	 * @return
	 */
	private boolean executeSingleTest(TestSteps steps, TestData testData,
			String testCaseFile) {
		APP_LOGS.info(getClass().getName() + "   executeSingleTest");
		List<Step> testSteps = steps.getTeststeps();
		Set<String> testDataKeys = testData.getKeySet();
		for (Step testStep : testSteps) {
			Map<String, String> arguments = testStep.getArguments();
			// Setting value for arguments from test Data
			for (String testDataKey : testDataKeys) {
				if (arguments.containsKey(testDataKey)) {
					arguments.put(testDataKey, testData.getValue(testDataKey));
				}
			}
			bResult = executeTestStep(testStep, testCaseFile);
			if (bResult) {
				continue;
			} else {
					//genericKeywords.closeBrowser("", "");
					break;
				
			}
		}
		return bResult;

	}

	/**
	 * Validate the testdata
	 * 
	 * @param testDataList
	 * @throws InvalidTestDataException
	 */
	private void validateTestData(List<TestData> testDataList)
			throws InvalidTestDataException {
		APP_LOGS.info(getClass().getName() + "   validateTestData");
		TestData previousTestData = testDataList.get(0);
		for (int i = 1; i < testDataList.size(); ++i) {
			TestData currentTestData = testDataList.get(i);
			if (!currentTestData.equals(previousTestData)) {
				APP_LOGS.info("Invalid the Test Data...match the previous testdata and current testdata tags");
				throw new InvalidTestDataException();
			}
			previousTestData = currentTestData;
		}

	}

	/**
	 * Execute the each test step
	 * 
	 * @param testStep
	 * @param testCaseFile
	 * @return
	 */
	private boolean executeTestStep(Step testStep, String testCaseFile) {
		APP_LOGS.info(getClass().getName() + "   executeTestStep");
		try {
			// TempActionExecutioner.executeStep(testStep);
			bResult = executeStep(testStep, testCaseFile);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bResult;

	}

	/**
	 * 
	 * @param step
	 * @param testCaseFile
	 * @return
	 * @throws IOException
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 */
	private boolean executeStep(Step step, String testCaseFile) {
		APP_LOGS.info(getClass().getName() + "   executeStep");
		try {
			String action = step.getAction();
			Map<String, String> map = step.getArguments();
			Set<Entry<String, String>> set = map.entrySet();
			Iterator<Entry<String, String>> iterator = set.iterator();
			while (iterator.hasNext()) {
				Map.Entry<String, String> keys = iterator.next();
				String key = keys.getKey();
				String object = iCONFIG.getObjectData(key);
				APP_LOGS.info("trying to find a particular "+key+" for a xpath "+object);
				String data = map.get(key);
				bResult = executeKeywords(action, object, data, testCaseFile);
			}
		} catch (NoSuchMethodException nsm) {
			nsm.printStackTrace();
			bResult = false;
		} catch (SecurityException se) {
			se.printStackTrace();
			bResult = false;
		} catch (IllegalAccessException iae) {
			iae.printStackTrace();
			bResult = false;
		} catch (InvocationTargetException ite) {
			ite.printStackTrace();
			bResult = false;
		}

		return bResult;
	}

	/**
	 * Execute keywords
	 * 
	 * @param action
	 * @param object
	 * @param data
	 * @param testCaseFile
	 * @return
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 */
	private boolean executeKeywords(String action, String object, String data,
			String testCaseFile) throws NoSuchMethodException,
			SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		APP_LOGS.info(getClass().getName() + "   executeKeywords");
		start = 0;
		end = 0;
		totalTime = 0;
		start = System.currentTimeMillis();
		Object[] parameters = { object, data };
		String keyword_execution_result = null;
		String webAction = Arrays.asList(genericMethods).toString();
		if (webAction.contains(action)) {
			APP_LOGS.info("Calling to web keywords class using reflections with action "
					+ action);
			Method method = genericKeywords.getClass().getMethod(action,
					new Class[] { String.class, String.class });
			testStepStartTime = new Date(System.currentTimeMillis());
			keyword_execution_result = (String) method.invoke(genericKeywords,
					parameters);
			APP_LOGS.info("The web keyword execution result "
					+ keyword_execution_result);

		} else {
			APP_LOGS.info("Calling to web user defined keywords class using reflections with action "
					+ action);
			Method method = userDefinedKeywordObject.getClass().getMethod(action,
					new Class[] { String.class, String.class });
			testStepStartTime = new Date(System.currentTimeMillis());
			keyword_execution_result = (String) method.invoke(
					userDefinedKeywordObject, parameters);
			APP_LOGS.info("The web user defined keyword execution result "
					+ keyword_execution_result);
		}
		Date d = new Date();
		String date = d.toString().replaceAll(" ", "_");
		date = date.replaceAll(":", "_");
		date = date.replaceAll("\\+", "_");
		String imgid = null;
		String Link = null;
		
		if (keyword_execution_result.contains("PASS")) {
			bResult = true;
			try {
				testStepScreenShotPath=EvidenceCapture.screencapture(driver,evidencePath,runListId,testCaseFile, action, testStepNum);
				testStepNum++;
			} catch (IOException e) {
				e.printStackTrace();
			}
			taf.assertStep(testCaseFile, testCaseFile, action, action, data, data, "PASS",testStepScreenShotPath,bResult,testStepStartTime, new Date(System.currentTimeMillis()), keyword_execution_result, "", "", testCaseFile, testCaseFile, testCasePriority);
		} else {
			APP_LOGS.info("Capturing the screen shot... " + action + ", "
					+ object);
			modifiedTestcaseFile = testCaseFile;
			if(testCaseFile.contains(".xml")){
				testCaseFile = testCaseFile.replace(".xml", "");
			}
			bResult = false;
			try {
				testStepScreenShotPath=EvidenceCapture.screencapture(driver,evidencePath,runListId,testCaseFile, action, testStepNum);
				testStepNum++;
			} catch (IOException e) {
				e.printStackTrace();
			}
			taf.assertStep(testCaseFile, testCaseFile, action, action, action, action, "FAIL",testStepScreenShotPath,bResult,testStepStartTime, new Date(System.currentTimeMillis()), keyword_execution_result, keyword_execution_result, keyword_execution_result, testCaseFile, testCaseFile, testCasePriority);
			capturescreenShot_method = genericKeywords.getClass().getMethod(
					"captureScreenshot", String.class, String.class);
			capturescreenShot_method.invoke(genericKeywords, testCaseFile,
					keyword_execution_result);
			Link = testCaseFile + ".png";
			imgid = testCaseFile;
			imageID = imageID + 1;
			String screenShotResult = keyword_execution_result
					+ "</br>"
					+ "  @"
					+ date
					+ "</br>"
					+ "<script type='text/javascript'>function toggleIn_"
					+ imgid
					+ "(){var id = document.getElementById('Image"
					+ imageID
					+ "');id.style.display = 'block';}function toggleOut_"
					+ imgid
					+ "(){var id = document.getElementById('Image"
					+ imageID
					+ "');id.style.display = 'none';}</script><img src="
					+ System.getProperty("user.dir")
					+ "\\screenshots\\"
					+ Link
					+ " alt='IMAGE ALT' id='Image"
					+ imageID
					+ "' width='1000' height='800' style= 'position:fixed;TOP:10px;Left:150px;display:none;'></img><div onmouseover='toggleIn_"
					+ imgid + "()' onmouseout='toggleOut_" + imgid
					+ "()'><a href=" + Link + ">Click</a></div>";
			testCaseFile = modifiedTestcaseFile;
			screenShots.put(testCaseFile, screenShotResult);
		}

		end = System.currentTimeMillis();
		totalTime = end - start;
		totalCount = totalCount + totalTime;
		long second = (totalTime / 1000) % 60;
		long minute = (totalTime / (1000 * 60)) % 60;
		long hour = (totalTime / (1000 * 60 * 60)) % 24;
		long day = ((totalTime / (1000 * 60 * 60 * 24)) % 7);
		String seconda = null;
		seconda = String.valueOf(second);
		String minutea = null;
		minutea = String.valueOf(minute);
		String houra = null;
		houra = String.valueOf(hour);
		String daya = null;
		daya = String.valueOf(day);
		if (seconda.length() == 1) {
			seconda = "0" + seconda;
		}
		if (minutea.length() == 1) {
			minutea = "0" + minutea;
		}
		if (houra.length() == 1) {
			houra = "0" + houra;
		}
		if (daya.length() == 1) {
			daya = "0" + daya;
		}
		totalTimenew = daya + ":" + houra + ":" + minutea + ":" + seconda;
		//writeToTaf.assertStep(testCaseFile, testCaseFile, action, action, data, data, data, null, bResult, startTime, endTime, null, null)
		second = 0;
		minute = 0;
		hour = 0;
		end = 0;
		start = 0;
		// To Capture Batch Execution Time
		batchtotalTime = batchtotalTime + totalTime;
		totalTime = 0;
		return bResult;
	}

}
