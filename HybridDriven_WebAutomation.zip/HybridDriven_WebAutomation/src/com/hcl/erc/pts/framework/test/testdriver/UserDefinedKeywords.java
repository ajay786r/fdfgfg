package com.hcl.erc.pts.framework.test.testdriver;

import static com.hcl.erc.pts.framework.test.testdriver.Keywords.driver;
import static com.hcl.erc.pts.framework.test.testdriver.TestDriver.APP_LOGS;
import static com.hcl.erc.pts.framework.test.testdriver.TestDriver.CONFIG;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

/**
 * 
 * the class user defined keywords
 * 
 */
public class UserDefinedKeywords {
	
	public void dymamicWait() {
		try {
			String getWaitTime;
			getWaitTime = CONFIG.getProperty("DynamicWaitTime");
			int maxWaitTime = Integer.parseInt(getWaitTime);
			for (int j = 0; j < maxWaitTime; j++) {
				String ajaxComplete = ((org.openqa.selenium.JavascriptExecutor) driver)
						.executeScript("return jQuery.active == 0").toString();
				if (ajaxComplete.equalsIgnoreCase("true")) {
					break;
				}
				Thread.sleep(1000);
			}
			for (int j = 0; j < maxWaitTime; j++) {
				String pageLoad = ((org.openqa.selenium.JavascriptExecutor) driver)
						.executeScript("return document.readyState").toString();
				if (pageLoad.equalsIgnoreCase("complete")) {
					break;
				}
				Thread.sleep(1000);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	/*************************************************************************.
	# 1
	**************************************************************************
	'* Keyword Name         : switchToIframe
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : To control the iframes
	'* Input Parameters     : object
	'* Output Parameters    : PASS or FAIL
	'* Revision History     :
	'* Usage				: Login(object, data)
							object:=Xpath of the object
							data  :=Data is not required
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	**************************************************************************/
	public String switchToIframe(String object, String data) {
	
		try {
			driver.switchTo()
					.frame(driver.findElement(By.xpath(object)))
					.switchTo()
					.frame(driver.findElement(By.xpath("//iframe[@id"
							+ "='ReportViewer1ReportFrame']")));
			driver.switchTo().activeElement();
		} catch (Exception e) {
			return "FAIL <br>" + "switchToIframe failed" + data + " in "
					+ object + "</br>";
		}
		return "PASS <br>" + "switchToIframe Passed" + data + " in " + object
				+ "</br>";

	}

	/*************************************************************************.
	# 2
	**************************************************************************
	'* Keyword Name         : Login
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : To login to the toysrus account
	'* Input Parameters     : data
	'* Output Parameters    : PASS or FAIL
	'* Revision History     :
	'* Usage				: Login(object, data)
							object:=Xpath of the object
							data  :=Data will be taken from the xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	**************************************************************************/

	public String login(String object, String data) {

		try {
			String[] objects = object.split("#");
			String[] testData = data.split("#");
			WebElement userElement = driver.findElement(By.xpath(objects[0]));
			userElement.clear();
			userElement.sendKeys(testData[0]);
			WebElement pwdElement = driver.findElement(By.xpath(objects[1]));
			pwdElement.clear();
			pwdElement.sendKeys(testData[1]);
			driver.findElement(By.xpath(objects[2])).click();
		} catch (Exception e) {
			return "FAIL <br>" + "Login Credentials fail" + data + " in "
					+ object + "</br>";
		}
		return "PASS <br>" + "Login successfully " + data + " in " + object
				+ "</br>";

	}

	/*************************************************************************.
	# 3
	**************************************************************************
	'* Keyword Name         : inVisibleElementClick
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : To identified the inVisible elements
	'* Input Parameters     : object , data
	'* Output Parameters    : PASS or FAIL
	'* Revision History     :
	'* Usage				: inVisibleElementClick(object, data)
							object:=object is required to identifying the elements
							data  :=Data will be taken from the xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	**************************************************************************/
	public String inVisibleElementClick(String object, String data) {
		try {
			WebElement element = driver.findElement(By.xpath(object));
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
			return "PASS <br>" + " successfully clicked on the" + object
					+ "</br>";

		} catch (Exception e) {
			return "FAIL <br>" + "unable to clicked on the " + object + "</br>";
		}

	}

	/*************************************************************************.
	# 4
	**************************************************************************
	'* Keyword Name         : shippingAddressDetails
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : To fill the address details
	'* Input Parameters     : object , data
	'* Output Parameters    : PASS or FAIL
	'* Revision History     :
	'* Usage				: shippingAddressDetails(object, data)
							object:=object is required to identifying the elements
							data  :=Data will be taken from the xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	**************************************************************************/
	public String shippingAddressDetails(String object, String data) {
		try {
			String[] objects = object.split("#");
			String[] testData = data.split("#");
			WebElement name = driver.findElement(By.xpath(objects[0]));
			name.sendKeys(testData[0]);
			WebElement phone = driver.findElement(By.xpath(objects[1]));
			phone.sendKeys(testData[1]);
			WebElement address = driver.findElement(By.xpath(objects[2]));
			address.sendKeys(testData[2]);
			WebElement zipcode = driver.findElement(By.xpath(objects[3]));
			zipcode.sendKeys(testData[3]);
			zipcode.sendKeys(Keys.TAB);
			Thread.sleep(2000);
			/*
			 * WebElement city = driver.findElement(By.xpath(objects[4]));
			 * city.sendKeys(testData[4]); Select select = new
			 * Select(driver.findElement(By.xpath(objects[5])));
			 * select.selectByVisibleText(testData[5]);
			 */
			return "PASS <br> Successfully entered the shipping address details </br>";
		} catch (Exception e) {
			e.printStackTrace();
			return "FAIL <br> to entered the shipping address details </br>";
		}
	}

	/*************************************************************************.
	# 5
	**************************************************************************
	'* Keyword Name         : loginEdurite
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : To login page
	'* Input Parameters     : object , data
	'* Output Parameters    : PASS or FAIL
	'* Revision History     :
	'* Usage				: loginEdurite(object, data)
							object:=object is required to identifying the elements
							data  :=Data will be taken from the xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	**************************************************************************/
	public String loginEdurite(String object, String data) {
		try {
			String[] objects = object.split("#");
			String[] testData = data.split("#");
			System.out.println(objects[0]);
			System.out.println(objects[1]);
			System.out.println(objects[2]);
			System.out.println(testData[0]);
			System.out.println(testData[1]);
			WebElement userElement = driver.findElement(By.xpath(objects[0]));
			userElement.clear();
			userElement.sendKeys(testData[0]);
			WebElement pwdElement = driver.findElement(By.xpath(objects[1]));
			pwdElement.clear();
			pwdElement.sendKeys(testData[1]);
			driver.findElement(By.xpath(objects[2])).click();
			String userNameText = driver.findElement(By.xpath(objects[3]))
					.getText();
			if (userNameText.equals(testData[2])) {
				System.out.println("LoggedIn Username Verified");
			}
		} catch (Exception e) {
			return "FAIL <br> Login to edurite credentials were failed" + data + " in " + object
					+ "</br>";
		}
		return "PASS <br> Successfully login to edurite" + data + " in " + object
				+ "</br>";

	}

	/*************************************************************************.
	# 6 {Sales force keywords}
	**************************************************************************
	'* Keyword Name         : loginToSalesforce
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : To login page
	'* Input Parameters     : object , data
	'* Output Parameters    : PASS or FAIL
	'* Revision History     :
	'* Usage				: loginEdurite(object, data)
							object:=object is required to identifying the elements
							data  :=Data will be taken from the xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	**************************************************************************/
	public String loginToSalesforce(String object, String data) {
		try {
			String[] objects = object.split("#");
			String[] testData = data.split("#");
			WebElement userElement = driver.findElement(By.xpath(objects[0]));
			userElement.clear();
			userElement.sendKeys(testData[0]);
			WebElement pwdElement = driver.findElement(By.xpath(objects[1]));
			pwdElement.clear();
			pwdElement.sendKeys(testData[1]);
			driver.findElement(By.xpath(objects[2])).click();
			driver.findElement(By.xpath(objects[3])).click();
			String userNameText = driver.findElement(By.xpath(objects[4]))
					.getText();
			if (userNameText.equals(testData[2])) {
				System.out.println("Logged Username Verified");
			}
		} catch (Exception e) {
			return "FAIL <br> Login to salesforce credentials were failed" + data + " in " + object
					+ "</br>";
		}
		return "PASS <br> Successfully Login to salesforce " + data + " in " + object
				+ "</br>";

	}

	/*************************************************************************.
	# 7 {Sales force keywords}
	**************************************************************************
	'* Keyword Name         : createNewEvent
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : To create event
	'* Input Parameters     : object , data
	'* Output Parameters    : PASS or FAIL
	'* Revision History     :
	'* Usage				: createNewEvent(object, data)
							object:=object is required to identifying the elements
							data  :=Data will be taken from the xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	**************************************************************************/
	public String createNewEvent(String object, String data) {
		try {
			String[] objects = object.split("#");
			String[] testData = data.split("#");

			driver.findElement(By.xpath(objects[0])).click();
			clickOnIT("//label[@for='it-choice']");
			driver.findElement(By.xpath(objects[1])).sendKeys(testData[0]);
			driver.findElement(By.xpath(objects[2])).sendKeys(testData[1]);
			WebElement userElement = driver.findElement(By.xpath(objects[3]));
			userElement.clear();
			userElement.sendKeys(testData[2]);
			driver.findElement(By.xpath(objects[4])).sendKeys(testData[3]);
			driver.findElement(By.xpath(objects[5])).click();
			clickOnIT("//label[@for='it-choice']");
			Assert.assertEquals(
					testData[0],
					driver.findElement(
							By.xpath("//a[text()='" + testData[0] + "']"))
							.getText());
		} catch (Exception e) {
			return "FAIL <br> Not able to create the new event </br>";
		}
		return "PASS <br> Successfully create the new event </br>";

	}

	/*************************************************************************.
	# 8 {Sales force keywords}
	**************************************************************************
	'* Keyword Name         : editEvent
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : To edit event
	'* Input Parameters     : object , data
	'* Output Parameters    : PASS or FAIL
	'* Revision History     :
	'* Usage				: editEvent(object, data)
							object:=object is required to identifying the elements
							data  :=Data will be taken from the xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	**************************************************************************/
	public String editEvent(String object, String data) {
		try {
			String[] objects = object.split("#");
			String[] testData = data.split("#");

			driver.findElement(By.xpath(objects[0])).click();
			clickOnIT("//label[@for='it-choice']");
			driver.findElement(By.xpath(objects[1])).sendKeys(testData[0]);
			driver.findElement(By.xpath(objects[2])).sendKeys(testData[1]);
			WebElement userElement = driver.findElement(By.xpath(objects[3]));
			userElement.clear();
			userElement.sendKeys(testData[2]);
			driver.findElement(By.xpath(objects[4])).sendKeys(testData[3]);
			driver.findElement(By.xpath(objects[5])).click();
			clickOnIT("//label[@for='it-choice']");
			Assert.assertEquals(
					testData[0],
					driver.findElement(
							By.xpath("//a[text()='" + testData[0] + "']"))
							.getText());
			driver.findElement(
					By.xpath("(//a[text()='" + testData[0] + "'])[1]")).click();
			clickOnIT("//label[@for='it-choice']");
			driver.findElement(By.xpath(objects[6])).click();
			clickOnIT("//label[@for='it-choice']");
			WebElement location = driver.findElement(By.xpath(objects[2]));
			location.clear();
			location.sendKeys(testData[4]);
			driver.findElement(By.xpath(objects[5])).click();
			clickOnIT("//label[@for='it-choice']");

		} catch (Exception e) {
			return "FAIL <br> Unable to edit the event </br>";
		}
		return "PASS <br> Successfully edit the event </br>";

	}

	/*************************************************************************.
	# 9 {Sales force keywords}
	**************************************************************************
	'* Keyword Name         : deleteEvent
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : To delete event
	'* Input Parameters     : object , data
	'* Output Parameters    : PASS or FAIL
	'* Revision History     :
	'* Usage				: deleteEvent(object, data)
							object:=object is required to identifying the elements
							data  :=Data will be taken from the xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	**************************************************************************/
	public String deleteEvent(String object, String data) {
		try {
			String[] objects = object.split("#");
			String[] testData = data.split("#");

			driver.findElement(By.xpath(objects[0])).click();
			clickOnIT("//label[@for='it-choice']");
			driver.findElement(By.xpath(objects[1])).sendKeys(testData[0]);
			driver.findElement(By.xpath(objects[2])).sendKeys(testData[1]);
			WebElement userElement = driver.findElement(By.xpath(objects[3]));
			userElement.clear();
			userElement.sendKeys(testData[2]);
			driver.findElement(By.xpath(objects[4])).sendKeys(testData[3]);
			driver.findElement(By.xpath(objects[5])).click();
			clickOnIT("//label[@for='it-choice']");
			Assert.assertEquals(testData[0],driver.findElement(By.xpath("//a[text()='" + testData[0] + "']")).getText());
			driver.findElement(By.xpath("(//a[text()='" + testData[0] + "'])[1]")).click();
			clickOnIT("//label[@for='it-choice']");
			driver.findElement(By.xpath(objects[6])).click();
		} catch (Exception e) {
			return "FAIL <br> Not able to delete the event </br>";
		}
		return "PASS <br> Successfully delete the event </br>";

	}

	/*************************************************************************.
	# 10 {Sales force keywords}
	**************************************************************************
	'* Keyword Name         : createContactInfo
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : To create contact information
	'* Input Parameters     : object , data
	'* Output Parameters    : PASS or FAIL
	'* Revision History     :
	'* Usage				: createContactInfo(object, data)
							object:=object is required to identifying the elements
							data  :=Data will be taken from the xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	**************************************************************************/
	public String createContactInfo(String object, String data) {
		try {
			String[] objects = object.split("#");
			driver.findElement(By.xpath(objects[0])).click();
			clickOnIT("//label[@for='it-choice']");
			driver.findElement(By.xpath(objects[1])).click();
			clickOnIT("//label[@for='it-choice']");
			
		} catch (Exception e) {
			return "FAIL <br> Not able to clicked on Contactbtn </br>";
		}
		return "PASS <br> Successfully clicked on contactbtn </br>";

	}
	private void clickOnIT(String xpath) {
		driver.findElement(By.xpath(xpath)).click();
	}
	
	/*************************************************************************.
	# 11 {New Orleans Turner keywords}
	**************************************************************************
	'* Keyword Name         : getTitlesOfTheBlocks
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : To get the titles of the blocks.
	'* Input Parameters     : object , data
	'* Output Parameters    : PASS or FAIL
	'* Revision History     :
	'* Usage				: getTitlesOfTheBlocks(object, data)
							object:=object is required to identifying the elements
							data  :=Data will be taken from the xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	**************************************************************************/
	public String getTitlesOfTheBlocks(String object, String data) {
		APP_LOGS.info("Getting the titles of the blocks.......!!!!!!!!!!!!!");
		try {
			String[] arr = data.replace("[", "").replace("]", "").split(",");
			int[] items = new int[arr.length];
			for(int i=0;i<arr.length;i++){
				items[i] = Integer.parseInt(arr[i]);
			}
			driver.findElement(By.id("nba_tos_close_button")).click();
			for(int j=0;j<items.length;j++){
				APP_LOGS.info("The title name of "+items[j]+" block is : "+driver.findElement(By.xpath("("+object+")["+items[j]+"]")).getText());
				System.out.println("The title name of "+items[j]+" block is : "+driver.findElement(By.xpath("("+object+")["+items[j]+"]")).getText());
			}
		} catch (Exception e) {
			return "FAIL <br> Not able to verify**** the 3rd,4th and 5th blocks </br>";
		}
		return "PASS <br> 3rd,4th and 5th blocks are successfully verified </br>";

	}
	
	/*************************************************************************.
	# 12 {New Orleans Turner keywords}
	**************************************************************************
	'* Keyword Name         : verifyParticularBlockInfo
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : To verify the particular block of the information
	'* Input Parameters     : object , data
	'* Output Parameters    : PASS or FAIL
	'* Revision History     :
	'* Usage				: verifyParticularBlockInfo(object, data)
							object:=object is required to identifying the elements
							data  :=Data will be taken from the xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	**************************************************************************/
	public String verifyParticularBlockInfo(String object,String data){
		APP_LOGS.info("Verifing the "+data+"");
		String[] objects = object.split("#");
		int iBlock = Integer.parseInt(data); 
		try{
			WebElement particularBlock = driver.findElement(By.xpath("("+objects[0]+")["+iBlock+"]"));
			Actions builder = new Actions(driver);
			builder.moveToElement(particularBlock).build().perform();
			boolean facebookIcon = driver.findElement(By.xpath("("+objects[1]+")["+(iBlock+1)+"]")).isEnabled();
			System.out.println("The facebook icon is on the "+iBlock+" block enable ?(True/false) : "+facebookIcon);
			boolean googlePlusIcon =driver.findElement(By.xpath("("+objects[2]+")["+(iBlock+1)+"]")).isEnabled();
			System.out.println("The google+ icon is on the "+iBlock+" block enable ?(True/false) : "+googlePlusIcon);
			boolean twitterIcon =driver.findElement(By.xpath("("+objects[3]+")["+(iBlock+1)+"]")).isEnabled();
			System.out.println("The twitter icon is on the "+iBlock+" block enable ?(True/false) : "+twitterIcon);
			boolean shareLink =driver.findElement(By.xpath("("+objects[4]+")["+(iBlock)+"]")).isEnabled();
			System.out.println("The share link is on the "+iBlock+" block enable ?(True/false) : "+shareLink);
			boolean viewLink =driver.findElement(By.xpath("("+objects[5]+")["+(iBlock)+"]")).isEnabled();
			System.out.println("The view link is on the "+iBlock+" block enable ?(True/false) : "+viewLink);
			
			driver.findElement(By.xpath("("+objects[5]+")["+(iBlock)+"]")).click();
			
		}catch(Exception e){
			return "FAIL <br> Not able to verify the particular block of the information </br>";			
		}
		return "PASS <br> Successfully verified the particular block of the information </br>";
	}
	
	/*************************************************************************.
	# 12 {New Orleans Turner keywords} 
	**************************************************************************
	'* Keyword Name         : verifyUpArrow
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : To verify the up arrow is enable or not after clicked on the down arrow
	'* Input Parameters     : object , data
	'* Output Parameters    : PASS or FAIL
	'* Revision History     :
	'* Usage				: verifyUpArrow(object, data)
							object:=object is required to identifying the elements
							data  :=Data will be taken from the xml file
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	**************************************************************************/
	public String verifyUpArrow(String object, String data) { 
		dymamicWait();
		String objects[] = object.split("#");
		try {
			WebElement element = driver.findElement(By.xpath(objects[0]));
			if(element!=null && element.isDisplayed()){
				element.click();
				boolean upArrow = driver.findElement(By.xpath(objects[1])).isEnabled();
				System.out.println("The UpArrow is enable after clicked on the downarrow.(True/false) : "+upArrow);
				List<WebElement> thumbnailList = driver.findElements(By.xpath(objects[2]));
				System.out.println("The no.of thumbnails in the 4th block : "+thumbnailList.size());
				return "PASS <br> Successfully verified the up arrow </br>";
			}else{
				List<WebElement> thumbnailList = driver.findElements(By.xpath(objects[2]));
				System.out.println("The no.of thumbnails in the 4th block : "+thumbnailList.size());
				return "PASS <br> The down arrow is not visible so uparrow also not enable </br>";
			}
		} catch (Exception e) {
			return "FAIL <br> Not able to verify the up arrow </br>";
		}
		
	}
	
	public String loginSplunkClone(String object, String data) {
		try {
			String[] objects = object.split("#");
			String[] testData = data.split("#");
			WebElement userElement = driver.findElement(By.xpath(objects[0]));
			userElement.clear();
			userElement.sendKeys(testData[0]);
			WebElement pwdElement = driver.findElement(By.xpath(objects[1]));
			pwdElement.clear();
			pwdElement.sendKeys(testData[1]);
			driver.findElement(By.xpath(objects[2])).click();
		} catch (Exception e) {
			return "FAIL <br>" + "Login Credentials fail" + data + " in "
					+ object + "</br>";
		}
		return "PASS <br>" + "Login successfully " + data + " in " + object
				+ "</br>";
	}
	
	public String mouseHoverSplunkClone(String object,String data){
		try {
			Thread.sleep(3000);
			APP_LOGS.debug("Perform Mouse Hover operation");
			String obj[] = object.split("#");
			WebElement element = driver.findElement(By.xpath(obj[0]));
			Actions builder = new Actions(driver);
			builder.moveToElement(element).moveToElement(driver.findElement(By.xpath(obj[1]))).build().perform();
			Thread.sleep(2000);
			return "PASS <br>" + " Mouse hover on the " + object
					+ " object was successful" + "</br>";
		} catch (Exception e) {
			APP_LOGS.debug("Unable to perform Mouse Hover operation");
			return "FAIL <br>" + " Unable to hover on the " + object
					+ " object -- " + e.getMessage().substring(0, 40) + "</br>";
		}
	}
	
	public String loginSymantec(String object, String data) {
		try {

			String[] objects = object.split("#");
			String[] testData = data.split("#");
			WebElement userElement = driver.findElement(By.xpath(objects[0]));
			userElement.clear();
			userElement.sendKeys(testData[0]);
			WebElement pwdElement = driver.findElement(By.xpath(objects[1]));
			pwdElement.clear();
			pwdElement.sendKeys(testData[1]);
			driver.findElement(By.xpath(objects[2])).click();
		} catch (Exception e) {
			return "FAIL <br>" + "Login Credentials fail" + data + " in "
					+ object + "</br>";
		}
		return "PASS <br>" + "Login successfully " + data + " in " + object
				+ "</br>";

	}
	
	public String loginABB(String object, String data) {
		try {

			String[] objects = object.split("#");
			String[] testData = data.split("#");
			WebElement userElement = driver.findElement(By.xpath(objects[0]));
			userElement.clear();
			userElement.sendKeys(testData[0]);
			WebElement pwdElement = driver.findElement(By.xpath(objects[1]));
			pwdElement.clear();
			pwdElement.sendKeys(testData[1]);
			driver.findElement(By.xpath(objects[2])).click();
		} catch (Exception e) {
			return "FAIL <br>" + "Login Credentials fail" + data + " in "
					+ object + "</br>";
		}
		return "PASS <br>" + "Login successfully " + data + " in " + object
				+ "</br>";

	}
	
	public String errorMsgABB(String object, String data) {
		try {
			System.out.println("111111111111111111111111111111");
			String error = driver.findElement(By.xpath(object)).getText();
			System.out.println("ERROR......................... "+error);
			if(error!=null){
				return "FAIL <br>" + "Login Credentials fail" + data + " in "
						+ object + "</br>";
			}else {
				return "PASS <br>" + "Login successfully " + data + " in " + object
						+ "</br>";
			}
		} catch (Exception e) {
			System.out.println("2222222222222222222222222222222");
			return "PASS <br>" + "error msg displayed " + data + " in " + object
					+ "</br>";
		}
		

	}
}

