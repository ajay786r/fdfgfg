package com.hcl.erc.pts.framework.testcasedata;

import static com.hcl.erc.pts.framework.test.testdriver.TestDriver.APP_LOGS;

import java.io.File;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
public class Parser {
	
	private static final String FILE_EXTENSION = ".xml";

	public static List<String> getTestCasesList(String testSuiteFile) throws JAXBException {
		APP_LOGS.info("Unmarshalling the "+testSuiteFile+"...");
		if(!testSuiteFile.endsWith(FILE_EXTENSION)) {
			testSuiteFile += FILE_EXTENSION;
		}
		File file = new File(System.getProperty("user.dir")+"/Xml_files/"+testSuiteFile);
		JAXBContext jaxbContext = JAXBContext.newInstance(TestSuite.class);
 
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		TestSuite testSuite = (TestSuite) jaxbUnmarshaller.unmarshal(file);
		
		return testSuite.getTestcases();
		
	}

	public static TestCase getTestCase(String testCaseFile) throws JAXBException {
		APP_LOGS.info("Unmarshalling the "+testCaseFile+"...");
		if(!testCaseFile.endsWith(FILE_EXTENSION)) {
			testCaseFile += FILE_EXTENSION;
		}
		File file = new File(System.getProperty("user.dir")+"//Xml_files//"+testCaseFile);
		JAXBContext jaxbContext = JAXBContext.newInstance(TestCase.class);
 
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		TestCase testCase = (TestCase) jaxbUnmarshaller.unmarshal(file);
		
		return testCase;
		
	}
	
}
