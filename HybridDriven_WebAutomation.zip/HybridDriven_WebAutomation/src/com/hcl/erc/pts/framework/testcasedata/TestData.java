package com.hcl.erc.pts.framework.testcasedata;


import java.util.Map;
import java.util.Set;

import javax.xml.bind.annotation.XmlElementWrapper;

public class TestData {

	@Override
	public boolean equals(Object testData) {
		boolean bResult = true;
		if (testData == null)
		{
			return false;
		}
		Map<String, String> testDataMap = ((TestData)testData).getTestCaseData();

		
		for(String key: testDataMap.keySet()) {
			if(!testcasedata.containsKey(key))
			{
				// key doesn't exist in given data set
				bResult = false;
			}
		}
		return bResult;
	}

	protected Map<String, String> testcasedata;
	
	@XmlElementWrapper(name="testcasedata")
	public Map<String, String> getTestCaseData() {
        return testcasedata;
    }

    public void setTestCaseData(Map<String, String> value) {
        this.testcasedata = value;
    }
    
    public Set<String> getKeySet() {
    	return testcasedata.keySet();
    }
    
    public String getValue(String key) {
    	return testcasedata.get(key);
    }
}
