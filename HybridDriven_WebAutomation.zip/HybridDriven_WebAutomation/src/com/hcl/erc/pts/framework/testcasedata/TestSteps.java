package com.hcl.erc.pts.framework.testcasedata;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class TestSteps {

	 	@XmlElement(name="step", required = true)
	  	protected List<Step> teststeps;

		public List<Step> getTeststeps() {
			return teststeps;
		}
		
		public void setTeststeps(List<Step> teststeps) {
			this.teststeps = teststeps;
		}
	 	
}
