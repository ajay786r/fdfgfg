package com.hcl.erc.pts.framework.testcasedata;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "testsuite")
@XmlAccessorType(XmlAccessType.FIELD)
public class TestSuite {

    @XmlElement(name = "testcase")
    List<String> testcases = new ArrayList<String>();

	public List<String> getTestcases() {
		return testcases;
	}

	public void setTestcases(List<String> testcases) {
		this.testcases = testcases;
	}

}
