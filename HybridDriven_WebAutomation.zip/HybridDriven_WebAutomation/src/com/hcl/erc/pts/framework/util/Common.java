/**
 * 
 */
package com.hcl.erc.pts.framework.util;

import java.io.File;

/**
 * @author indrakaran.r
 *
 */
public class Common {
	
	public static final String TAF_HOME=System.getProperty("user.home")+File.separator+"TAF";
	public static final String TAF_LIB=System.getProperty("user.home")+File.separator+"TAF"+File.separator+"lib";
	public static final String TEMP_IMAGE_PATH=System.getProperty("user.home")+File.separator+"TAF"+File.separator+"TEMP_IMG";
	
	public static final String CONFIG_FILE=TAF_HOME+File.separator+"TAF.config";
	
	public static final String HYBRID_HOME = System.getProperty("user.home")+File.separator+"HYBRID";
	

}
