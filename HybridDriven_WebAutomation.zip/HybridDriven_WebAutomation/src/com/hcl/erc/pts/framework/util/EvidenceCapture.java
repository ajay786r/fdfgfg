package com.hcl.erc.pts.framework.util;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.WebDriver;

import com.experitest.client.Client;
import com.hcl.atf.taf.util.EvidenceCreation;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

public class EvidenceCapture {	
	
	public static String captureScreenshotInSeetest(Client client, String runListId, String testCaseName, String testStepName) throws IOException{
			
		String imagePath=client.getLastCommandResultMap().get("outFile").toString();
		
		String newName=runListId+"_"+testCaseName+"_"+testStepName+"_"+"img.png";
		
		File screenshot = new File(imagePath);
		
		
		for(int i=1; i<=100000; i++) 
			if(screenshot.exists()) break;
		
		EvidenceCreation.copyScreenshotEvidence(imagePath, newName);
		
		return newName;
	}
	
	public static String captureDeviceLog(Client client) {
		
		String logPath=client.getDeviceLog();
		
		return EvidenceCreation.copyLogEvidence(logPath);
	} 

	public static String screencapture(WebDriver driver,String screenshotpath,String runListId,String testCaseName,String testStepName, long testStepNum) throws IOException {
		
		File srcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        
	    String newName=runListId+"_"+testCaseName+"_"+testStepName+"_"+testStepNum+"_"+"img.png";           
           
        File screenshot = new File(screenshotpath);
        
        for(int i=1; i<=100000; i++) 
        	if(screenshot.exists()) break;
           
        //FileUtils.copyFile(scrFile, new File("D:\\screenshot.png"));
        //FileUtils.copyFile(scrFile,new File(screenshotpath+runListId, newName));
        /**
         * Purpose : To copy the captured screenshots from the scrFile location with the filename specification.
         */
        EvidenceCreation.WebScreencapture(srcFile.toPath().toString().trim(),newName);
        
		return newName;
	}

}