package com.hcl.erc.pts.framework.util;

import static com.hcl.erc.pts.framework.test.testdriver.TestDriver.CONFIG;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

import com.hcl.erc.pts.framework.interfaces.IHtmlReporter;

public class HtmlReporter implements IHtmlReporter {
	public String browserName = CONFIG.getProperty("browserName");
	public String version = "-";
	public static BufferedWriter out = null;
	public static String result_FolderNamePath = System.getProperty("user.dir")
			+ "\\Execution_Results\\";
	public static String result_FolderName = null;
	static {
		try {
			Date d = new Date();
			String date = d.toString().replaceAll(" ", "_");
			date = date.replaceAll(":", "_");
			date = date.replaceAll("\\+", "_");
			result_FolderName = result_FolderNamePath + date.substring(0, 10)
					+ "\\ENTIRE_TEST_REPORT" + "_" + date;
			new File(result_FolderName).mkdirs();
			String indexHtmlPath = result_FolderName
					+ "\\Batch_Execution_Summary.html";
			new File(indexHtmlPath).createNewFile();
			FileWriter fstream = new FileWriter(indexHtmlPath);
			out = new BufferedWriter(fstream);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void GenerateTestcaseReport(String testcaseName, String result,
			String totalTime) {
		try {

			StringBuffer moduleresult = new StringBuffer();
			moduleresult
					.append("<tr><td width=20% align= center><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
			moduleresult.append(testcaseName);

			if(result!=null){
				if (result.contains("PASS")) {
					moduleresult
							.append("</b></td><td width=20% align= center bgcolor=GREEN><FONT COLOR=WHITE FACE= Arial  SIZE=2><b>");
					moduleresult.append(result);
					
					moduleresult
							.append("</b></td><td width=20% align= center><FONT COLOR=#153E7E FACE= Arial  SIZE=2>");
					moduleresult.append(totalTime);
					moduleresult.append("</b></td></tr>");
					out.write(moduleresult.toString());
				} else {
					moduleresult
							.append("</b></td><td width=20% align= center bgcolor=#ED4040><FONT COLOR=WHITE FACE= Arial  SIZE=2><b>");
					moduleresult.append(result);
					
					moduleresult
							.append("</b></td><td width=20% align= center><FONT COLOR=#153E7E FACE= Arial  SIZE=2>");
					moduleresult.append(totalTime);
					moduleresult.append("</b></td></tr>");
					out.write(moduleresult.toString());
				}	
			}else {
				moduleresult.append("</b></td><td width=20% align= center bgcolor=RED><FONT COLOR=WHITE FACE= Arial  SIZE=2><b>");
				moduleresult.append("The Results are not able to generating");
				moduleresult.append("</b></td></tr>");
				out.write(moduleresult.toString());
			}
		
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	public void generateHeaderReport() {
		Date d = new Date();
		String date = d.toString().replaceAll(" ", "_");
		date = date.replaceAll(":", "_");
		date = date.replaceAll("\\+", "_");
		try {
			String imageone = System.getProperty("user.dir")+"/logos/HCL_Logo.png";
			String imagetwo = System.getProperty("user.dir")+CONFIG.getProperty("clientImagePath");
			
			StringBuffer moduleresult = new StringBuffer();
			moduleresult
					.append("<html><HEAD><TITLE>Batch Execution Results</TITLE></HEAD><body><h4 align=center><FONT COLOR=660066 FACE=AriaL SIZE=6><b><u>Batch Execution Results</u></b></h4><image vspace=3 src="+ imageone + " align=left></img><image vspace=3 src=" + imagetwo + " align=right></img><br></br><table  border=1 cellspacing=1 cellpadding=1 ><tr><h4> <FONT COLOR=660000 FACE=Arial SIZE=4.5> <u>Test Details :</u></h4><td width=150 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run Date</b></td><td width=150 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>");
			moduleresult.append(d.toString());
			moduleresult
					.append("</b></td></tr><tr><td width=150 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run Environment</b></td><td width=150 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>");
			moduleresult.append(browserName);
			moduleresult
					.append("</b></td></tr><tr><td width=150 align= left  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Release</b></td><td width=150 align= left ><FONT COLOR=#153E7E FACE= Arial  SIZE=2.75><b>");
			moduleresult.append(version);
			moduleresult
					.append("</b></td></tr></table><h4> <FONT COLOR=660000 FACE= Arial  SIZE=4.5> <u>TestCase Reports :</u></h4><table  border=1 cellspacing=1 cellpadding=1 width=100%><tr><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>TESTCASE NAME</b></td><td width=20% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>RESULT</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>EXECUTION TIME</b></td></tr>");
			out.write(moduleresult.toString());
		} catch (IOException ie) {
			ie.printStackTrace();
		}

	}

	public void generateFooterReport() {
		try {

			StringBuffer moduleresult = new StringBuffer();
			moduleresult.append("</table>");
			moduleresult
					.append("<br></br><h6 align=center><FONT COLOR=#FF0000 FACE=Arial SIZE=1.5>\u00a9 Copyright 2014 HCL. All rights reserved.<br><br>Results best viewed in Google Chrome V32 and above</h6>");
			moduleresult.append("</body></html>");
			out.write(moduleresult.toString());
			out.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void totalTestCaseTime(String totalTime) {
		try{
		StringBuffer moduleresult = new StringBuffer();
		moduleresult.append("<tr><td width=20% align= center><FONT COLOR=WHITE FACE= Arial  SIZE=2><b>");
		moduleresult.append("</b></td><td width=20% align= center bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>");
		moduleresult.append("Total Execution Time");
		moduleresult.append("</b></td><td width=20% align= center bgcolor=Yellow><FONT COLOR=BLACK FACE= Arial  SIZE=2><b>");
		moduleresult.append(totalTime);
		moduleresult.append("</b></td></tr>");
		out.write(moduleresult.toString());
	} catch (IOException ie) {
		ie.printStackTrace();
	}
		
		
	}
}
