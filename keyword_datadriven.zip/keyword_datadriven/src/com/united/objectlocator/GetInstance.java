package com.united.objectlocator;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class GetInstance {
	public WebElement getInstanceObj(String object,WebDriver driver)
	{
		WebElement element = null;
		//String locator = getElementLocator(objectLogicalName);
		ObjectLocator objectLocator = new ObjectLocator();
		element = objectLocator.findElement(object,driver);
		return element;
	}
}

