package com.united.objectlocator;

import static com.united.test.DriverScript.OR;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


//import com.applabs.seleniumUtils.SeleniumServer;

public class ObjectLocator
{
	static String locatorType=null;
	public static String getLocatorType(String object){
		
		int objsize=object.lastIndexOf('_') ;
		locatorType = object.substring(objsize+1);
		
		return locatorType;
	}
	
public WebElement findElement(String object,WebDriver driver) 
	{
		WebElement element = null;
		//String locatorType=getLocatorType(object);
		/*int objsize=object.lastIndexOf('_') ;
		locatorType = object.substring(objsize+1);*/
		System.out.println("YYYYYYYYYYYYYYYY:"+locatorType);
		int counter = 1;
		try {
			if(locatorType.equalsIgnoreCase("id")){
				element = driver.findElement(By.id(OR.getProperty(object)));
			}else if(locatorType.equalsIgnoreCase("name")){
				element = driver.findElement(By.name(OR.getProperty(object)));
			}else if(locatorType.equalsIgnoreCase("linkText")){
				element = driver.findElement(By.linkText(OR.getProperty(object)));
			}else if(locatorType.equalsIgnoreCase("xpath")){
				element = driver.findElement(By.xpath(OR.getProperty(object)));
			}
			while ((element == null) && (counter < 15)) {
				//Thread.sleep(ApplicationConstants.minTimeoutMS);
				if(locatorType.equalsIgnoreCase("id")){
					element = driver.findElement(By.id(OR.getProperty(object)));
				}else if(locatorType.equalsIgnoreCase("name")){
					element = driver.findElement(By.name(OR.getProperty(object)));
				}else if(locatorType.equalsIgnoreCase("linkText")){
					element = driver.findElement(By.linkText(OR.getProperty(object)));
				}else if(locatorType.equalsIgnoreCase("xpath")){
					element = driver.findElement(By.xpath(OR.getProperty(object)));
				}
				counter++;
			}
		} catch (Exception exception) {
			
		}
		return element;
	}}