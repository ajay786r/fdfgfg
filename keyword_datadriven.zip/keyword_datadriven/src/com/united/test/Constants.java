package com.united.test;

/**
 * The Class Constants.
 */
public class Constants {

	/** The test suite sheet. */
	public static String TEST_SUITE_SHEET = "Test Suite";

	/** The Test_ suite_ id. */
	public static String Test_Suite_ID = "TSID";

	/** The runmode yes. */
	public static String RUNMODE_YES = "Y";

	/** The test cases sheet. */
	public static String TEST_CASES_SHEET = "Test Cases";

	/** The runmode. */
	public static String RUNMODE = "Runmode";

	/** The tcid. - Test Case ID */
	public static String TCID = "TCID";

	/** The test steps sheet. */
	public static String TEST_STEPS_SHEET = "Test Steps";

	/** The TES t_ step s_ data. */
	public static String TEST_STEPS_Data = "Test Data";

	/** The keyword. */
	public static String KEYWORD = "Keyword";

	/** The keyword pass. */
	public static String KEYWORD_PASS = "PASS";

	/** The keyword fail. */
	public static String KEYWORD_FAIL = "FAIL";

	/** The result. */
	public static String RESULT = "Result";

	/** The keyword skip. */
	public static String KEYWORD_SKIP = "SKIP";

	/** The data. */
	public static String DATA = "Data";

	/** The object. */
	public static String OBJECT = "Object";

	/** The data start col. */
	public static String DATA_START_COL = "col";

	/** The data split. */
	public static String DATA_SPLIT = "\\|";

	/** The positive data. */
	public static Object POSITIVE_DATA = "Y";

	/** The random value. */
	public static Object RANDOM_VALUE = "Random_Value";

	/** The config. */
	public static String CONFIG = "config";

	/** The iteration. */
	public static String ITERATION = "Iteration";

	/** The Proceed yn. */
	public static String ProceedYN = "Proceed_on_Fail";

	/** The Constant SUITE_ID. */
	public static final String SUITE_ID = "TSID";

	/** The Constant DESCRIPTION. */
	public static final String DESCRIPTION = "Description";

	/** The Constant BrowserType. */
	public static final String BrowserType = "browserType";

	/** The Constant BrowserName. */
	public static final String BrowserName = "ExecutedBrowserList";

	/** The Constant ExecutionTime. */
	public static final String ExecutionTime = "ExecutionTime";

	/** The Constant ExecutionStatus. */
	public static final String ExecutionStatus = "ExecutionStatus";

	/** The Constant AlmUpdate. */
	public static final String AlmUpdate = "AlmUpdate";

	/** The Constant ALMTCID. */
	public static final String ALMTCID = "TCID_P";

	/** The Constant TestSetID. */
	public static final String TestSetID = "TestSetID_L";

	/** The Constant CycleID. */
	public static final String CycleID = "CycleID_L";

	/** The Constant InstanceID. */
	public static final String InstanceID = "InstanceID_L";

	/** The Constant ConfigID. */
	public static final String ConfigID = "ConfigID_P";

	/** The Constant ALMStatus. */
	public static final String ALMStatus = "ALMUpdateStatus";

}
