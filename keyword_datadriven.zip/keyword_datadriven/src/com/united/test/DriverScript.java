/*
 * 
 */
package com.united.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
//import java.util.Random;

import org.apache.log4j.Logger;
import com.united.xls.read.Xls_Reader;
import com.united.util.*;
import com.united.test.Keywords;

// TODO: Auto-generated Javadoc
/**
 * The Class DriverScript.
 */
public class DriverScript {

	//Variable declaration for the APP_Logs and Xls_Reader

	/** The app logs. */
	public static Logger APP_LOGS;

	/** The suite xls. */
	public Xls_Reader suiteXLS;

	/** The current suite id. - where Modules kept for execution  */
	public int currentSuiteID;

	/** The current test suite. - Current module for execution */
	public String currentTestSuite;

	/** The current test suite xls. Test cases related to the CurrentTestSuite*/
	public static Xls_Reader currentTestSuiteXLS;

	/** The current test case id. - Current executing test case ID*/
	public static int currentTestCaseID;

	/** The current test case name. - Current executing test case name */
	public static String currentTestCaseName;

	/** The currentsuitedes. - Description of the current test suite */
	public static String currentsuitedes;

	/** The currentrunmode. */
	public static int currentrunmode;

	/** The current test step id. - Current executing test step id*/
	public static int currentTestStepID;

	/** The Proceed yn.  - Proceed yes or no for the current step*/
	public static int ProceedYN;

	/** The current keyword. Current executing keyword */
	public static String currentKeyword;

	/** The current test data set id. Current executing test data id*/
	public static int currentTestDataSetID = 2;

	/** The method. */
	public static Method[] method;

	/** The capturescreen shot_method. - To capture the screenshot */
	public static Method capturescreenShot_method;

	/** The keywords. - To access keywords file */
	public static Keywords keywords;

	/** The report util. - To access reportutil file */
	public static ReportUtil reportUtil;

	/** The keyword_execution_result. - Execution result for the current executed keyword pass or fail */
	public static String keyword_execution_result;

	/** The result set. */
	public static ArrayList<String> resultSet;

	/** The data. - data is used as a parameter for the methods in the keywords file */
	public static String data;

	/** The object. - object is used as a parameter for the methods in the keywords file */
	public static String object;

	/** The image id. - ID of the screenshot  */
	public static int imageID = 0;

	/** The Constant REQUIRE_WINDOW_FOCUS. */
	public static final boolean REQUIRE_WINDOW_FOCUS = true;

	private static final String Null = null;

	/** The Browser name. - execution of current browser */
	public String BrowserName;

	/** The config. - To access the config properties file */
	public static Properties CONFIG;

	/** The or. - To access OR properties file */
	public static Properties OR;

	/** The dataclear. */
	public int dataclear = 0;

	/** The start. - Start time of the current executing test case */
	public static long start;

	/** The end. - End time of the current executing test case */
	public static long end;

	/** The total time. total time of the test case execution = end - start */
	public static long totalTime;

	/** The total timenew. */
	public String totalTimenew = null;

	/** The batchtotal time. Total time required for the batch execution*/
	public static long batchtotalTime;

	/** The batchtotal timenew. */
	public String batchtotalTimenew = null;

	/**
	 * Instantiates a new driver script.
	 *
	 * @throws NoSuchMethodException the no such method exception
	 * @throws SecurityException the security exception
	 */
	public DriverScript() throws NoSuchMethodException, SecurityException {
		keywords = new Keywords();
		method = keywords.getClass().getMethods();
		capturescreenShot_method = keywords.getClass().getMethod("captureScreenshot", String.class, String.class);
	}

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 * @throws IllegalAccessException the illegal access exception
	 * @throws IllegalArgumentException the illegal argument exception
	 * @throws InvocationTargetException the invocation target exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws NoSuchMethodException the no such method exception
	 * @throws SecurityException the security exception
	 */
	public static void main(final String[] args) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, NoSuchMethodException, SecurityException {

		//Creation of FileInputStream object to Fetch required values from config.properties
		FileInputStream fs = new FileInputStream(System.getProperty("user.dir") + "//src//com//united//config//config.properties");
		CONFIG = new Properties();
		CONFIG.load(fs);

		//Creation of FileInputStream object to Fetch required values from or.properties
		fs = new FileInputStream(System.getProperty("user.dir") + "//src//com//united//config//or.properties");
		OR = new Properties();
		OR.load(fs);

		//Creation of object to access the DriverScript class
		DriverScript test = new DriverScript();
		test.start();
	}

	/**
	 * Start.
	 *
	 * @throws IllegalAccessException the illegal access exception
	 * @throws IllegalArgumentException the illegal argument exception
	 * @throws InvocationTargetException the invocation target exception
	 * @throws NoSuchMethodException the no such method exception
	 * @throws SecurityException the security exception
	 * @throws IOException 
	 */
	public final void start() throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, IOException {

		/* Initialize the APP_Logs */
		APP_LOGS = Logger.getLogger(DriverScript.class.getName());
		APP_LOGS.info("Hello");
		APP_LOGS.info("Properties loaded. Starting testing");
		APP_LOGS.info("Intialize Suite xlsx");
		suiteXLS = new Xls_Reader(System.getProperty("user.dir") + "//src//com//united//xls//UnitedSuite.xlsx");
		for (currentSuiteID = 2; currentSuiteID <= suiteXLS.getRowCount(Constants.TEST_SUITE_SHEET); currentSuiteID++) {
			//Check the RunMode of each Module
			APP_LOGS.info(suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.Test_Suite_ID, currentSuiteID) + " -- " +  suiteXLS.getCellData("Test Suite", "Runmode", currentSuiteID));
			currentTestSuite = suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.Test_Suite_ID, currentSuiteID);
			currentsuitedes = suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.DESCRIPTION, currentSuiteID);
			currentrunmode = currentSuiteID;

			//Test suite name = test suite xlsx file having test cases
			currentTestSuite = suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.Test_Suite_ID, currentSuiteID);
			if (suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.RUNMODE, currentSuiteID).equals(Constants.RUNMODE_YES)) {

				//Execute the test cases in the suite
				APP_LOGS.info("******Executing the Suite******" + suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.Test_Suite_ID, currentSuiteID));
				currentTestSuiteXLS = new Xls_Reader(System.getProperty("user.dir") + "//src//com//united//xls//" + currentTestSuite + ".xlsx");
				APP_LOGS.info("Test Steps Count:"+currentTestSuiteXLS.getColumnCount(Constants.TEST_STEPS_SHEET));
				if (currentTestSuiteXLS.getColumnCount(Constants.TEST_STEPS_SHEET) > 7) {

					//To delete existing Result columns
					for (int c = 8; c <= currentTestSuiteXLS.getColumnCount(Constants.TEST_STEPS_SHEET); c++) {
						currentTestSuiteXLS.removeColumn(Constants.TEST_STEPS_SHEET, c);
					}
				}

				//To get the active rows count of the test cases sheet
				int activeRows = currentTestSuiteXLS.getRowCount(Constants.TEST_CASES_SHEET);
				
				APP_LOGS.info("Active rows countt:"+activeRows);

				//To delete existing Browser data and Execution Time
				if (dataclear == 0) {
					for (int activerow = 2; activerow <= activeRows; activerow++) {
						currentTestSuiteXLS.setCellData(Constants.TEST_CASES_SHEET, Constants.BrowserName, activerow, "");
						currentTestSuiteXLS.setCellData(Constants.TEST_CASES_SHEET, Constants.ExecutionTime, activerow, "");
						currentTestSuiteXLS.setCellData(Constants.TEST_CASES_SHEET, Constants.ExecutionStatus, activerow, "");
						currentTestSuiteXLS.setCellData(Constants.TEST_CASES_SHEET, Constants.ALMStatus, activerow, "");
					}
					dataclear = dataclear + 1;
				}

				//Iterate through all the test cases in the suite
					for (currentTestCaseID = 2; currentTestCaseID <= currentTestSuiteXLS.getRowCount(Constants.TEST_CASES_SHEET); currentTestCaseID++) {
						BrowserName = "";
						APP_LOGS.info(currentTestSuiteXLS.getCellData(Constants.TEST_CASES_SHEET, Constants.TCID, currentTestCaseID) + " -- " + currentTestSuiteXLS.getCellData("Test Cases", "Runmode", currentTestCaseID));
						currentTestCaseName = currentTestSuiteXLS.getCellData(Constants.TEST_CASES_SHEET, Constants.TCID, currentTestCaseID);

						if (currentTestSuiteXLS.getCellData(Constants.TEST_CASES_SHEET, Constants.RUNMODE, currentTestCaseID).equals(Constants.RUNMODE_YES)) {
							APP_LOGS.info("Executing the test case -> " + currentTestCaseName);
							if (currentTestSuiteXLS.isSheetExist(currentTestCaseName)) {
								//RUN as many times as number of test data sets with Runmode Y
								for (currentTestDataSetID = 2; currentTestDataSetID <= currentTestSuiteXLS.getRowCount(currentTestCaseName); currentTestDataSetID++) {
									APP_LOGS.info("Iteration number " + (currentTestDataSetID - 1));

									//Check the Runmode for the current data set
									if (currentTestSuiteXLS.getCellData(currentTestCaseName, Constants.RUNMODE, currentTestDataSetID).equals(Constants.RUNMODE_YES)) {

										//Iterating through all keywords
										String colName = Constants.RESULT + (currentTestDataSetID - 1);
										boolean isColExist = false;
										for (int c = 0; c < currentTestSuiteXLS.getColumnCount(Constants.TEST_STEPS_SHEET); c++) {
											if (currentTestSuiteXLS.getCellData(Constants.TEST_STEPS_SHEET, c , 1).equals(colName)) {
												isColExist = true;
												break;
											}
										}
										if (!isColExist) {
											currentTestSuiteXLS.addColumn(Constants.TEST_STEPS_SHEET, colName);
										}

										//To append Browser Name on each iteration to ExecutedBrowserList column in the Test Suite sheet
										String browsertemp = currentTestSuiteXLS.getCellData(currentTestCaseName, Constants.BrowserType, currentTestDataSetID);
										if (browsertemp.indexOf(BrowserName) >= 0) {
											BrowserName = browsertemp;
											currentTestSuiteXLS.setCellData(Constants.TEST_CASES_SHEET, Constants.BrowserName, currentTestCaseID, BrowserName);
										}
										else {
											BrowserName = BrowserName + "<br></br>" + currentTestSuiteXLS.getCellData(currentTestCaseName, Constants.BrowserType, currentTestDataSetID);
											currentTestSuiteXLS.setCellData(Constants.TEST_CASES_SHEET, Constants.BrowserName, currentTestCaseID, BrowserName);
										}
										executeKeywords(colName); //Iterating through all keywords

										//To append Execution Time on each iteration to ExecutionTime column in the Test Suite sheet
										String timetemp = currentTestSuiteXLS.getCellData(Constants.TEST_CASES_SHEET, Constants.ExecutionTime, currentTestCaseID);
										if (!(timetemp.equalsIgnoreCase(""))) {
											timetemp = timetemp + "<br></br>" + totalTimenew;
											currentTestSuiteXLS.setCellData(Constants.TEST_CASES_SHEET, Constants.ExecutionTime, currentTestCaseID, timetemp);
										}
										else {
											currentTestSuiteXLS.setCellData(Constants.TEST_CASES_SHEET, Constants.ExecutionTime, currentTestCaseID, totalTimenew);
										}
									}
								}
							}
							else {
								//Iterating through all keywords
								String colName = Constants.RESULT + (currentTestDataSetID - 1);
								boolean isColExist = false;
								for (int c = 0; c < currentTestSuiteXLS.getColumnCount(Constants.TEST_STEPS_SHEET); c++) {
									if (currentTestSuiteXLS.getCellData(Constants.TEST_STEPS_SHEET, c , 1).equals(colName)) {
										isColExist = true;
										break;
									}
								}
								if (!isColExist) {
									currentTestSuiteXLS.addColumn(Constants.TEST_STEPS_SHEET, colName);
								}

								executeKeywords(colName); //No data with the test
							}
					}
				}
			}
		}
		
		//Take the backup of Results in a different location/
		String fileLocationSourceNetwork = System.getProperty("user.dir") + "/src/com//united//xls//" + currentTestSuite + ".xlsx";
		Date d = new Date();
		String date = d.toString().replaceAll(" ", "_");
		date = date.replaceAll(":", "_");
		date = date.replaceAll("\\+", "_");
		String fileLocationDestination = System.getProperty("user.dir") + "//src//com//united//xls//Result_Files//" + currentTestSuite + date + ".xlsx";
		copyFile(fileLocationSourceNetwork, fileLocationDestination);

		// Generate report and send E-mail
		ReportUtil util = new ReportUtil();

		//Capture Batch Execution Time
		long batchsecond = (batchtotalTime / 1000) % 60;
		long batchminute = (batchtotalTime / (1000 * 60)) % 60;
		long batchhour = (batchtotalTime / (1000 * 60 * 60)) % 24;
		long batchdays = ((batchtotalTime / (1000 * 60 * 60 * 24)) % 7);
		String bseconda = String.valueOf(batchsecond);
		String bminutea = String.valueOf(batchminute);
		String bhoura = String.valueOf(batchhour);    
		String batchdaysa = String.valueOf(batchdays);
		if (bseconda.length() == 1) {
			bseconda = "0" + bseconda;
		}
		if (bminutea.length() == 1) {
			bminutea = "0" + bminutea;
		}
		if (bhoura.length() == 1) {
			bhoura = "0" + bhoura;
		}
		if (batchdaysa.length() == 1) {
			batchdaysa = "0" + batchdaysa;
		}
		batchtotalTimenew = batchdaysa + ":" + bhoura + ":" + bminutea + ":" + bseconda;
		try {
			//Generate Entire Test Suite Execution Report
			util.GenerateReport("Generate Test Result", BrowserName, batchtotalTimenew);
			dataclear = 0;
			Runtime.getRuntime().exec("taskkill /F /IM javaw.exe");
		}
		catch (Exception e) {
			System.out.println("Unable to Generate Test Result" + e);
		}
	}

	/**
	 * Execute keywords.
	 *
	 * @param ColumnName the column name
	 * @throws IllegalAccessException the illegal access exception
	 * @throws IllegalArgumentException the illegal argument exception
	 * @throws InvocationTargetException the invocation target exception
	 * @throws NoSuchMethodException the no such method exception
	 * @throws SecurityException the security exception
	 * @throws IOException 
	 */
	public final void executeKeywords(final String ColumnName) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, IOException {
		int proceedNow = 0;
		start = 0;
		end = 0;
		totalTime = 0;
		start = System.currentTimeMillis();

		// iterating through all keywords
		for (currentTestStepID = 2; currentTestStepID <= currentTestSuiteXLS.getRowCount(Constants.TEST_STEPS_SHEET); currentTestStepID++) {

			// checking TCID
			if (currentTestCaseName.equals(currentTestSuiteXLS.getCellData(Constants.TEST_STEPS_SHEET, Constants.TCID, currentTestStepID))) {
				data = currentTestSuiteXLS.getCellData(Constants.TEST_STEPS_SHEET, Constants.DATA, currentTestStepID);
				if (data.startsWith(Constants.DATA_START_COL)) {

					// read actual data value from the corresponding column
					data = currentTestSuiteXLS.getCellData(currentTestCaseName, data.split(Constants.DATA_SPLIT)[1], currentTestDataSetID);
				}
				else if (data.startsWith(Constants.CONFIG)) {

					// read actual data value from config.properties
					data = CONFIG.getProperty(data.split(Constants.DATA_SPLIT)[1]);
				}
				else {

					// read actual data value from or.properties
					data = OR.getProperty(data);
				}
				object = currentTestSuiteXLS.getCellData(Constants.TEST_STEPS_SHEET, Constants.OBJECT, currentTestStepID);
				currentKeyword = currentTestSuiteXLS.getCellData(Constants.TEST_STEPS_SHEET, Constants.KEYWORD, currentTestStepID);
				APP_LOGS.trace(currentKeyword);

				//Code to execute the keywords as well reflection API
				Date d = new Date();
				String date = d.toString().replaceAll(" ", "_");
				date = date.replaceAll(":", "_");
				date = date.replaceAll("\\+", "_");
				Object[] parameters = {object, data };
				String imgid = Null;
				String Link = Null;

                Method method = keywords.getClass().getMethod(currentKeyword, new Class[] {String.class, String.class});
                keyword_execution_result = (String) method.invoke(keywords, parameters);
                APP_LOGS.info(keyword_execution_result);

				// capture screen shot
				if (keyword_execution_result.contains("FAIL")) {
					capturescreenShot_method.invoke(keywords, currentTestSuite + "_" + currentTestCaseName + "_TS" + currentTestStepID + "_" + (currentTestDataSetID - 1), keyword_execution_result);
					Link = currentTestSuite + "_" + currentTestCaseName + "_TS" + currentTestStepID + "_" + (currentTestDataSetID - 1) + ".png";
					imgid = currentTestSuite + "_" + currentTestCaseName + "_TS" + currentTestStepID + "_" + (currentTestDataSetID - 1);

				//Link screen shot
					imageID = imageID + 1;
					currentTestSuiteXLS.setCellData(Constants.TEST_STEPS_SHEET, ColumnName, currentTestStepID, keyword_execution_result + "</br>" + "  @" + date + "</br>" + "<script type='text/javascript'>function toggleIn_" + imgid + "(){var id = document.getElementById('Image" + imageID + "');id.style.display = 'block';}function toggleOut_" + imgid + "(){var id = document.getElementById('Image" + imageID + "');id.style.display = 'none';}</script><img src=" + Link + " alt='IMAGE ALT' id='Image" + imageID + "' width='1000' height='800' style= 'position:fixed;TOP:10px;Left:150px;display:none;'></img><div onmouseover='toggleIn_" + imgid + "()' onmouseout='toggleOut_" + imgid + "()'><a href=" + Link + ">Click</a></div>");
				}
				else {
					currentTestSuiteXLS.setCellData(Constants.TEST_STEPS_SHEET, ColumnName, currentTestStepID, keyword_execution_result + "  @" + "<br>" + date + "</br>");
				}
				if (keyword_execution_result.contains("FAIL") && (currentTestSuiteXLS.getCellData(Constants.TEST_STEPS_SHEET, Constants.ProceedYN, currentTestStepID).equalsIgnoreCase("NO"))) {
					// decide to proceed on fail or not??
					proceedNow = proceedNow + 1;
					keywords.closeBrowser("" , "");
					break;
				}
				else if (keyword_execution_result.contains("FAIL") && (currentTestSuiteXLS.getCellData(Constants.TEST_STEPS_SHEET , Constants.ProceedYN , currentTestStepID).equalsIgnoreCase("YES"))) {
					String getDes = currentTestSuiteXLS.getCellData(Constants.TEST_STEPS_SHEET , Constants.DESCRIPTION , currentTestStepID );
					String AddChar = "\"";
					currentTestSuiteXLS.setCellData(Constants.TEST_STEPS_SHEET , ColumnName,currentTestStepID , "Warning: " + "Unable to " + AddChar + getDes + AddChar + "</br>" + "  @" + date + "</br>" + "<script type='text/javascript'>function toggleIn_" + imgid + "(){var id = document.getElementById('Image" + imageID + "');id.style.display = 'block';}function toggleOut_" + imgid + "(){var id = document.getElementById('Image" + imageID + "');id.style.display = 'none';}</script><img src=" + Link + " alt='IMAGE ALT' id = 'Image" + imageID + "' width='1000' height='800' style= 'position:fixed;TOP:10px;Left:150px;display:none;'></img><div onmouseover='toggleIn_" + imgid + "()' onmouseout='toggleOut_" + imgid + "()'><a href=" + Link + ">Click</a></div>");
				}
		  	}
		}

		//To Capture Individual script Execution Time
		end = System.currentTimeMillis();
		totalTime = end - start;
		long second = (totalTime / 1000) % 60;
		long minute = (totalTime / (1000 * 60)) % 60;
		long hour = (totalTime / (1000 * 60 * 60)) % 24;
		long day = ((totalTime / (1000 * 60 * 60 * 24)) % 7);
		String seconda = null;
		seconda = String.valueOf(second);
		String minutea = null;
		minutea = String.valueOf(minute);
		String houra = null;
		houra = String.valueOf(hour);
		String daya = null;
		daya = String.valueOf(day);
		if (seconda.length() == 1) {
			seconda = "0" + seconda;
		}
		if (minutea.length() == 1) {
			minutea = "0" + minutea;
		}
		if (houra.length() == 1) {
			houra = "0" + houra;
		}
		if (daya.length() == 1) {
			daya = "0" + daya;
		}
		totalTimenew = daya + ":" + houra + ":" + minutea + ":" + seconda;
		second = 0;
		minute = 0;
		hour = 0;
		end = 0;
		start = 0;

		//To Capture Batch Execution Time
		batchtotalTime = batchtotalTime + totalTime;
		totalTime = 0;
		ReportUtil util = new ReportUtil();
		try {
			util.GenerateIndividualReport("Generate Test Result", BrowserName, currentTestCaseName, currentTestCaseID, currentTestSuite, currentsuitedes, currentrunmode, totalTimenew, currentTestDataSetID, currentTestStepID);
			DriverScript.closeAllWindows();
		}
		catch (Exception e) {
			System.out.println("Unable to Generate Individual Test Result" + e);
		}
	}

	/**
	 * Copy file.
	 *
	 * @param sourceFileName the source file name
	 * @param destionFileName the destination file name
	 */
	public static void copyFile(final String sourceFileName, final String destionFileName) {
		try {
			System.out.println("Reading..." + sourceFileName);
			File sourceFile = new File(sourceFileName);
			File destinationFile = new File(destionFileName);
			InputStream in = new FileInputStream(sourceFile);
			OutputStream out = new FileOutputStream(destinationFile);
			byte[] buffer = new byte[1024];
			int length;
			while ((length = in.read(buffer)) > 0) {
				out.write(buffer, 0, length);
			}
			in.close();
			out.close();
			System.out.println("Copied: " + sourceFileName);
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * Close all windows.
	 *
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static void closeAllWindows() throws IOException {
        String os = System.getProperty("os.name");

        if (os.contains("Windows")) {
        	Runtime.getRuntime().exec("taskkill /F /IM chrom.exe");
            Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
            Runtime.getRuntime().exec("taskkill /F /IM firefox.exe");
            Runtime.getRuntime().exec("taskkill /F /IM safari.exe");
            Runtime.getRuntime().exec("taskkill /F /IM opera.exe");
        }
        else {
            // Assuming a non Windows OS will be some version of Unix, Linux, or Mac
            Runtime.getRuntime().exec("kill `ps -ef | grep -i firefox | grep -v grep | awk '{print $2}'`");
            Runtime.getRuntime().exec("kill `ps -ef | grep -i chrome | grep -v grep | awk '{print $2}'`");
            Runtime.getRuntime().exec("kill `ps -ef | grep -i safari | grep -v grep | awk '{print $2}'`");
        }
	}

 } //End of Class