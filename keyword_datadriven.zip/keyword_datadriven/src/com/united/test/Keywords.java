package com.united.test;

import static com.united.test.DriverScript.APP_LOGS;
import static com.united.test.DriverScript.CONFIG;
import static com.united.test.DriverScript.OR;

import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.opera.core.systems.OperaDriver;
import com.united.objectlocator.GetInstance;
import com.united.objectlocator.ObjectLocator;

/**
 * The Class Keywords.
 */
public class Keywords {

	/** The Constant NULL. */
	private static final String NULL = null;

	/** The driver. */
	public WebDriver driver;

	/** The s handle before. */
	public String sHandleBefore = "";

	/** The filename. - Screen shot name */
	public String filename;

	/** The keyword_execution_result. - Execution result of the keyword */
	public String keyword_execution_result;

	/** The Expected output. */
	public String Expectedoutput = null;

	/** The browser version. - Browser version of the current executed keyword */
	public static String browserVersion;

	/** The var. */
	public static String var = null;

	/** The platform. */
	public static Platform platfrom = null;
	
	public String browserName = null;

	/**
	 * The Enum Mode.
	 */
	private enum Mode {
		    xpath, id, linkText, value, name, cssSel;
	}
	/*************************************************************************..
	*  # 1
	* ************************************************************************
	*  '* Keyword Name         : WaitForPage
	*  '* Developed Date 		 :
	*  '* Author               : HCL
	*  '* Purpose              : Wait for page load
	*  '* Input Parameters     : Xpath of the object
	*  '* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
	*  '* Revision History     :
	*  '* Usage				   : WaitForPage(object, data)
	*  						object:=Xpath of the object
	*  						data  :=data is not required
	*  **********************************************************************
	*  '* Modified	:
	*  '* Reason		:
	*  '* Date		:
	**************************************************************************/

			public String WaitForPage(String object, String data) {
				APP_LOGS.debug("To Wait for page load");
				String strResult = null;
				String objDesc = "";
				String[] textboxname = object.split("_");
	    		int objsize = textboxname.length;
	    		objDesc = textboxname[objsize-1];
				try {
					int intloopcounter = 0;
					boolean waitObject = driver.findElement(By.xpath(OR.getProperty(object))).isDisplayed();
					for (intloopcounter = 0; intloopcounter <= 7; intloopcounter++) {
						if (waitObject) {
							strResult = "TRUE";
							break;
						}
						else {
							driver.findElement(By.xpath("//body")).sendKeys(Keys.HOME);
							strResult = "FALSE";
						}
					}
				}
				catch (Exception e) {
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to wait for Page " + e.getMessage().substring(0, 40) + "</br>";
				}
				if (strResult.equalsIgnoreCase("TRUE")) {
					return Constants.KEYWORD_PASS + "<br>" + "Page loaded successfully and " + objDesc + " object was found" + "</br>";
				}
				else
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to find the " + objDesc + " object as the page load was not successful" + "</br>";
			}

	/**********************************************************************.
	# 2
	***********************************************************************
	'* Keyword Name         : waitForElement
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : To wait for the Element with the specified text
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
	'* Revision History     :
	'* Usage				: waitForElement(object, data)
							object:=Xpath of the object
							data  :=Data will be taken from the Excel sheet e.g:col|TexttoWaitFor
	'**********************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'***********************************************************************/

			public  String waitForElement(String object, String data) {
				APP_LOGS.debug("To wait for the Element with the specified text");
				String expectedval = data;
				String textverified = "false";
				String objDesc = "";
				String[] textboxname = object.split("_");
	    		int objsize = textboxname.length;
	    		objDesc = textboxname[objsize-1];
				try {
					for (long icnt = 0; icnt < 100000; icnt++) {
						String actualval = driver.findElement(By.xpath(OR.getProperty(object))).getText();
						if (actualval.contains(expectedval)) {
							textverified = "true";
							break;
						}
					}
					if (textverified == "true") {
						return Constants.KEYWORD_PASS + "<br>" + objDesc + " object with the specified text '" + data + "' is found" + "</br>";
					} else {
						return Constants.KEYWORD_FAIL + "<br>" + objDesc + " object with text '" + data + "' is not found" + "</br>";
					}
				}
				catch (Exception e) {
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to wait for Element '" + data + "'" + e.getMessage().substring(0, 40) + "</br>";
				}
			}

	/*************************************************************************..
	# 3
	***********************************************************************
	'* Keyword Name         : verifyTextWithDataAttrribute
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : To verify the text with the "data-val-required" attribute
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
	'* Revision History     :
	'* Usage				: verifyTextWithDataAttrribute(object, data)
							object:=Xpath of the object
							data  :=Data will be taken from the Excel sheet e.g:col|ExpectedText
	'**********************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'***********************************************************************/

			public String verifyTextWithDataAttrribute(String object, String data) {
				APP_LOGS.debug("To verify the text with the \"data-val-required\" attribute");
				String objDesc = "";
				String expected = data;
				String[] textboxname = object.split("_");
	    		int objsize = textboxname.length;
	    		objDesc = textboxname[objsize-1];
				try {
					if (waitUntilExists(object, "xpath")) {
						String actual = driver.findElement(By.xpath(OR.getProperty(object))).getAttribute("data-val-required");
						if (actual.equalsIgnoreCase(expected)) {
							return Constants.KEYWORD_PASS + "<br>" +  "<B>" + " Expected text: " + "</B>" + expected + "<B>" + " Actual text: "+ "</B>" + actual  + "</br>";
						} else {
							return Constants.KEYWORD_FAIL + "<br>" + "<B>" + " Expected text: " + "</B>" + expected + "<B>" + " Actual text: " + "</B>" + actual + "</br>";
						}
					} else {
						return Constants.KEYWORD_FAIL + "<br>" + objDesc +" object does not exist" + "</br>";
					}
				}
				catch (Exception e) {
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to verify the text " + expected + "<br>" + e.getMessage().substring(0, 40) + "<B>" + "</br>";
				}
			}

	/*************************************************************************.
	# 4
	**************************************************************************
	'* Keyword Name         : verifyIsEnabled
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : To verify whether button is enabled
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
	'* Revision History     :
	'* Usage				: verifyIsEnabled(object,  data)
							object:=Xpath of the object
							data  :=Data will be taken from the Excel sheet e.g:col|ExpectedValue
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/

			public String verifyIsEnabled(String object, String data) {
				APP_LOGS.debug("To verify whether button is enabled");
				String objDesc = "";
				String[] textboxname = object.split("_");
	    		int objsize = textboxname.length;
	    		objDesc = textboxname[objsize-1];
				try {
					if (waitUntilExists(object, "xpath")) {
						String temp = driver.findElement(By.xpath(OR.getProperty(object))).getAttribute("class");
						if (temp.contains("disabled") &&  data.equalsIgnoreCase("false")) {
							return Constants.KEYWORD_PASS + " <br> " + objDesc + " object is disabled"  + "</br>";
						}
						else if (!temp.contains("disabled") && data.equalsIgnoreCase("true")) {
							return Constants.KEYWORD_PASS + " <br> " + objDesc + " Object is enabled"  + "</br>";
						} 
						else {
							return Constants.KEYWORD_FAIL + " <br> " + objDesc + " Object not found or invalid data " + data + " provided"  + "</br>";
						}
					} else {
						return Constants.KEYWORD_FAIL + " <br> " + objDesc + " Object not found"  + "</br>";
					}
				}
				catch (Exception e) {
					return Constants.KEYWORD_FAIL + " <br> " + "Unable to verify whether the object " + objDesc + " is enabled" + e.getMessage().substring(0, 40)  + "</br>";
				}
			}

	/*************************************************************************.
	# 5
	**************************************************************************
	'* Keyword Name         : deleteSingleChar
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : To delete Single character in the given object
	'* Input Parameters     : Xpath of the object
	'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
	'* Revision History     :
	'* Usage				: deleteSingleChar(object,  data)
							object:=Xpath of the object
							data  :=data is not required
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/

			public  String deleteSingleChar(String object, String data) {
		        APP_LOGS.debug("Delete Single character in the given object");
		        String objDesc = "";
		        String[] textboxname = object.split("_");
	    		int objsize = textboxname.length;
	    		objDesc = textboxname[objsize-1];
		        try {
		        	if (waitUntilExists(object, "xpath")) {
		        		driver.findElement(By.xpath(OR.getProperty(object))).click();
		                driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(Keys.DELETE);
		                return Constants.KEYWORD_PASS + "<br>" + "Text between " + objDesc + " is deleted" + "</br>";
		            }
		            else
		            	return Constants.KEYWORD_FAIL + "<br>" + "Unable to delete the text for " + objDesc + " object" + "</br>";
		        }
		        catch (Exception e) {
		        	return Constants.KEYWORD_FAIL + "<br>" + "Unable to delete the text because " + e.getMessage().substring(0, 40) + "</br>"; 
		        }
			}

	/*************************************************************************.
	# 6
	**************************************************************************
	'* Keyword Name         : waitUntilExists
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Wait until the object is visible
	'* Input Parameters     : object and data
	'* Output Parameters    : true or false
	'* Revision History     :
	'* Usage				: waitUntilExists(object, mode)
							object:=object
							mode  :=To specify the Mode used for identification of the Object like xpath, ClassName, LinkText etc.
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/

			private boolean waitUntilExists(String object, String mode) throws InterruptedException {
				APP_LOGS.debug("Wait until the object is visible");
				boolean result = false;
			    Mode accessBy = Mode.valueOf(mode);
			    int count = 1;
			    while (count < 2000) {
			    	Thread.sleep(1000);
			    	switch(accessBy) {
		    	    	case xpath:
		    	    		if (driver.findElement(By.xpath(OR.getProperty(object))) != null) {
		    	    			result = true;
		    	    			count = 2000;
		    	    		}
		    	    		break;
		    	    	case id:
		    	    		if (driver.findElement(By.id(OR.getProperty(object))) != null) {
		    	    			result = true;
		    	    			count = 2000;
		    	    		}
		    	    		break;
		    	    	case linkText:
		    	    		if (driver.findElement(By.linkText(OR.getProperty(object))) != null) {
		    	    			result = true;
		    	    			count = 2000;
		    	    		}
		    	    		break;
		    	    	case name:
		    	    		if (driver.findElement(By.name(OR.getProperty(object))) != null) {
		    	    			result = true;
		    	    			count = 2000;
		    	    		}
		    	    		break;
		    	    	case cssSel:
		    	    		if (driver.findElement(By.cssSelector(OR.getProperty(object))) != null) {
		    	    			result = true;
		    	    			count = 2000;
		    	    		}
		    	    		break;
					default:
						break;
			    	}
		           count++;
			    }
			    return result;
			}

	/*************************************************************************.
	# 7
	**************************************************************************
	'* Keyword Name         : openBrowser
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Opening the browser
	'* Input Parameters     : data
	'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
	'* Revision History     :
	'* Usage				: openBrowser(object, data)
		 					object:=Not required
		 					data  :=data is taken from excel sheet e.g:col|Browser_Type	
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/

			public String openBrowser(String object, String data) {
				//String browserName = null;
				try {
				APP_LOGS.debug("Opening browser");
				
				Platform Exeplatfrom = null;
				if (data.equals("Mozilla")) {
			   		driver = new FirefoxDriver();
			   		Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
			   		browserName = caps.getBrowserName();
			   		browserVersion = caps.getVersion();
			   		var = browserVersion;
			   		Exeplatfrom = caps.getPlatform();
			   		platfrom = Exeplatfrom;
				}
				else if (data.equalsIgnoreCase("IE")) {
					File file = new File(CONFIG.getProperty("browserpathIE"));
				   	System.setProperty("webdriver.ie.driver" , file.getAbsolutePath());
				   	driver = new InternetExplorerDriver();
			   		Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
			   		browserName = caps.getBrowserName();
			   		browserVersion = caps.getVersion();
			   		var = browserVersion;
			   		Exeplatfrom = caps.getPlatform();
			   		platfrom = Exeplatfrom;
				}
				else if (data.equals("Chrome")) {
					File file = new File(CONFIG.getProperty("browserpathChrome"));
				   	System.setProperty("webdriver.chrome.driver" , file.getAbsolutePath());
				   	driver=new ChromeDriver();
			   		Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
			   		browserName = caps.getBrowserName();
			   		browserVersion = caps.getVersion();
			   		var = browserVersion;
			   		Exeplatfrom = caps.getPlatform();
			   		platfrom = Exeplatfrom;
			   	}
				else if (data.equals("Opera")) {
					DesiredCapabilities capabilities = DesiredCapabilities.opera();
					capabilities.setCapability("opera.binary" , " Absolute Path of Opera browser ");
					driver = new OperaDriver(capabilities);
					Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
					browserName = caps.getBrowserName();
					browserVersion = caps.getVersion();
					var = browserVersion;
					Exeplatfrom = caps.getPlatform();
			   		platfrom = Exeplatfrom;
				}
				else if (data.equals("Safari")) {
					driver = new SafariDriver();
			   		Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
			   		browserName = caps.getBrowserName();
			   		browserVersion = caps.getVersion();
			   		var = browserVersion;
			   		Exeplatfrom = caps.getPlatform();
			   		platfrom = Exeplatfrom;
				}
				driver.manage().window().maximize();			
				long implicitWaitTime = Long.parseLong(CONFIG.getProperty("implicitwait"));
				driver.manage().timeouts().implicitlyWait(implicitWaitTime, TimeUnit.SECONDS);
				return Constants.KEYWORD_PASS + "<br>" + "Sucessfully opened the browser "+"<FONT COLOR=0000FF>" + "<B>  Browser = </B>" + "<B>" + browserName + "</B>" + " ,<B> Version = " + "</B>" + "<B>" + browserVersion + "</B>" + "</br>" + "</FONT>";
			}
				catch (Exception e) {
					return Constants.KEYWORD_FAIL + "<br>"+ "Unable to Open "+ browserName +"-"+ browserVersion + " Brower" + e.getMessage().substring(0, 40)+ "</br>";
				}	
			}	

	/*************************************************************************.
	# 8
	**************************************************************************
	'* Keyword Name         : CaptureSID_NewSite
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Captures the SID of the New United.com Site
	'* Input Parameters     : Browser Object and data
	'* Output Parameters    : Constants.KEYWORD_PASS along with SID for the Browser or Constants.KEYWORD_FAIL
	'* Revision History     :
	'* Usage				: CaptureSID_NewSite(object, data)
			 				object:=Browser Object
			 				data  :=data is not required
	'**************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'***************************************************************************/

			public  String CaptureSID_NewSite(String object, String data) {
				APP_LOGS.debug("Captures the SID of the New United.com Site");
				String objDesc = "";
				String[] textboxname = object.split("_");
	    		int objsize = textboxname.length;
	    		objDesc = textboxname[objsize-1];
				try {
					//Thread.sleep(10000);
					//AlertsHandling("" , "The page encountered an error processing your request.");
					int maxWaitTime = 60;
					for (int j = 0; j < maxWaitTime; j++) {
						if (driver.findElement(By.xpath("//*[@id='oo_invitation_prompt']")).isDisplayed()) {
							driver.findElement(By.xpath("//*[@id='oo_no_thanks']")).click();
							break;
						}
						Thread.sleep(1000);
					}
					if (waitUntilExists(object, "xpath")) {
						String SID = driver.getPageSource();
						int SIDOccurrence = SID.indexOf("Session" , 1);
						int SIDEnd = SID.indexOf("\" ,\"LangCode\"" , 1);
						String SIDValue = SID.substring(SIDOccurrence, SIDEnd);
						return Constants.KEYWORD_PASS + "<br>" + "Session ID of this transaction is: " + "\"" + "<B>" + SIDValue + "<B>\"" + "</br>";
					}
					else
				       	return Constants.KEYWORD_FAIL + "<br>" + "Could not find the " + objDesc + " or Application" + "</br>";
				}
				catch (Exception e) {
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to Capture session ID " + e.getMessage().substring(0, 40) + "</br>";
				}
			}

	/*************************************************************************.
	# 9
	**************************************************************************
	'* Keyword Name         : DeleteCookies
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Delete the Browser Cookies
	'* Input Parameters     : NA
	'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
	'* Revision History     :
	'* Usage				: DeleteCookies(object, data)
				 			object:=Not required
				 			data  :=Not required
	'**************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'***************************************************************************/

			public  String DeleteCookies(String object, String data) {
				APP_LOGS.debug("Delete the Browser Cookies"); 
		        try {
		        	Set<Cookie> cookies = driver.manage().getCookies();
		        	System.out.print("Total Cookies " + cookies.size());
		        	java.util.Iterator<Cookie>  itr = cookies.iterator();
		        	while (itr.hasNext()) {
		        		Cookie c = itr.next();
		        		System.out.println(c.getDomain() + "" + c.getName() + "" + c.getValue());
		        		driver.manage().deleteAllCookies();
		        	}
		        }
		        catch (Exception e) {
		        	return Constants.KEYWORD_FAIL + "<br>" + "Unable to delete cookies " + e.getMessage().substring(0, 20) + "</br>";
		        }
		        return Constants.KEYWORD_PASS + "<br>" + "Browser Cookies were deleted successfully" + "</br>"; 
			}

	/*************************************************************************.
	# 10
	**************************************************************************
	'* Keyword Name         : verifyTextCss
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Verifying the CSS text 
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
	'* Revision History     :
	'* Usage				: verifyTextCss(object, data)
				 			object:=Xpath of the object
				 			data  :=data is taken from excel sheet e.g:col|Expected_CSS_Text	
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/

			public String verifyTextCss(String object, String data) {
				APP_LOGS.debug("Verifying the CSS text");
				String objDesc = "";
				String[] textboxname = object.split("_");
	    		int objsize = textboxname.length;
	    		objDesc = textboxname[objsize-1];
				try {
					if (waitUntilExists(object, "cssSel")) {
						String actual = driver.findElement(By.cssSelector(OR.getProperty(object))).getText();
					    String expected = data;
					    if (actual.equalsIgnoreCase(expected))
					    	return Constants.KEYWORD_PASS + "<br>" +  "<B>" + " Expected text: " + "</B>" + expected + "<B>" + " Actual text: "+ "</B>" + actual + "</br>";
					    else
					    	return Constants.KEYWORD_FAIL + "<br>" + "<B>" + " Expected text: " + "</B>" + expected + "<B>" + " Actual text: " + "</B>" + actual + "</br>";
					}
					else
				       	return Constants.KEYWORD_FAIL + "<br>" + objDesc + " object not found" + "</br>";
					}
				catch (Exception e) {
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to Verify text " + e.getMessage().substring(0, 20) + "</br>";
				}
			}

	/*************************************************************************.
	# 11
	**************************************************************************
	'* Keyword Name         : VerifyCalendarFutureDateIsClickable
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : To verify whether the Future Date is selectable in the Calendar
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
	'* Revision History     :
	'* Usage				: VerifyCalendarFutureDateIsClickable(object, data)
							object:=Xpath of the object
							data  :=Data will be taken from the Excel sheet e.g:col|Date
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		: 12/11/2013
	'**************************************************************************/

			public String VerifyCalendarFutureDateIsClickable(String object, String data) {
				APP_LOGS.debug("To verify whether the Future Date is selectable in the Calendar");
				String isSelected = null;
				//String objDesc = "";
				//String[] textboxname = object.split("_");
	    		//int objsize = textboxname.length;
	    		//objDesc = textboxname[objsize-1];
				try {
					if (waitUntilExists(object, "xpath")) {
						int date = Integer.parseInt(data);
						Calendar cal = Calendar.getInstance();
				        cal.setTimeZone(TimeZone.getTimeZone("GMT"));
				        cal.add(Calendar.DATE, date);
				        String newdate = cal.getTime().toString();
					    String[] dateconv = newdate.split(" ");
					    String strmonth = dateconv[1];
					    String strday = dateconv[2];
					    if (strday.startsWith("0")) {
					    	strday = strday.charAt(1) + "";
					    }
					    String stryear = dateconv[5];
					    String[] montharray = new String[]{"JANUARY" , "FEBRUARY" , "MARCH" , "APRIL" , "MAY" , "JUNE" , "JULY" , "AUGUST" , "SEPTEMBER" , "OCTOBER" , "NOVEMBER" , "DECEMBER"};
					    for (int i = 0; i < montharray.length; i++) {
					    	String strtocmp = montharray[i].substring(0, 3);
					    	if (strtocmp.equalsIgnoreCase(strmonth.toLowerCase())) {
					    		strmonth = montharray[i];
					    		break;
					    	}
					    }
					    String calmonthyear = strmonth + " " + stryear;
					    for (int j = 0; j < 12; j++) {
					    	String xpathcalendarone = "";
							xpathcalendarone = OR.getProperty(object) + "/div[1]/div/div";
							xpathcalendarone = driver.findElement(By.xpath(xpathcalendarone)).getText();
							String xpathcalendartwo = "";
							xpathcalendartwo = OR.getProperty(object) + "/div[2]/div/div";
							xpathcalendartwo = driver.findElement(By.xpath(xpathcalendartwo)).getText();
							if (xpathcalendarone.equalsIgnoreCase(calmonthyear)) {
								WebElement dateWidget = driver.findElement(By.xpath(OR.getProperty("List_HomePage_Flight_DeptDatePickone")));
								List<WebElement> columns = dateWidget.findElements(By.tagName("td"));
								for (WebElement col: columns) {
									if (col.getText().equalsIgnoreCase(strday)) {
										isSelected = col.getAttribute("class");
										isSelected = isSelected.replace(" " , "");
										if (isSelected != null && (isSelected.toLowerCase().indexOf("disabled") > 0)) {
											isSelected = "true";
											break;
										}
										else if (isSelected.equalsIgnoreCase("") || (isSelected.toLowerCase().indexOf("week-end") > 0)) {
											isSelected="false";
										}
									}
								}
							 }
							 else if (xpathcalendartwo.equalsIgnoreCase(calmonthyear)) {
								 WebElement dateWidget = driver.findElement(By.xpath(OR.getProperty("List_HomePage_Flight_DeptDatePicktwo")));
								 List<WebElement> columns = dateWidget.findElements(By.tagName("td"));
								 for (WebElement col: columns) {
									 if (col.getText().equalsIgnoreCase(strday)) {
										 isSelected = col.getAttribute("class");
										 isSelected = isSelected.replace(" " , "");
										 if (isSelected != null && (isSelected.toLowerCase().indexOf("disabled") > 0)) {
											 isSelected = "true";
											 break;
										 }
										 else if (isSelected.equalsIgnoreCase("") || (isSelected.toLowerCase().indexOf("week-end") > 0)) {
											 isSelected="false";
										 }
									 }
								 }
							 }
							 else {
								 driver.findElement(By.xpath("//*[@title='Next']")).click();
								 if(!(driver.findElement(By.xpath(OR.getProperty(object))).isDisplayed()))
								 {
									 return Constants.KEYWORD_FAIL + "<br>" + "Unable to click Next button in the Calendar widget" + "</br>";
								 }
								 isSelected = "false";
							 }
						}
					}
				}
				catch (Exception e) {
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to determine whether the given future date is clickable as" + e.getMessage().substring(0, 20) + "</br>";
				}
				if (isSelected != null && (isSelected.equalsIgnoreCase("true"))) {
					return Constants.KEYWORD_PASS + "<br>" + "Unable to Select future date of " + (Integer.parseInt(data)) + " days from the Calendar as the link is disabled" + "</br>";
				}
				else if (isSelected != null && (isSelected.equalsIgnoreCase("false"))) {
					return Constants.KEYWORD_PASS + "<br>" + "Able to select future date of " + "<b>" + (Integer.parseInt(data)) + "</b>" + " days from the Calendar" + "</br>";
				}
				else {
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to determine whether the given future date is clickable " + (Integer.parseInt(data)) + " is selectable in the Calendar" + "</br>";
				}
			}

	/*************************************************************************.
	# 12
	**************************************************************************
	'* Keyword Name         : verifyAllListItems
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Verify the all the list items
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
	'* Revision History     :
	'* Usage				: verifyAllListItems(object, data)
							object:=Xpath of the object
							data  :=Data will be taken from the Excel sheet e.g:col|ListItems_Seperatedby';'symbol
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/

			public  String verifyAllListItems(String object, String data) {
		        APP_LOGS.debug("Verify All list item details"); 
		        String objDesc = "";
		        String isExists = "";
		        String[] objname = object.split("_");
	    		int objsize = objname.length;
	    		objDesc = objname[objsize-1];
		        try {
		        	if (waitUntilExists(object, "xpath")) {
		        		WebElement trElement = driver.findElement(By.xpath(OR.getProperty(object)));
		                String[] aArray =  data.split("|");
		                List<WebElement> td_collection=trElement.findElements(By.xpath("li"));
		                for (WebElement tdElement : td_collection) {
		                	for (int i = 0; i < aArray.length; i++) {
		                		if (tdElement.getText().contains(aArray[i].trim())) {
		                			isExists = "true"; 
		                        } 
		                        else {
		                        	isExists = "false";
		                        	break;
		                        }
		                    }
		                }
		        	}
		        	else
		        		return Constants.KEYWORD_FAIL + "</br>" + objDesc + " Dropdown List does not exist" + "</br>";
		        }
		        catch (Exception e) {
		                return Constants.KEYWORD_FAIL + "</br>" +" Unable to verify the "+ objDesc + "dropdown List item. --" + e.getMessage().substring(0, 40) + "</br>";
		        }
		        if (isExists.equalsIgnoreCase("true")) {
	            	return Constants.KEYWORD_PASS + "</br>" + "All the specified List Items are verified in the " + objDesc + "dropdown" + "</br>";
	            }
		        else {
		        	return Constants.KEYWORD_FAIL + "</br>" + data + " Items not found in the "+ objDesc + " dropdown List" + "</br>";
		        }
			}

	/*************************************************************************.
	# 13
	**************************************************************************
	'* Keyword Name         : dateCompare
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : To compare two dates. Both the dates should be in the same format
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
	'* Revision History     :
	'* Usage				: dateCompare(object, data)
							object:=Xpath of the object
							data  :=Data will be taken from the Excel sheet e.g:col|date
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/

			public String dateCompare(String object, String data) {
				APP_LOGS.debug("To compare the dates");
				String objDesc = "";
		        String[] objname = object.split("_");
	    		int objsize = objname.length;
	    		objDesc = objname[objsize-1];
				try {
					if (waitUntilExists(object, "xpath")) {
						String actual = driver.findElement(By.xpath(OR.getProperty(object))).getText();
					    String expected = data;
					    if(actual.compareTo(expected) == 0)
					    	return Constants.KEYWORD_PASS + "<br>" + "<B>" + " Expected date: " + "</B>" + expected + "<B>" + " Actual date: "+ "</B>" + actual  + "</br>";
					    else
					    	return Constants.KEYWORD_FAIL + "<br>" + "<B>" + " Expected date: " + "</B>" + expected + "<B>" + " Actual date: " + "</B>" + actual + "</br>";
					}
					else
				       	return Constants.KEYWORD_FAIL + "<br>" + objDesc + " object does not exist" + "</br>";
					}
				catch (Exception e) {
					return Constants.KEYWORD_FAIL + "<br>" + "Date Comparison was not successful as " + e.getMessage().substring(0, 40) + "</br>";
				}
			}

	/*************************************************************************.
	# 14
	**************************************************************************
	'* Keyword Name         : verifyLinkPresence
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Verify the link existence
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
	'* Revision History     :
	'* Usage				: verifyLinkPresence(object, data)
							object:=Xpath of the object
							data  :=Data will be taken from the Excel sheet e.g:col|Link_Text
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/

			public  String verifyLinkPresence(String object, String data) {
		        String isverified = "";
				APP_LOGS.debug("Verify the link existence");
				String objDesc = "";
		        String[] objname = object.split("_");
	    		int objsize = objname.length;
	    		objDesc = objname[objsize-1];
		        try {
		        	if (waitUntilExists(object, "xpath")) {
		        		// logic to find a random value in list 
		                WebElement droplist = driver.findElement(By.xpath(OR.getProperty(object)));
		                List<WebElement> tr_collection = droplist.findElements(By.tagName("li"));
		                String expected = data;
		                for (WebElement trElement : tr_collection) {
		                	String actual = trElement.getText();
		                    if (actual.equalsIgnoreCase(expected)) {
		                    	isverified = "true";
		                    }
		                    else {
		                    	isverified = "false";
		                    }
	                    }
	                } 
	                else {
	                	return Constants.KEYWORD_FAIL + "<br>" + objDesc + " object does not exist" + "</br>";
	                }
		        }
		        catch (Exception e) {
		        	return Constants.KEYWORD_FAIL + "<br>" + "Unable to verify the Link Existence " + e.getMessage().substring(0, 40) + "</br>";
		        } 
		        if (isverified.equalsIgnoreCase("true")) {
	            	return Constants.KEYWORD_PASS + "<br>" + "Verified Link " + objDesc + " with the text '" + data + "' exists" + "</br>";
	            }
	            else {
	            	return Constants.KEYWORD_FAIL + "<br>" + "Unable to verify Link " + objDesc + " with the text '" + data + "' exists" + "</br>";
	            }
			}

	/*************************************************************************.
	# 15
	**************************************************************************
	'* Keyword Name         : VerifyfontColorofSpecificDate
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Verifying font color of specific Date 
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
	'* Revision History     :
	'* Usage				: VerifyfontColorofSpecificDate(object, data)
							object:=Xpath of the object
							data  :=Data will be taken from the Excel sheet e.g:col|Date;Color
	'************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/

			public  String VerifyfontColorofSpecificDate(String object, String data) {
				APP_LOGS.debug("Verifying font color of specific Date");
			    //String objDesc = "";
		        //String[] objname = object.split("_");
	    		//int objsize = objname.length;
	    		//objDesc = objname[objsize-1];
		      try {
		    	   String ismatched = null;
		    	   String[] arrDateColor = data.split(";");
		    	   String actualcolor = null;
		    	   String actualclr = null;
		    	   WebElement dateWidget = driver.findElement(By.id("ui-datepicker-div"));
		    	   List<WebElement> columns=dateWidget.findElements(By.tagName("td"));
		    	   for (WebElement col: columns) {
		    		   if (col.getText().equals(arrDateColor[0])) {
		    			   actualclr = col.getCssValue("color"); 
		    			   actualcolor = actualclr.substring(0, 4);
		    			   if (actualcolor.equalsIgnoreCase("rgba")) {
		    				   String rgbConvert = actualclr.substring(5);
		    				   String[] arrhexVal = rgbConvert.split(", ");
		    				   int i = Integer.parseInt(arrhexVal[0]);
		    				   int j = Integer.parseInt(arrhexVal[1]);
		    				   int k = Integer.parseInt(arrhexVal[2]);
		    				   Color c = new Color(i, j, k);
		    				   actualcolor = Integer.toHexString(c.getRGB()).toString();
		    				   actualcolor = actualcolor.substring(2);
		    				   int strlen = actualcolor.length();
		    				   if (strlen == 6) {
		    					   actualclr = "";
		    					   for (int n = 1; n <= strlen; n = n + 2) {
		    						   actualclr = actualclr + actualcolor.charAt(n);
		    					   }
		    					   actualcolor = actualclr;
		    				   }
		    			   }
		    			   if (actualcolor.equalsIgnoreCase(arrDateColor[1])) {
		    				   ismatched = "True";
		    				   break;
		    			   }
		    			   else {
		    				   ismatched = "False";
		    			   }
		    		   }
		    	   }
		    	   if(ismatched != null && ismatched.equals("True")) {
		    		   return Constants.KEYWORD_PASS + "<br>" + "Font color verified." + "<B>" +  "Expected Color " + "</B>" + arrDateColor[1] + "<B>" + "Actual Color " + "</B>" + actualcolor + "</br>";
					}
					else {
						return Constants.KEYWORD_FAIL + "<br>" + "Font color not verified." + "<B>" +  "Expected Color " + "</B>" + arrDateColor[1] + "<B>" + "Actual Color " + "</B>" + actualcolor + "</br>";
					}
		      }
		      catch (Exception e) {
		    	  return Constants.KEYWORD_FAIL + "<br>" + "Error in retrieving Font color " + e.getMessage().substring(0, 40) + "</br>";
		      }
			}

	/*************************************************************************.
	# 16
	**************************************************************************
	'* Keyword Name         : writeInInput
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Writing in text box
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
	'* Revision History     :
	'* Usage				: writeInInput(object, data)
							object:=Xpath of the object
							data  :=Data will be taken from the Excel sheet e.g:col|TexttobeWritten
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/

		public  String writeInInput(String object, String data) {
	        APP_LOGS.debug("Writing in text box");
	        String objDesc = "";
	        String[] textboxname = object.split("_");
			int objsize = textboxname.length;
			objDesc = textboxname[objsize-1];
	        try {
	        	if (waitUntilExists(object, "xpath")) {
	        		driver.findElement(By.xpath(OR.getProperty(object))).clear();
	        		driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(data);
	            }
	            else
	            	return Constants.KEYWORD_FAIL + "<br>" + objDesc + " does not exist" + "</br>";
	        }
	        catch (Exception e) {
	        	return Constants.KEYWORD_FAIL + "<br>" + "Unable to write in the Input box " + e.getMessage().substring(0, 40) + "</br>";
	        }
	        return Constants.KEYWORD_PASS + "<br>" + "Entered input " + data + " in " + objDesc + "</br>";
		}

	/*************************************************************************.
	# 17
	**************************************************************************
	'* Keyword Name         : SelectCalendarDate
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Select Date from the Calendar
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
	'* Revision History     :
	'* Usage				: SelectCalendarDate(object, data)
							object:=Xpath of the object
							data  :=Data will be taken from the Excel sheet e.g:col|Date
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/

			public String SelectCalendarDate(String object, String data) {
				APP_LOGS.debug("Select Date from the Calendar");
				String objDesc = "";
		        String[] textboxname = object.split("_");
				int objsize = textboxname.length;
				objDesc = textboxname[objsize-1];
				try {
				    if (waitUntilExists(object, "xpath")) {
				    	String isSelected = null;
		  				WebElement dateWidget = driver.findElement(By.id("ui-datepicker-div"));
						List<WebElement> columns = dateWidget.findElements(By.tagName("td"));
						for (WebElement col: columns) {
							if (col.getText().equals(data)) {
								col.findElement(By.linkText(data)).click();
		   						isSelected = "True";
		   						break;
							}
						}
						if (isSelected != null && isSelected == "True") {
							return Constants.KEYWORD_PASS + "<br>" + "Selected " + data + " from the Calendar" + "</br>";
						}
						else {
							return Constants.KEYWORD_FAIL + "<br>" + "Unable to select " + data + " from the Calendar" + "</br>";
						}
					}
				    else
						return Constants.KEYWORD_FAIL + "<br>" + objDesc + " object not found" + "</br>";
				}
				catch (Exception e) {
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to find Calendar " + e.getMessage().substring(0, 40) + "</br>";
				}
			}

	/*************************************************************************.
	# 18
	**************************************************************************
	'* Keyword Name         : AutoSelectCalendarPreviousDate
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Automatically select Previous Date from the Calendar 
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
	'* Revision History     :
	'* Usage				: AutoSelectCalendarPreviousDate(String object, String data)
							object:=Xpath of the object
							data  :=Data will be taken from the Excel sheet e.g:col|PreviousDate
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/

			public String AutoSelectCalendarPreviousDate(String object, String data) {
				APP_LOGS.debug("Automatically select Previous Date from the Calendar");
				DymamicWait();
				String objDesc = "";
		        String[] textboxname = object.split("_");
				int objsize = textboxname.length;
				objDesc = textboxname[objsize-1];
			    try {
			        if (waitUntilExists(object, "xpath")) {
			        	int date = Integer.parseInt(data);
			            Calendar cal = Calendar.getInstance();
			            cal.setTimeZone(TimeZone.getTimeZone("GMT"));
		                cal.add(Calendar.DATE, date);
		                String newdate = cal.getTime().toString();
		                String[] dateconv = newdate.split(" ");
		                String strday = dateconv[2];
		                String isSelected = null;
	                    WebElement dateWidget = driver.findElement(By.xpath(OR.getProperty(object)));
		                List<WebElement> columns = dateWidget.findElements(By.tagName("td"));
		                for (WebElement col: columns) {
		                	if (col.getText().equals(strday)) {
		                		isSelected = col.getAttribute("class");
			                    isSelected = isSelected.replace(" " , "");
		                        break;
		                	}
		                }
			            if (isSelected != null && isSelected.contains("ui-datepicker-unselectableui-state-disabled")) {
			            	return Constants.KEYWORD_PASS + "<br>" + "Unable to Select " + strday + " from the Calendar as the link is disabled" + "</br>";
			            }
			            else {
			            	return Constants.KEYWORD_FAIL + "<br>" + "Selected " + strday + " from the Calendar" + "</br>";
			            }
			        }
			        else
			        	return Constants.KEYWORD_FAIL + "<br>" + objDesc + " object not found" + "</br>";
			    }
			    catch (Exception e) {
			    	return Constants.KEYWORD_FAIL + "<br>" + "Unable to find the Calendar " + e.getMessage().substring(0, 40) + "</br>";
			    }
			}

	/*************************************************************************.
	# 19
	**************************************************************************
	'* Keyword Name         : VerifyBackColorofDateSelected
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Verifying background color of the Date Selected
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
	'* Revision History     :
	'* Usage				: VerifyBackColorofDateSelected(object, data)
							object:=Xpath of the object
							data  :=Data will be taken from the Excel sheet e.g:col|Date;Color
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/
			public  String VerifyBackColorofDateSelected(String object, String data) {
				APP_LOGS.debug("Verifying background color of the Object");
				//String objDesc = "";
		        //String[] textboxname = object.split("_");
				//int objsize = textboxname.length;
				//objDesc = textboxname[objsize-1];
			    try {
			    	String ismatched = null;
			    	String[] arrDateColor = data.split(";");
			    	String actualcolor = null;
			    	String actualclr = null;
			    	WebElement dateWidget = driver.findElement(By.id("ui-datepicker-div"));
					List<WebElement> columns = dateWidget.findElements(By.tagName("td"));
					for (WebElement col: columns) {
						if (col.getText().equals(arrDateColor[0])) {
							actualclr = col.findElement(By.linkText(arrDateColor[0])).getCssValue("background-color");
							actualcolor = actualclr.substring(0, 4);
							if (actualcolor.equalsIgnoreCase("rgba")) {
								String rgbConvert = actualclr.substring(5);
								String[] arrhexVal = rgbConvert.split(", ");
								int i = Integer.parseInt(arrhexVal[0]);
								int j = Integer.parseInt(arrhexVal[1]);
								int k = Integer.parseInt(arrhexVal[2]);
								Color c = new Color(i, j, k);
								actualcolor = Integer.toHexString(c.getRGB()).toString();
								actualcolor = actualcolor.substring(2);
								int strlen = actualcolor.length();
								if (strlen == 6) {
									actualclr = "";
									for (int n = 1; n <= strlen; n = n + 2) {
										actualclr = actualclr + actualcolor.charAt(n);
									}
									actualcolor = actualclr;
								}
							}
							if (actualcolor.equalsIgnoreCase(arrDateColor[1])) {
								ismatched = "True";
								break;
							}
							else {
								ismatched = "False";
							}
						}
					}
					if (ismatched != null && ismatched.equals("True")) {
						return Constants.KEYWORD_PASS + "<br>" + "Background color verified." + "<B>" +  "Expected Color " + "</B>" + arrDateColor[1] + "<B>" + "Actual Color " + "</B>" + actualcolor + "</br>";
					}
					else {
						return Constants.KEYWORD_FAIL + "<br>" + "Background color not verified." + "<B>" +  "Expected Color " + "</B>" + arrDateColor[1] + "<B>" + "Actual Color " + "</B>" + actualcolor + "</br>";
					}
		   		}
			    catch (Exception e) {
			    	return Constants.KEYWORD_FAIL + "<br>" + "Error in retrieving Background color " + e.getMessage().substring(0, 40) + "</br>";
				}
			}

	/*************************************************************************.
	# 20
	**************************************************************************
	'* Keyword Name         : monthandyearcomparision
	'* Developed Date 		:
	'* Author               : HCL
	'* Purpose              : Verifies the month and year
	'* Input Parameters     : Xpath of the object and data
	'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
	'* Revision History     :
	'* Usage				: monthandyearcomparision(object, data)
							object:=Xpath of the object
							data  :=Data will be taken from the Excel sheet e.g:col|No.of Days to be incremented;True or False
	'*************************************************************************
	'* Modified	:
	'* Reason	:
	'* Date		:
	'**************************************************************************/

			public String monthandyearcomparision(String object, String data)throws IOException {
				APP_LOGS.debug("Verifying all the list elements");
				String objDesc = "";
		        String[] textboxname = object.split("_");
				int objsize = textboxname.length;
				objDesc = textboxname[objsize-1];
				try {
					if (waitUntilExists(object, "xpath")) {
						boolean isExists = false;
						WebElement droplist = driver.findElement(By.xpath(OR.getProperty(object)));
						List<WebElement> droplist_cotents = droplist.findElements(By.tagName("option"));
						// extract the expected values from OR. properties
						String temp = data;
						String[] allElements = temp.split(";");
						int dateincreament = Integer.parseInt(allElements[0]);
						boolean verifyexistence = Boolean.parseBoolean(allElements[1]);
						Calendar cal = Calendar.getInstance();
						cal.add(Calendar.DAY_OF_MONTH, dateincreament);
						Date expdate = cal.getTime();
						String expectedmonth = datesplitter(expdate , "mm");
						String expectedyear = datesplitter(expdate , "yy");
						String expectedDate = expectedmonth + " " + expectedyear;
						for (WebElement option : droplist_cotents) {
							if (expectedDate.equalsIgnoreCase(option.getText())) {
								isExists = true;
								break;
							}
						}
						if (isExists != verifyexistence) {
							return Constants.KEYWORD_FAIL + "<br>" + "Month after 337 days from current date is not displayed" + expectedDate + "</br>";
						}
						else {
							return Constants.KEYWORD_PASS + "<br>" + "Month after 337 days from current date is displayed" + expectedDate + "</br>";
						}
					}
					else
			        	return Constants.KEYWORD_FAIL + "<br>" + "Not able to find the " + objDesc + " dropdown List" + "</br>";
				}
				catch (Exception e) {
					return Constants.KEYWORD_FAIL + "<br>" + "Could not verify the month displayed after 337 days from current date " + e.getMessage().substring(0, 40) + "</br>";	
				}
			}

/*************************************************************************.
# 21
**************************************************************************
'* Keyword Name         : getMonthForInt
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To convert month number to month name
'* Input Parameters     : data
'* Output Parameters    : month name
'* Revision History     :
'* Usage				: getMonthForInt(data)
						data  :=Data should be entered as the month number
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public static String getMonthForInt(int m) {
			APP_LOGS.debug("To convert month number to month name");
		    String month = "invalid";
		    DateFormatSymbols dfs = new DateFormatSymbols();
		    String[] months = dfs.getMonths();
		    if (m >= 0 && m <= 11) {
		        month = months[m];
		    }
		    return month;
		}

/*************************************************************************.
# 22
**************************************************************************
'* Keyword Name         : navigate
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Navigate to the specified URL
'* Input Parameters     : data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: navigate(object,  data)
						object:=object is not required
						data  :=Data will be taken from the Excel sheet e.g:config|URL
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public String navigate(String object, String data) {
			APP_LOGS.debug("Navigating to URL");
			try {
				driver.navigate().to(data);
				DymamicWait();
				return Constants.KEYWORD_PASS + "<br>" + "Able to navigate to the " +data+ " URL successfully" + "</br>";
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>" + "Unable to navigate to the " +data+ " URL " + e.getMessage().substring(0, 20) + "</br>";
			}
			
		}

/*************************************************************************.
# 23
**************************************************************************
'* Keyword Name         : clickLink
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Click on the Link
'* Input Parameters     : Xpath of the object
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: clickLink(object,  data)
						object:=Xpath of the object
						data  :=Data is not required
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public String clickLink(String object, String data) {
	        APP_LOGS.debug("Clicking on link ");
	        String objlink="";
	        try {
	        	if (waitUntilExists(object, "xpath")) {
	        		String[] linkname = object.split("_");
	        		int objsize = linkname.length;
	        		objlink = linkname[objsize-1];
	        		driver.findElement(By.xpath(OR.getProperty(object))).click();
	        		DymamicWait();
	        	}
	        	else
	        		return Constants.KEYWORD_FAIL +"<br>"+ "Unable to click on "+objlink+" link"+"</br>";
	        }
	        catch (Exception e) {
	        	return Constants.KEYWORD_FAIL +"<br>"+ "Link "+objlink+" is not found"+ e.getMessage().substring(0, 40)+"</br>";
				
	        }
			return Constants.KEYWORD_PASS + "<br>"+"Successfully clicked on the link "+objlink+"</br>";
		}

/*************************************************************************.
# 24
**************************************************************************
'* Keyword Name         : clickLink_linkText
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Click on the Link with Linktext attribute
'* Input Parameters     : LinkText of the object
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: clickLink(object,  data)
						object:=Data will be taken from the Excel sheet e.g:col|Link_text
						data  :=Data is not required
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public String clickLink_linkText(String object, String data) {
			 APP_LOGS.debug("Clicking on linkText ");
			 String objlink="";
		     try {
		     	 if (waitUntilExists(object, "linkText")) {
		        	String[] linkname = object.split("_");
		        	int objsize = linkname.length;
		        	objlink = linkname[objsize-1];
		     		driver.findElement(By.linkText(OR.getProperty(object))).click();
		     		DymamicWait();
		        }
		        else
		        	return Constants.KEYWORD_FAIL +"<br>"+ "Unable to click on "+objlink+" link"+"</br>";
		        }
		     	catch (Exception e) {
		     		return Constants.KEYWORD_FAIL +"<br>"+ "Link "+objlink+" is not found"+ e.getMessage().substring(0, 40)+"</br>";
		     	}
		     	return Constants.KEYWORD_PASS + "<br>"+"Successfully clicked on the link "+objlink+"</br>";
		}

/*************************************************************************.
# 25
**************************************************************************
'* Keyword Name         : verifyLinkText
'* Developed Date 		:
'* Author               : AppLabs
'* Purpose              : Verifying link Text
'* Input Parameters     : Xpath of the object and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: clickLink(object, data)
						object:=Xpath of the object
						data  :=Data will be taken from the Excel sheet e.g:col|Expected_Link_text
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String verifyLinkText(String object, String data) {
			APP_LOGS.debug("Verifying link Text");
		    try {
		     	if (waitUntilExists(object, "linkText")) {
		     		String actual = driver.findElement(By.xpath(OR.getProperty(object))).getText();
		        	String expected = data;
		        	if (actual.equalsIgnoreCase(expected))
		        		return Constants.KEYWORD_PASS + "<br>"+"<b>"+"Expected LinkText "+"</b>" + data +"</br>"+"<br>"+"<b>"+"Actual LinkText "+"</b>" + actual+"</br>";
		        	else
		        		return Constants.KEYWORD_FAIL + "<br>"+"<b>"+"Expected LinkText "+"</b>" + data +"</br>"+"<br>"+"<b>"+"Actual LinkText "+"</b>" + actual+"</br>";
	        	}
	        	else
	        		return Constants.KEYWORD_FAIL +"<br>"+"Unable to find the Link "+ data +"</br>";
		    }
		    catch (Exception e) {
		    	return Constants.KEYWORD_FAIL +"<br>"+"Unable to find the Link "+ data +e.getMessage().substring(0,40)+"</br>";
		    }
		}

/*************************************************************************.
# 26
**************************************************************************
'* Keyword Name         : clickButton
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Click on the specified Button
'* Input Parameters     : Xpath of the object
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: clickButton(object,  data)
						object:=Xpath of the object
						data  :=Data is not required
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String clickButton(String object, String data) {
	        APP_LOGS.debug("Click on the specified Button");
	        String objDesc = "";
    		String[] textboxname = object.split("_");
    		int objsize = textboxname.length;
    		objDesc = textboxname[objsize-1];
	        try {
	        	if (waitUntilExists(object, "xpath")) {
	        		driver.findElement(By.xpath(OR.getProperty(object))).click();
	        		DymamicWait();
	        		return Constants.KEYWORD_PASS + "<br>" + "Successfully clicked on the " + objDesc + " button"+ "</br>";
		        }
		        else
		        	return Constants.KEYWORD_FAIL + "<br>" + objDesc + " button is not found"+ "</br>";
	        }
	        catch (Exception e) {
	        	return Constants.KEYWORD_FAIL + "<br>" + "Unable to click on " + objDesc + " button --" + e.getMessage().substring(0, 40)+ "</br>";
	        }
		}

/*************************************************************************.
# 27
**************************************************************************
'* Keyword Name         : verifyURL
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To verify the URL of the Page
'* Input Parameters     : Browser Object and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: verifyURL(object, data)
		 				object:=Browser Object
		 				data  :=Data will be taken from the Excel sheet e.g:col|Expected_URL
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String verifyURL(String object, String data) {
			APP_LOGS.debug("To verify the URL of the Page");
			try {
				if (waitUntilExists(object, "xpath")) {
					String actualurl = driver.getCurrentUrl();
					if (actualurl != null &&  actualurl.equalsIgnoreCase(data)) {
						return Constants.KEYWORD_PASS + "<br>"+"<b>"+"Expected URL is "+"</b>"+data+"</br>"+"<br>"+"<b>"+ "Actual URL is "+"</b>" + actualurl +"</br>";
					}
					else if (actualurl == null) {
						return Constants.KEYWORD_FAIL + "<br>"+"URL "+ data + " not found"+"</br>";
					}
					else
						return Constants.KEYWORD_FAIL + "<br>"+"<b>"+"Expected URL " +"</b>"+ data +"</br>"+"<br>"+"<b>"+ "Actual URL "+"</b>" + actualurl +"</br>";										
				}
				else
		        	return Constants.KEYWORD_FAIL + "<br>"+"URL "+ data + " not found"+"</br>";
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>"+"URL "+ data + " not found"+"</br>"+e.getMessage().substring(0,40);
			}
		}

/*************************************************************************.
# 28
**************************************************************************
'* Keyword Name         : verifyButtonText
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Verifying the button text
'* Input Parameters     : Xpath of the Object and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: verifyButtonText(object, data)
		 				object:=Xpath of the object
		 				data  :=Data will be taken from the Excel sheet e.g:col|Expected_Button_text
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String verifyButtonText(String object, String data) {
			APP_LOGS.debug("Verifying the button text");
			try {
				 if (waitUntilExists(object, "xpath")) {
					String actual = driver.findElement(By.xpath(OR.getProperty(object))).getText();
			    	String expected = data;
			    	if (actual.equals(expected))
			    		return Constants.KEYWORD_PASS + "<br>"+"<b>"+"Expected Button text "+"</b>" + expected +"</br>"+"<br>"+"<b>"+ "Actual Button text "+"</b>" + actual+"</br>";
			    	else
			    		return Constants.KEYWORD_FAIL + "<br>"+"<b>"+"Expected Button text " +"</b>" + expected +"</br>"+"<br>"+"<b>"+ "Actual Button text "+"</b>" + actual+"</br>";
				 }
				 else
		        	return Constants.KEYWORD_FAIL +"<br>"+ "Button with text name "+ data+" is not found"+"</br>";
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL +"<br>"+ "Button with text name "+ data+" is not found"+"</br>"+e.getMessage().substring(0, 40);
			}
		}

/*************************************************************************.
# 29
**************************************************************************
'* Keyword Name         : selectList
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Find a random value in list
'* Input Parameters     : Xpath of the object and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: selectList(object, data)
		 				object:=Xpath of the object
		 				data  :=Data will be taken from the Excel sheet e.g:col|Expected_Value
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String selectList(String object, String data) {
			APP_LOGS.debug("Find a random value in list");
	        String objDesc = "";
    		String[] textboxname = object.split("_");
    		int objsize = textboxname.length;
    		objDesc = textboxname[objsize-1];
			try {
				if (!data.equals(Constants.RANDOM_VALUE)) {
				  driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(data);
				}
				else {
					// logic to find a random value in list
					WebElement droplist = driver.findElement(By.xpath(OR.getProperty(object)));
					List<WebElement> droplist_cotents = droplist.findElements(By.tagName("option"));
					Random num = new Random();
					int index = num.nextInt(droplist_cotents.size());
					String selectedVal = droplist_cotents.get(index).getText();
					driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(selectedVal);
					return Constants.KEYWORD_FAIL + "<br>"+"Unable to select the " + data + " from "+objDesc+" list"+"</br>" ;
				}
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>"+"Unable to select the " + data + " from "+objDesc+" list"+"</br>"  + e.getMessage().substring(0, 40);
			}
			return Constants.KEYWORD_PASS + "<br>"+"Selected " + data + " from the "+objDesc+" dropdown list"+"</br>";
		}

/*************************************************************************.
# 30
**************************************************************************
'* Keyword Name         : selectListItem
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Select the specified Item from the drop-down list
'* Input Parameters     : Xpath of the object and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: selectListItem(object, data)
		 				object:=Xpath of the object
		 				data  :=Data will be taken from the Excel sheet e.g:col|Expected_Value
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String selectListItem(String object, String data) {
			APP_LOGS.debug("Selecting List item from drop-down list");
			 String objDesc = "";
	    		String[] textboxname = object.split("_");
	    		int objsize = textboxname.length;
	    		objDesc = textboxname[objsize-1];
			try {
				if (!data.equals(Constants.RANDOM_VALUE)) {
					driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(data);
				}
				else {
					// logic to find a random value in list
					WebElement droplist = driver.findElement(By.xpath(OR.getProperty(object)));
					droplist.findElement(By.xpath("//option[contains(text(),'" + data + "')]")).click();
					return Constants.KEYWORD_FAIL + "<br>"+"Unable to select the " + data + " from "+objDesc+" list"+"</br>" ;
				}
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>"+"Unable to select the " + data + " from "+objDesc+" list"+"</br>"+ e.getMessage().substring(0, 20);
			}
			return Constants.KEYWORD_PASS +"<br>"+"Selected " + data + " from the "+objDesc+" dropdown list"+"</br>";
		}

/*************************************************************************.
# 31
**************************************************************************
'* Keyword Name         : verifyListItems
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Verifying all the list elements
'* Input Parameters     : Xpath of the object and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: verifyListItems(object, data)
		 				object:=Xpath of the object
		 				data  :=Data will be taken from the Excel sheet e.g:col|List_items
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public String verifyListItems(String object, String data) {
			APP_LOGS.debug("Verifying all the list elements");
			 String objDesc = "";
	    		String[] textboxname = object.split("_");
	    		int objsize = textboxname.length;
	    		objDesc = textboxname[objsize-1];
			try {
				if (waitUntilExists(object, "xpath")) {
					boolean isExists = false;
					WebElement droplist = driver.findElement(By.xpath(OR.getProperty(object)));
					List<WebElement> droplist_cotents = droplist.findElements(By.tagName("option"));
					// extract the expected values from OR. properties
					String temp = data;
					String allElements[] = temp.split(";");
					// check if size of array == size if list
					if (allElements.length != droplist_cotents.size())
						for (int i = 0; i < allElements.length; i++) {
							isExists = false;
							for (WebElement option : droplist_cotents) {
								if (allElements[i].equalsIgnoreCase(option.getText())) {
									isExists = true;
									break;
								}
							}
							if (!isExists) {
								return Constants.KEYWORD_FAIL + "<br>"+"Element"+allElements[i]+" is not found in the droplist" +objDesc+"</br>" ;
							}
						}
				}
				else
		        	return Constants.KEYWORD_FAIL + "<br>"+"Not able to find the droplist"+objDesc+"</br>";
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>"+"Not able to find the droplist"+objDesc+"</br>"+ e.getMessage().substring(0, 40);
			}
			return Constants.KEYWORD_PASS +"<br>"+ "Successfully verified the Dropdown "+objDesc+" List Items"+"</br>";
		}

/*************************************************************************.
# 32
**************************************************************************
'* Keyword Name         : verifyListSelection
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Verifying the selection of the list
'* Input Parameters     : Xpath of the object and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: verifyListSelection(object, data)
						object:=Xpath of the object
		 				data  :=Data will be taken from the Excel sheet e.g:col|List_item
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String verifyListSelection(String object, String data) {
			APP_LOGS.debug("Verifying the selection of the list");
			String expectedVal = data;
			 String objDesc = "";
	    		String[] textboxname = object.split("_");
	    		int objsize = textboxname.length;
	    		objDesc = textboxname[objsize-1];
			try {
				if (waitUntilExists(object, "xpath")) {
					WebElement droplist = driver.findElement(By.xpath(OR.getProperty(object)));
					List<WebElement> droplist_cotents = droplist.findElements(By.tagName("option"));
					String actualVal = null;
					for (int i = 0; i < droplist_cotents.size(); i++) {
						String selected_status = droplist_cotents.get(i).getAttribute("selected");
						if (selected_status != null)
							actualVal = droplist_cotents.get(i).getText();
					}

					if (!actualVal.equals(expectedVal))
						return Constants.KEYWORD_FAIL + "<br>" + expectedVal + " is not exist in the Droplist"+"</br>";
				 }
				 else
					 return Constants.KEYWORD_FAIL + "<br>" + objDesc + " is not exist"+"</br>";
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>" + objDesc + " is not exist"+"</br>"+e.getMessage().substring(0, 40);	
			}
			return Constants.KEYWORD_PASS + "<br>"+ expectedVal + " is existed  in the Droplist"+objDesc+"</br>";
		}

/*************************************************************************.
# 33
**************************************************************************
'* Keyword Name         : selectRadio
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Selecting a radio button
'* Input Parameters     : Xpath of the object
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: selectRadio(String object, String data)
						object:=Xpath of the object
		 				data  :=Data is not required
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String selectRadio(String object, String data) {
			APP_LOGS.debug("Selecting a radio button");
			 String objDesc = "";
	    		String[] textboxname = object.split("_");
	    		int objsize = textboxname.length;
	    		objDesc = textboxname[objsize-1];
			try {
				if (waitUntilExists(object, "xpath")) {
					driver.findElement(By.xpath(OR.getProperty(object))).click();
					if (object.equalsIgnoreCase("radio_HomePage_Flighttab_RoundTrip") || object.equalsIgnoreCase("radio_HomePage_Flighttab_Oneway")) {
						driver.findElement(By.xpath(OR.getProperty("input_HomePage_Flighttab_From"))).clear();
						driver.findElement(By.xpath(OR.getProperty("input_HomePage_Flighttab_To"))).clear();
						driver.findElement(By.xpath(OR.getProperty("textBox_HomePage_Flighttab_DeptDate"))).clear();
						if (driver.findElement(By.xpath(OR.getProperty("textBox_HomePage_Flighttab_RetDate"))).isDisplayed()) {
							driver.findElement(By.xpath(OR.getProperty("textBox_HomePage_Flighttab_RetDate"))).clear();
						}
						driver.findElement(By.xpath(OR.getProperty("Webelement_HomePage_TileContainer"))).click();
					}
				}
				else
					return Constants.KEYWORD_FAIL + "<br>"+"Unable to select the "+objDesc+" radio button"+"</br>";
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>"+"Unable to select the "+objDesc+" radio button"+"</br>"+ e.getMessage().substring(0, 20);
			}
			return Constants.KEYWORD_PASS + "<br>"+"Successfully selected the "+objDesc+" radio button"+"</br>";
		}

/*************************************************************************.
# 34
**************************************************************************
'* Keyword Name         : splitTextAndVerify
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : To split text and verify existence of sub-string
'* Input Parameters     : Text and data
'* Output Parameters  	: Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: splitTextAndVerify(object, data)
						object:= Text
						data  := Data will be taken from the Excel sheet e.g: col|Sub-string
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String splitTextAndVerify(String object, String data) {
		    APP_LOGS.debug("To split text and verify existence of substring");
			//String objDesc = "";
    		//String[] textboxname = object.split("_");
    		//int objsize = textboxname.length;
    		//objDesc = textboxname[objsize-1];
		    try {
		    	String strtext = driver.findElement(By.xpath(OR.getProperty(object))).getText();
	            //String delimiter=data;
		    	String newstring[] = strtext.split(" ");
		    	int intLen = newstring.length;
		    	int intCounter = 0;
		    	int i;
		    	for (i = 0; i < intLen; i++) {
		    		String tempA = newstring[i];
		    		if (data.equalsIgnoreCase(tempA)) {
		    			intCounter = intCounter + 1;
		    		}
		    	}
		    	if (intCounter >= 1)
		    		return Constants.KEYWORD_PASS + "<br>"+"Substring " +"<b>"+ data + "</b>"+" is found in the string " + strtext+"</br>";
		    	else 
		    		return Constants.KEYWORD_FAIL + "<br>"+"Substring " +"<b>"+ data + "</b>"+" is not  found in the string " + strtext+"</br>";
		    }
		    catch (Exception e) {
		    	return Constants.KEYWORD_FAIL + "<br>"+"Unable to find substring --"+ data +"</br>"+ e.getMessage().substring(0, 20);
		    }
		}

/*************************************************************************.
# 35
**************************************************************************
'* Keyword Name         : verifyRadioSelected
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Verify Radio Selected
'* Input Parameters     : Xpath of the object
'* Output Parameters  	: Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: verifyRadioSelected(object, data)
						object:= Xpath of the object
						data  := Data is not required
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String verifyRadioSelected(String object, String data) {
			APP_LOGS.debug("Verify Radio Selected");
			 String objDesc = "";
	    		String[] textboxname = object.split("_");
	    		int objsize = textboxname.length;
	    		objDesc = textboxname[objsize-1];
			try {
				if (waitUntilExists(object, "xpath")) {
					String checked = driver.findElement(By.xpath(OR.getProperty(object))).getAttribute("checked");
					if (checked == null) 
						return Constants.KEYWORD_FAIL + "<br>"+"<b>"+objDesc+"</b>"+" radio button is not selected"+"</br>";
				}
				else
					return Constants.KEYWORD_FAIL + "<br>"+"<b>"+objDesc+"</b>"+" radio button is not exist"+"</br>";
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>"+"<b>"+objDesc+"</b>"+" radio button is not exist"+"</br>" + e.getMessage().substring(0, 20);	
			}
			return Constants.KEYWORD_PASS + "<br>"+"<b>"+objDesc+"</b>"+" radio button is selected"+"</br>";
		}

/*************************************************************************.
# 36
**************************************************************************
'* Keyword Name         : verifyImageExistence
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Verifying the Image Existence
'* Input Parameters     : Xpath of the object and data
'* Output Parameters  	: Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: verifyImageExistence(object, data)
						object:= Xpath of the object
						data  := Data will be taken from the Excel sheet e.g:col|Expected_data
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String verifyImageExistence(String object, String data) {
			APP_LOGS.debug("Verifying the Image Existence");
			String objDesc = "";
			String[] textboxname = object.split("_");
    		int objsize = textboxname.length;
    		objDesc = textboxname[objsize-1];
			try {
				if (waitUntilExists(object, "xpath")) {
			
					String actual = driver.findElement(By.xpath(OR.getProperty(object))).getAttribute("class");
				    String expected = data;
			    	if (actual.equals(expected))
			    		return Constants.KEYWORD_PASS + "<br>" + objDesc + " image exists" + "/<br>";
			    	else
			    		return Constants.KEYWORD_FAIL  + "<br>" + objDesc + " image does not exist" + "/<br>";
				 }
				 else
		        	return Constants.KEYWORD_FAIL + "<br>" + objDesc + " not found" + "/<br>";
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>"+ "image existence not verified" + e.getMessage().substring(0, 20)+ "/<br>";
			}
		}

/*************************************************************************
# 37
**************************************************************************
'* Keyword Name         : verifyTextboxExistence
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Verifying the Text box Existence
'* Input Parameters     : Xpath of the object and data
'* Output Parameters  	: Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: verifyTextboxExistence(object, data)
						object:= Xpath of the object
						data  := Data will be taken from the Excel sheet e.g:col|Expected_data
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String verifyTextboxExistence(String object, String data) {
			APP_LOGS.debug("Verifying the Textbox Existence");
				String objDesc = "";
				String[] textboxname = object.split("_");
	    		int objsize = textboxname.length;
	    		objDesc = textboxname[objsize-1];
			try {
				if (waitUntilExists(object, "xpath")) {
					String actual = driver.findElement(By.xpath(OR.getProperty(object))).getAttribute("for");
			    	String expected = data;
			    	if (actual.equals(expected))
			    		return Constants.KEYWORD_PASS + "<br>"+"<b>"+objDesc+"</b>"+" Textbox is exists"+"</br>";
			    	else
			    		return Constants.KEYWORD_FAIL + "<br>"+"<b>"+objDesc+"</b>"+" Textbox is doesnot  exists"+"</br>";
				 }
				 else
					 return Constants.KEYWORD_FAIL + "<br>"+"unable to find the "+"<b>"+objDesc+"</b>"+" Textbox"+"</br>";
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>"+"unable to find the "+"<b>"+objDesc+"</b>"+" Textbox"+"</br>" + e.getMessage().substring(0, 20);
			}
		}

/*************************************************************************.
# 38
**************************************************************************
'* Keyword Name         : checkCheckBox
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Check the specified checkbox
'* Input Parameters     : Xpath of the object
'* Output Parameters  	: Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: checkCheckBox(object, data)
						object:= Xpath of the object
						data  := Data is not required
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String checkCheckBox(String object, String data) {
			APP_LOGS.debug("Check the specified checkbox");
			String objDesc = "";
			String[] textboxname = object.split("_");
    		int objsize = textboxname.length;
    		objDesc = textboxname[objsize-1];
			try {
				if (waitUntilExists(object, "xpath")) {
					// true or null
					String checked = driver.findElement(By.xpath(OR.getProperty(object))).getAttribute("checked");
					if (checked == null) // checkbox is unchecked
						driver.findElement(By.xpath(OR.getProperty(object))).click();
				}
				else
		        	return Constants.KEYWORD_FAIL + "<br>"+"Unable to Check the "+"<b>"+objDesc+"</b>"+" checkbox"+"</br>";
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL  + "<br>"+"The "+"<b>"+objDesc+"</b>"+" checkbox is not exist"+"</br>"+ e.getMessage().substring(0, 20);
			}
			return Constants.KEYWORD_PASS + "<br>"+"Successfully Checked the "+"<b>"+objDesc+"</b>"+" checkbox"+"</br>";
		}

/*************************************************************************.
# 39
**************************************************************************
'* Keyword Name         : unCheckCheckBox
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Uncheck the specified checkbox
'* Input Parameters     : Xpath of the object
'* Output Parameters  	: Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: unCheckCheckBox(object, data)
						object:= Xpath of the object
						data  := Data is not required
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public String unCheckCheckBox(String object, String data) {
			APP_LOGS.debug("Uncheck the specified checkbox");
			String objDesc = "";
			String[] textboxname = object.split("_");
    		int objsize = textboxname.length;
    		objDesc = textboxname[objsize-1];
			try {
				if (waitUntilExists(object, "xpath")) {
					String checked = driver.findElement(By.xpath(OR.getProperty(object))).getAttribute("checked");
					if (checked != null)
						driver.findElement(By.xpath(OR.getProperty(object))).click();
				}
				else
		        	return Constants.KEYWORD_FAIL + "<br>"+"Unable to  Unchecked the "+"<b>"+objDesc+"</b>"+" checkbox"+"</br>";
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>"+"<b>"+objDesc+"</b>"+" checkbox is not exist"+"</br>" + e.getMessage().substring(0, 20);
			}
			return Constants.KEYWORD_PASS + "<br>"+"Successfully Unchecked the "+"<b>"+objDesc+"</b>"+" checkbox"+"</br>";
		}

/*************************************************************************.
# 40
**************************************************************************
'* Keyword Name         : CheckBoxSelected
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Verifying whether the checkbox is selected
'* Input Parameters     : Xpath of the object and data
'* Output Parameters  	: Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :Xpath of the object and data
'* Usage				: CheckBoxSelected(object, data)
						object:= Xpath of the object
						data  := Data will be taken from the Excel sheet e.g:col|Expected_data
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String CheckBoxSelected(String object, String data) {
			APP_LOGS.debug("Verifying whether the checkbox is selected");
			String objDesc = "";
			String[] textboxname = object.split("_");
    		int objsize = textboxname.length;
    		objDesc = textboxname[objsize-1];
			try {
				if (waitUntilExists(object, "xpath")) {
					String checked = driver.findElement(By.xpath(OR.getProperty(object))).getAttribute("checked");
					if (checked != null && data.equalsIgnoreCase("true"))
						return Constants.KEYWORD_PASS + "-- Specfied Checkbox is checked";
					else if (checked==null && data.equalsIgnoreCase("false"))
						return Constants.KEYWORD_PASS +"<br>"+"<b>"+objDesc+"</b>"+ " Checkbox is Selected"+"</br>";
					else
						return Constants.KEYWORD_FAIL +"<br>"+"<b>"+objDesc+"</b>"+ " Checkbox is not Selected"+"</br>";
				}
				else
		        	return Constants.KEYWORD_FAIL +"<br>"+"<b>"+objDesc+"</b>"+ " Checkbox is not Selected"+"</br>";
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL +"<br>"+"<b>"+objDesc+"</b>"+ " Unable to verify whether the specified checkbox is selected"+"</br>" + e.getMessage().substring(0, 20);
			}		
		}

/*************************************************************************.
# 41
**************************************************************************
'* Keyword Name         : verifyText
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Verifying the text
'* Input Parameters     : Xpath of the object and data
'* Output Parameters  	: Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: verifyText(object, data)
						object:= Xpath of the object
						data  := Data will be taken from the Excel sheet e.g:col|Expected_data
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

	public String verifyText(String object, String data) {
		APP_LOGS.debug("Verifying the text"); 
		String expected = data;
		
		try {
			if (waitUntilExists(object,"xpath")) {
				String actual = driver.findElement(By.xpath(OR.getProperty(object))).getText();
			   	
		    	if (actual.equalsIgnoreCase(expected))
		    		return Constants.KEYWORD_PASS + "<br>" +  "<B>" + " Expected text: " + "</B>" + expected + "<B>" + " Actual text: " + "</B>" + actual  + "</br>";
		    	else
		    		return Constants.KEYWORD_FAIL + "<br>" + "<B>" + " Expected text: " + "</B>" + expected + "<B>" + " Actual text: " + "</B>" + actual + "</br>";
			}
			else
	        	return Constants.KEYWORD_FAIL + "<br>" + expected + " text is not displayed in the application" + "<B>" + "</br>";
		}
		catch (Exception e) {
			return Constants.KEYWORD_FAIL + "<br>" + "Unable to verify the text " + expected + "<br>"+ e.getMessage().substring(0, 40)+ "<B>" + "</br>";
		}
	}

/*************************************************************************.
# 42
**************************************************************************
'* Keyword Name         : verifyTextinInput
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Verifying the text in input box
'* Input Parameters     : Xpath of the object and data
'* Output Parameters  	: Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: verifyTextinInput(object, data)
						object:= Xpath of the object
						data  := Data will be taken from the Excel sheet e.g:col|Expected_data
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String verifyTextinInput(String object, String data) {
			APP_LOGS.debug("Verifying the text in input box");
			String objDesc = "";
			String expected = "";
			String[] objname = object.split("_");
		    int objsize = objname.length;
		    objDesc = objname[objsize-1];
			try {
				if(waitUntilExists(object, "xpath")) {
					
					
					String actual = driver.findElement(By.xpath(OR.getProperty(object))).getAttribute("value");
					expected = data;
					if(actual.equals(expected)) {
						return Constants.KEYWORD_PASS + "<br>" + "Expected text --" +  "<B>"  + expected + "</B>" +  " and the actual text-- " +  "<B>"  + actual + "</B>"+ " matched in the " + objDesc + " Input box" + "</br>";
	    		   }
	    		   else {
	    			   return Constants.KEYWORD_FAIL + "<br>" + "Expected text --" +  "<B>"  + expected + "</B>" + " does not match the actual text-- " +  "<B>"  + actual + "</B>"+" in the " + objDesc + " Input box" + "</br>" ;
	    		   }
	    	   }
	    	   else
	    		   return Constants.KEYWORD_FAIL + "<br>" + objDesc + " Inputbox does not exist" + "</br>";
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>" + "Unable to Verify the " +  "<B>"  + expected + "</B>" + " Text in the " + objDesc + " input box --" + e.getMessage().substring(0, 40) + "</br>";
			}
		}

/*************************************************************************.
# 43
**************************************************************************
'* Keyword Name         : verifyTitle
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Verifying title
'* Input Parameters     : Xpath of the object and data
'* Output Parameters  	: Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: verifyTitle(object, data)
						object:= Xpath of the object
						data  := Data will be taken from the Excel sheet e.g:col|Expected_data
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String verifyTitle(String object, String data) {
			APP_LOGS.debug("Verifying title");
		    try {
		    	String actualTitle = driver.getTitle();
		    	String expectedTitle = data;
		    	if (actualTitle.equals(expectedTitle))
		    		return Constants.KEYWORD_PASS;
			    else
			    	return Constants.KEYWORD_FAIL + "<br>" + "Expected title --" +  "<B>"  + expectedTitle + "</B>" + " does not match the actual title " + "<B>"  + actualTitle +"</B>" + "</br>";
		    }
		    catch (Exception e) {
		    	return Constants.KEYWORD_FAIL + "<br>" + "Unable to verify title --" + e.getMessage().substring(0, 40) + "</br>";
			}
		}

/*************************************************************************.
# 44
**************************************************************************
'* Keyword Name         : exists
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Verify existence of the specified Object
'* Input Parameters     : Xpath of the object and data
'* Output Parameters  	: Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: exists(object, data)
						object:= Xpath of the object
						data  := Data will be taken from the Excel sheet e.g:col|Expected_data
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public String exists(String object, String data) {
			APP_LOGS.debug("Verify existence of the specified Object");
			String objDesc = "";
			String[] textboxname = object.split("_");
    		int objsize = textboxname.length;
    		objDesc = textboxname[objsize-1];
		    try {
		    	if (waitUntilExists(object, "xpath")) {
		    		
		    		
		    		boolean isExists = driver.findElement(By.xpath(OR.getProperty(object))).isDisplayed();
				    if (data.equalsIgnoreCase("true") && isExists) { // Check for existence of Object
				      	return Constants.KEYWORD_PASS + "<br>" + objDesc +" object is displayed" + "</br>";
				    }
				    else if (data.equalsIgnoreCase("false") && !(isExists)) {	// Check for non-existence of Object
				    	return Constants.KEYWORD_PASS + "<br>"+ objDesc +" object does not exist" + "</br>";
				    }
				    else
				    	return Constants.KEYWORD_FAIL + "<br>" + objDesc+" object does not exist" + "</br>";
			    }
				else
					return Constants.KEYWORD_FAIL + "<br>"+ objDesc +" object does not exist" + "</br>";
		    }
		    catch (Exception e) {
		    	return Constants.KEYWORD_FAIL + "<br>" + "Unable to determine the" + objDesc + "existence" + e.getMessage().substring(0, 40) + "</br>";
			}
		}

/*************************************************************************.
# 45
**************************************************************************
'* Keyword Name         : VerifyExistencewithtext
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Verifying existence of an Object with specified text
'* Input Parameters     : Xpath of the object and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: VerifyExistencewithtext(object, data)
						object:=Xpath of the object
						data  :=Data will be taken from the Excel sheet e.g:col|ExpectedData
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String VerifyExistencewithtext(String object, String data) {
			APP_LOGS.debug("Verifying existence of an Object with specified text");
			String objDesc = "";
			String[] textboxname = object.split("_");
    		int objsize = textboxname.length;
    		objDesc = textboxname[objsize-1];
	        try {
	        	if (waitUntilExists(object, "xpath")) {
	        		
		        	String actual = driver.findElement(By.xpath(OR.getProperty(object))).getText();
		        	String expected = data;
		        	if (actual.indexOf(expected) >= 0)
		        		return Constants.KEYWORD_PASS +  "<br>" + objDesc + " Object exists" + "</br>";
		        	else
		        		return Constants.KEYWORD_PASS +  "<br>" + objDesc + " Object does not exist" + "</br>";
	        	}
	        	else
	        		return Constants.KEYWORD_FAIL + "<br>" + objDesc + " Object not found" + "</br>";
	        }
	        catch (Exception e) {
				return Constants.KEYWORD_FAIL +  "<br>" +  "  Unable to verify existence of the"  + objDesc + " Object with given text --" + e.getMessage().substring(0, 40) + "</br>";
	        }
		}

/*************************************************************************.
# 46
**************************************************************************
'* Keyword Name         : selectListItemwithIndex
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Selecting List item from list using index
'* Input Parameters     : Xpath of the object and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: selectListItemwithIndex(object,  data)
						object:=Xpath of the object
						data  :=Data will be taken from the Excel sheet e.g:col|ExpectedIndex
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String selectListItemwithIndex(String object, String data) {
	        APP_LOGS.debug("Selecting List item from list using index");
	        String objDesc = "";
	        String[] textboxname = object.split("_");
    		int objsize = textboxname.length;
    		objDesc = textboxname[objsize-1];
	        try {
	        	if (waitUntilExists(object, "xpath")) {
	        	
	        		driver.findElement(By.xpath(OR.getProperty(object))).click();
	        		WebElement droplist = driver.findElement(By.xpath(OR.getProperty(object)));
                    List<WebElement> droplist_cotents = droplist.findElements(By.tagName("option"));
                    droplist.sendKeys(Keys.ARROW_UP);
                    int index = (int) Double.parseDouble(data);
	                for (int i = 1; i < droplist_cotents.size(); i++) {
	                	if (i <= index) {
	                		droplist.sendKeys(Keys.ARROW_DOWN);
	                    }
	                }
	                return Constants.KEYWORD_PASS + "<br>" + " Successfully selected the " + objDesc + " List Item with Index --" + data + "</br>";
                }
	        	else
	        		return Constants.KEYWORD_FAIL + "<br>" + objDesc + " Object not found" + "</br>";
	        }
	        catch (Exception e) {
	        	return Constants.KEYWORD_FAIL + "<br>" + " Unable to select the " + objDesc + " List Item with Index --" + data + e.getMessage().substring(0, 40) + "</br>";
	        }
			
	    }

/*************************************************************************.
# 47
**************************************************************************
'* Keyword Name         : getLinks
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Search for a link with specified text and click on it
'* Input Parameters     : data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: getLinks(object,  data)
						  object:=object is not required
						  data  :=Data will be taken from the Excel sheet e.g:col|ExpectedLink
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public String getLinks(String object, String data) {
			try {
				//WaitAndLoadPage(10);
				DymamicWait();
				List<WebElement> links = driver.findElements(By.tagName("a"));
				System.out.println(links.size());
				for (WebElement myElement : links) {
					String link = myElement.getText();
					if (link != "") {
						if (link.equalsIgnoreCase(data)) {
							myElement.click();
							//WaitAndLoadPage(5);
							DymamicWait();
							return Constants.KEYWORD_PASS + "<br>" + " Object is found and clicked on:" + data + " link Successfully " + "</br>";
						}
					}
				}
			}
			catch (Exception e) {
		      	return Constants.KEYWORD_FAIL + "<br>" + " Unable to click on specified link --" + e.getMessage().substring(0, 40) + "</br>";
		    }
		    return Constants.KEYWORD_FAIL + "<br>" + data +  " Object is not found "  + "</br>";
		}

/*************************************************************************.
# 48
**************************************************************************
'* Keyword Name         : click
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Clicking on specified object
'* Input Parameters     : Xpath of the object
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: click(object,  data)
						object:=Xpath of the object
						data  :=Data is not required
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String click(String object, String data) {
			APP_LOGS.debug("Clicking on specified object");
			String objDesc = "";
			String[] textboxname = object.split("_");
    		int objsize = textboxname.length;
    		objDesc = textboxname[objsize-1];
		    try {
		    	if (waitUntilExists(object, "xpath")) {
		    		
		    		driver.findElement(By.xpath(OR.getProperty(object))).click();
		    		DymamicWait();
		    		return Constants.KEYWORD_PASS + "<br>" + "Successfully clicked on the " + objDesc + " object" + "</br>";
		    			    	    		   
		        }
		    	else
			     	return Constants.KEYWORD_FAIL + "<br>" + "Object " + objDesc + " does not exist" + "</br>";
			}
		    catch (Exception e) {
		    	return Constants.KEYWORD_FAIL + "<br>" + "Unable to click on the " + objDesc + " Object --" + e.getMessage().substring(0, 40) + "</br>";
			}
			
		}

/*************************************************************************.
# 49
**************************************************************************
'* Keyword Name         : synchronize
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Waiting for page to load
'* Input Parameters     : NA
'* Output Parameters    : Constants.KEYWORD_PASS
'* Revision History     :
'* Usage				: synchronize(object,  data)
						object:=object is not required
						data  :=Data is not required
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

	public  String synchronize(String object, String data) {
		APP_LOGS.debug("Waiting for page to load");
		((JavascriptExecutor) driver).executeScript("function pageloadingtime()" + "{" + "return Page has completely loaded" + "}" + "return (window.onload=pageloadingtime());");
		return Constants.KEYWORD_PASS + "<br>" + " Synchorinization completed successfully" + "</br>";
	}

/*************************************************************************.
# 50
**************************************************************************
'* Keyword Name         : waitForElementVisibility
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Wait for an element to be visible
'* Input Parameters     : Xpath and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: waitForElementVisibility(object,  data)
						  object:=xpath of the object
						  data  :=Data will be taken from the Excel sheet e.g:col|ExpectedTimeinseconds
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String waitForElementVisibility(String object, String data) {
			APP_LOGS.debug("Wait for an element to be visible");
			String objDesc = "";
			int start = 0;
			int time = (int) Double.parseDouble(data);
			String[] textboxname = object.split("_");
    		int objsize = textboxname.length;
    		objDesc = textboxname[objsize-1];
			try {
				
				while (time == start) {
					if (driver.findElements(By.xpath(OR.getProperty(object))).size() == 0) {
						Thread.sleep(1000L);
						start++;
					}
					else {
						break;
					}
				}
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>" + objDesc +" Unable to wait for Element visibility --" + e.getMessage().substring(0, 40) + "</br>";
			}
			return Constants.KEYWORD_PASS + "<br>" + objDesc +" Element Found" + "</br>";
		}

/*************************************************************************.
# 51
**************************************************************************
'* Keyword Name         : mouseHover
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Perform Mouse Hover operation
'* Input Parameters     : xpath of the object 
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: mouseHover(object,  data)
						object:=Xpath of the object
						data  :=Data is not required
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String mouseHover(String object, String data) {
			APP_LOGS.debug("Perform Mouse Hover operation");
			String objDesc = "";
			String[] textboxname = object.split("_");
    		int objsize = textboxname.length;
    		objDesc = textboxname[objsize-1];
			Actions action = new Actions(driver);
			try {
				if (waitUntilExists(object, "xpath")) {
					WebElement devices=driver.findElement(By.xpath(OR.getProperty(object)));
					action.moveToElement(devices).build().perform();
					Thread.sleep(2000);
				}
				else
		        	return Constants.KEYWORD_FAIL + "<br>"  + objDesc + " Object does not exist" + "</br>";
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>" + " Unable to hover on the "  + objDesc + " object -- " + e.getMessage().substring(0, 40) + "</br>";
			}
			return Constants.KEYWORD_PASS + "<br>" + " Mouse hover on the "  + objDesc + " object was successful" + "</br>";
		}

/*************************************************************************.
# 52
**************************************************************************
'* Keyword Name         : verifyIsClickable
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Verify whether an Object is clickable
'* Input Parameters     : Xpath of the object and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: verifyIsClickable(object,  data)
						object:=Xpath of the object
						data  :=Data will be taken from the Excel sheet e.g:col|ExpectedData
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String verifyIsClickable(String object, String data) {
			APP_LOGS.debug("Verify whether an Object is clickable");
			String objDesc = "";
			String[] textboxname = object.split("_");
    		int objsize = textboxname.length;
    		objDesc = textboxname[objsize-1];
			try {
				if (waitUntilExists(object, "xpath")) {
					String attributeValue = driver.findElement(By.xpath(OR.getProperty(object))).getAttribute("href");
					if (attributeValue != null &&  data.equalsIgnoreCase("true")) {
						return Constants.KEYWORD_PASS + "<br>" +  objDesc + " Object is clickable" + "</br>";
					}
					else if (attributeValue == null &&  data.equalsIgnoreCase("false")) {
						return Constants.KEYWORD_PASS + "<br>"  +  objDesc +  " Object is not clickable" + "</br>";
					}
					else
						return Constants.KEYWORD_FAIL + "<br>" + objDesc + " Object not found" + "</br>";
				}
				else
		        	return Constants.KEYWORD_FAIL + "<br>" + objDesc + " Object does not exist" + "</br>";
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>" + " Unable to determine whether the " + objDesc + " object is clickable -- " + e.getMessage().substring(0, 40) + "</br>";
			}
		}

/*************************************************************************.
# 53
**************************************************************************
'* Keyword Name         : switchToPopup
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Switch to Popup
'* Input Parameters     : Xpath of the object
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: switchToPopup(object,  data)
						object:=Xpath of the object
						data  :=Data is not required
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String switchToPopup(String object, String data) {
			APP_LOGS.debug("Switch to Popup");
			try {
				sHandleBefore = driver.getWindowHandle();
				for (String Handle : driver.getWindowHandles()) {
					driver.switchTo().window(Handle);
				}
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>" + " Unable to Siwtch to the pop up -- " + e.getMessage().substring(0, 40) + "</br>";
			}
			return Constants.KEYWORD_PASS + "<br>" + " Successfully switched to the pop up" + "</br>";
		}

/*************************************************************************.
# 54
**************************************************************************
'* Keyword Name         : switchToNormal
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Switch to normal window
'* Input Parameters     : Xpath of the object
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: switchToNormal(object,  data)
						object:=Xpath of the object
						data  :=Data is not required
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String switchToNormal(String object, String data) {
			APP_LOGS.debug("Switch to normal window");
			try {
				driver.switchTo().window(sHandleBefore);
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>" + "Unable to switch to normal window --" + e.getMessage().substring(0, 40) + "</br>";
			}
			return Constants.KEYWORD_PASS + "<br>" + "Successfully switched to Normal Window" + "</br>";
		}

/*************************************************************************.
# 55
**************************************************************************
'* Keyword Name         : pause
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Pause execution for the specified time in seconds
'* Input Parameters     : object
'* Output Parameters    : Constants.KEYWORD_PASS
'* Revision History     :
'* Usage				: pause(object,  data)
						object:=object will be taken from the Excel sheet e.g:col|ExpectedTimeInSeconds
						data  :=Data is not required
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public String pause(String object, String data) throws NumberFormatException, InterruptedException {
			long time = (long) Double.parseDouble(object);
			Thread.sleep(time * 1000L);
			return Constants.KEYWORD_PASS + "<br>" + " Execution Paused for " + object + "seconds" + "</br>";
		}

/*************************************************************************.
# 56
**************************************************************************
'* Keyword Name         : closeBrowser
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Closing the browser
'* Input Parameters     : NA
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: closeBrowser(object,  data)
						object:=object is not required
						data  :=Data is not required
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String closeBrowser(String object, String data) {
			APP_LOGS.debug("Closing the browser");
			try {
				driver.close();
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>" + " Unable to close browser" + e.getMessage().substring(0, 40) + "</br>";
			}
			return Constants.KEYWORD_PASS + "<br>" + browserName + " browser closed successfully" + "</br>";
		}

/*************************************************************************.
# 57
**************************************************************************
'* Keyword Name         : LoginError
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : Verifying the Login Error messages
'* Input Parameters     : Xpath and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: LoginError(object,  data)
						object:=Xpath of the object
						data  :=Data is taken from the excel sheet. e.g. col|MPNumber,Password,Count,Error message
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

	public String LoginError(String object, String data) {
		APP_LOGS.debug("Verifying the Error messages");
		
		String [] searchdata = data.split(",");
		String objDesc = "";
		String[] textboxname = object.split("_");
		int objsize = textboxname.length;
		objDesc = textboxname[objsize-1];
		try {
			int j = Integer.parseInt(searchdata[2]);
			for (int i = 1; i <= j; i++) {
				driver.findElement(By.id("MpNumber")).clear();
				driver.findElement(By.id("MpNumber")).sendKeys(searchdata[0]);
				driver.findElement(By.id("Password")).clear();
				driver.findElement(By.id("Password")).sendKeys(searchdata[1]);
				driver.findElement(By.id("btnSignIn")).click();
				APP_LOGS.debug("Verifying the text");
				if (i == j) {
					if (waitUntilExists(object, "xpath")) {
						String actual = driver.findElement(By.xpath(OR.getProperty(object))).getText();
						String expected = searchdata[3];
						if (actual.equalsIgnoreCase(expected))
							return Constants.KEYWORD_PASS + "<br>" + "  Expected error --" + expected + " and the actual error " + actual + " matched" + "</br>";
						else
							return Constants.KEYWORD_FAIL + "<br>" + "  Expected error --" + expected + " does not match the actual error " + actual + "</br>";
					}
					else
						return Constants.KEYWORD_FAIL + "<br>" + objDesc + " object does not exist" + "</br>";
				}
			}
		}
		catch (Exception e) {
			return Constants.KEYWORD_FAIL + "<br>" + objDesc +" Object not found - " + e.getMessage().substring(0, 40) + "</br>";
		}
		return Constants.KEYWORD_PASS + "<br>" + " Expected error and the actual error matched" + "</br>";
	}

/*************************************************************************.
# 58
**************************************************************************
'* Keyword Name         : SelectCalendarCurrentDate
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To select currnent date from calendar date picker
'* Input Parameters     : Xpath of the object and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: SelectCalendarCurrentDate(String object, String data)
						object:=Xpath of the object
						data  :=Data will be taken from the Excel sheet e.g:col|WaitForText 
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public String SelectCalendarCurrentDate(String object, String data) 
		{
	        //WaitAndLoadPage(50);
			DymamicWait();
	        APP_LOGS.debug("To select current date from calendar date picker");
	        try 
	        {
	        	if (waitUntilExists(object, "xpath")) 
	        	{
	        		Calendar cal = Calendar.getInstance();
		            cal.setTimeZone(TimeZone.getTimeZone("GMT"));
	                String newdate = cal.getTime().toString();
	                String[] dateconv = newdate.split(" ");
	                String strday = dateconv[2];
		            String currentdate = SelectCalendarDate(object, strday); 
		            if (currentdate.contains("PASS")) 
		            {
		            	return Constants.KEYWORD_PASS + "<br>" + "Selected " + newdate + " from the Calendar widget" + "</br>";
		            }
		            else 
		            {
		            	return Constants.KEYWORD_FAIL + "<br>" + newdate + " is not selectable in the Calendar widget" + "</br>";
		            }
		        }
		        else 
		        {
		        	return Constants.KEYWORD_FAIL + "<br>" + "Calendar widget is not found" + "</br>";
		        }
	        }
	        catch (Exception e) 
	        {
	        	return Constants.KEYWORD_FAIL + "<br>" + "Unable to select current date from Calendar widget as " + e.getMessage().substring(0, 40) + "</br>";
		    }
		}

/*************************************************************************.
# 59
**************************************************************************
'* Keyword Name         : inputDate
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To input the date with the date addition for current date
'* Input Parameters     : Xpath of the object and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: inputDate(object, data)
			  			object:=Xpath of the object
			  			data  :=Data will be taken from the Excel sheet e.g:col|ExpectedDate
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String inputDate(String object, String data) {
			APP_LOGS.debug("Writing in text box"); 
			String objDesc = "";
			String[] textboxname = object.split("_");
			int objsize = textboxname.length;
			objDesc = textboxname[objsize-1];
	        try {
	        	if (waitUntilExists(object, "xpath")) {
	        		String temp = data;
		    		int dateincreament = Integer.parseInt(temp);
		            Calendar cal = Calendar.getInstance();
		            cal.add(Calendar.DAY_OF_MONTH, dateincreament);
		    		Date Expdate = cal.getTime();
		    		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		    	    String date = formatter.format(Expdate);
		    	    driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(date);
		        }
		        else
		            return Constants.KEYWORD_FAIL + "<br>" + objDesc + " Inputbox does not exist" + "</br>";
		    }
	        catch (Exception e) {
	        	return Constants.KEYWORD_FAIL + "<br>" + " Unable to enter date in the " + objDesc + " Inputbox" + e.getMessage().substring(0, 40) + "</br>";
	        } 
	        return Constants.KEYWORD_PASS + "<br>" + " Successfully entered date in  the " + objDesc + " Inputbox" + "</br>";
		}

/*************************************************************************.
# 60
**************************************************************************
'* Keyword Name         : doesNotExists
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To verify that object is not present in the page
'* Input Parameters     : Xpath of the object and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: doesNotExists( object,  data)
						object:=Xpath of the object
						data  :=Data will be taken from the Excel sheet e.g:col|Existence 
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

			public String doesNotExists(String object, String data) {
				APP_LOGS.debug("To verify that object is not present in the page");
				String objDesc = "";
				String[] textboxname = object.split("_");
				int objsize = textboxname.length;
				objDesc = textboxname[objsize-1];
			    try {
			    	boolean isExists = driver.findElement(By.xpath(OR.getProperty(object))).isDisplayed();
				    String actual = String.valueOf(isExists);
					if (data.equalsIgnoreCase("true") && isExists) { // Check for existence of Object
						return Constants.KEYWORD_FAIL +  "<br>" + objDesc + " Object exists in the application" + "</br>";
					}			                                    
					else if (data.equalsIgnoreCase(actual)) { // Check for non-existence of Object
						return Constants.KEYWORD_PASS +  "<br>" + objDesc + " Object does not exist in the application" + "</br>";
					}
					else return Constants.KEYWORD_FAIL + "<br>" +  objDesc + " Object not found in the application" + "</br>";
				}
			    catch (Exception e) {
			    	return Constants.KEYWORD_PASS +  "<br>" + " Unable to verify the existence of the object " +  objDesc + e.getMessage().substring(0, 40) + "</br>";
				}
			}

/*************************************************************************.
# 61
**************************************************************************
'* Keyword Name         : browserBack
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To click on the Browser back button.
'* Input Parameters     : NA
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: browserBack(object, data)
						object:=object is not required
						data  :=data is not required
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String browserBack(String object, String data) 
		{
			APP_LOGS.debug("To click on the Browser back button");
			try 
			{
				driver.navigate().back();
				DymamicWait();
			}
			catch (Exception e) 
			{
				return Constants.KEYWORD_FAIL + "<br>" + "Unable to click on the Browser back button as " + e.getMessage().substring(0, 40) + "</br>";
			}
			return Constants.KEYWORD_PASS + "<br>" + "Successfully clicked on the Browser Back button " + "</br>";
		}

/*************************************************************************.
# 62
**************************************************************************
'* Keyword Name         : verifyErrorMsg
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To validate the Error message displayed
'* Input Parameters     : data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: verifyErrorMsg(object, data)
						object:=object is not required
						data  :=Data will be taken from the Excel sheet e.g:col|Mpsignin1sttime
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'
**************************************************************************/

		public String verifyErrorMsg(String object, String data) 
		{
			APP_LOGS.debug("To validate the Error message displayed");
			try 
			{
				DymamicWait();
				String error_message_tooltip = "//div[starts-with(@id,'qtip-')]";
				List <WebElement> xpathfound = driver.findElements(By.xpath(error_message_tooltip));
				for (WebElement path:xpathfound) 
				{
					String path1 = path.getAttribute("aria-describedby");
					if (path1 != null && !path1.equals("")) 
					{
						String needpath = "//*[@id='" + path1 + "']";
						String expected = driver.findElement(By.xpath(needpath)).getText();
						if (expected != null && !expected.equals("")) 
						{
							if (expected.equalsIgnoreCase(data)) 
							{
								return Constants.KEYWORD_PASS + "<br>" + "<b>" + "Expected error message: " + "</b>" + expected + "and <b>" + " Actual error message: " + "</b>" + data+" matched</br>";
							}
							else
								return Constants.KEYWORD_FAIL + "<br>" + "<b>" + "Expected error message: " + "</b>"+ expected + "and <b>" + " Actual error message: " + "</b>" + data+" did not match</br>";
						}
					}
				}
			}
			catch (Exception e) 
			{
				return Constants.KEYWORD_FAIL + "<br>" + "Unable to verify the Error message." + data + "as" + e.getMessage().substring(0, 40)+ "</br>";
			}
			return Constants.KEYWORD_FAIL + "<br> Error message --" + data + "-- validation failed as the error message tooltip is not found" + "</br>";
		}

/*************************************************************************.
# 63
**************************************************************************
'* Keyword Name         : Login
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To login to the MP account
'* Input Parameters     : data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: Login(object, data)
						object:=object is not required
						data  :=Data will be taken from the Excel sheet e.g:col|Mpsignin1sttime
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
**************************************************************************/

		public String Login(String object, String data) 
		{
			APP_LOGS.debug("Login to the MP Account");
			String mpnumber=null;
			String mppin=null;
			  try 
			  {
				  String [] searchdata = data.split(";");
				  if(driver.findElement(By.id("MpNumber")).isDisplayed())
				  {
					  driver.findElement(By.id("MpNumber")).clear();
					  driver.findElement(By.id("MpNumber")).sendKeys(searchdata[0]);
				  }
				  else
				  {
					  return Constants.KEYWORD_FAIL + "<br>" + "Unable to login to the account as MileagePlus Number textbox is not displayed" + "</br>";
				  }
				  
				  if(driver.findElement(By.id("Password")).isDisplayed())
				  {
					  driver.findElement(By.id("Password")).clear();
					  driver.findElement(By.id("Password")).sendKeys(searchdata[1]);
				  }
				  else
				  {
					  return Constants.KEYWORD_FAIL + "<br>" + "Unable to login to the account as the Password or PIN textbox is not displayed" + "</br>";
				  }
				  
				  mpnumber=searchdata[0];
				  mppin=searchdata[1];
				  
				  if(driver.findElement(By.id("btnSignIn")).isDisplayed())
				  {
					  driver.findElement(By.id("btnSignIn")).click();
				  }
				  else
				  {
					  return Constants.KEYWORD_FAIL + "<br>" + "Unable to login to the account as the Sign in button is not displayed" + "</br>";
				  }
				  
				  DymamicWait();
				  WaitAndLoadPage(15);
				  boolean val;
				  val= driver.findElement(By.xpath(OR.getProperty("link_siginedin_Myaccount"))).isDisplayed();
				  if (val==true)
				  {
					  return Constants.KEYWORD_PASS + "<br>" + "Successfully Logged in to the account with the MP Account Number" +"<b>" + searchdata[0]+ "</b>" + "</br>";
				  }
				  else
				  {
					  return Constants.KEYWORD_FAIL + "<br>" + "MP Account login was not successful as the  View account button is not displayed" + "<b>" + "</br>";
				  }
			  }
			  catch (Exception e)
			  {
			  	return Constants.KEYWORD_FAIL + "<br>" + "Unable to login to the account with MPAccount Number " + "<b>" + mpnumber + "</b>" + "and Password:" + "<b>" + mppin + "</b>" + "</br> as" + e.getMessage().substring(0,40);
			  }
		}

/*************************************************************************.
# 64
**************************************************************************
'* Keyword Name         : LoginErrorMsgstepwise
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To validate the Error messages in different steps while login
'* Input Parameters     : data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: LoginErrorMsgstepwise(object, data)
						object:=object is not required
						data  :=Data will be taken from the Excel sheet e.g:col|Mpsignin1sttime
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
**************************************************************************/

		public String LoginErrorMsgstepwise(String object, String data) throws InterruptedException 
		{
			APP_LOGS.debug("To validate the Error messages in different steps while login");
			String errormssg=null;
			try
			{
				String [] searchdata = data.split(";");
				if(driver.findElement(By.id("MpNumber")).isDisplayed())
				{
					driver.findElement(By.id("MpNumber")).clear();
					driver.findElement(By.id("MpNumber")).sendKeys(searchdata[0]);
				}
				else
				{
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to login to the account as MileagePlus Number textbox is not displayed" + "</br>";
				}
				if(driver.findElement(By.id("Password")).isDisplayed())
				{
					driver.findElement(By.id("Password")).clear();
					driver.findElement(By.id("Password")).sendKeys(searchdata[1]);
				}
				else
				{
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to login to the account as the Password or PIN textbox is not displayed" + "</br>";
				}
				errormssg=searchdata[2];
				
				if(driver.findElement(By.id("btnSignIn")).isDisplayed())
				{
					driver.findElement(By.id("btnSignIn")).click();
				}
				else
				{
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to login to the account as the Sign in button is not displayed" + "</br>";
				}
				WaitAndLoadPage(15);
				DymamicWait();
				
				String error = "//div[starts-with(@id,'qtip-')]";
				List<WebElement> xpathfound = driver.findElements(By.xpath(error));
				for (WebElement path:xpathfound) 
				{
					String path1 = 	path.getAttribute("id");
					if (path1 != null &&!path1.equals("")) 
					{
						String needpath = "//*[@id='" + path1 + "']";
						WaitAndLoadPage(3);
						DymamicWait();
						boolean Displayed = driver.findElement(By.xpath(needpath)).isDisplayed();
						if (Displayed == true) 
						{
							String expected = driver.findElement(By.xpath(needpath)).getText();
							if (expected != null && !expected.equals("")) 
							{
								if (expected.equalsIgnoreCase(searchdata[2])) 
								{
									return Constants.KEYWORD_PASS + "<br>" + "<b>" + " Expected error message: " + "</b>" + expected + "and" + "<b>" + " Actual error message: " + "</b>" + searchdata[2]+" matched</br>";
								}
								else 
								{
									return Constants.KEYWORD_FAIL + "<br>" + "<b>" + " Expected error message: " + "</b>" + expected + "and" + "<b>" + " Actual error message: " + "</b>" + searchdata[2]+" did not match</br>";
								}
							}
						}
					}
				}
			}
			catch (Exception Ex)
			{
				return Constants.KEYWORD_FAIL + "<br>" + "Unable to verify the Error message." + errormssg + "as" + Ex.getMessage().substring(0, 40)+ "</br>";
			}
			return Constants.KEYWORD_FAIL + "<br> Error message" + errormssg + "-- validation failed as the error message tooltip is not found" + "</br>";
		}

/*************************************************************************.
# 65
**************************************************************************
'* Keyword Name         : verifyLoginFields
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Verify login fields
'* Input Parameters     : Xpath and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Usage				: verifyLoginFields(object,  data)
						object:=object is not required
						data  :=Data is not required
'* Revision History     :
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'* Comment  : Not Applicable to United.com
**************************************************************************/

		public  String verifyLoginFields(String object, String data) 
		{
			APP_LOGS.debug("Verify login fields");
			boolean isExists_username = false;
			boolean isExists1_password = false;
			boolean isExists2_signin = false;
				try 
				{
					if (driver.findElement(By.xpath(OR.getProperty("username_login_input"))) != null) 
					{
						isExists_username = true;
					}
					else
						isExists_username = false;
					if (isExists_username) 
					{
						if (driver.findElement(By.xpath(OR.getProperty("passwd_login_input"))) != null) 
						{
							isExists1_password = true;
						}
						else
							isExists1_password = false;
					}
					if (isExists_username==true &&  isExists1_password==true)
					{
						if (driver.findElement(By.xpath(OR.getProperty("sign_in_button"))) != null) 
						{
							isExists2_signin = true;
						}
						else
							isExists2_signin = false;
					}
					if (isExists2_signin==true) 
					{
						return Constants.KEYWORD_PASS + "<br>" + "Verification of the Login fields - Username textbox, Password textbox and Sign in button is Successful" + "</br>";
					}
					else if(isExists_username!=true)
					{
						return Constants.KEYWORD_FAIL + "<br>" + "Username textbox is not displayed" + "</br>";
					}
					else if(isExists1_password!=true)
					{
						return Constants.KEYWORD_FAIL + "<br>" + "Password textbox is not displayed" + "</br>";
					}
					else
					{
						return Constants.KEYWORD_FAIL + "<br>" + "Sign in button is not displayed" + "</br>";
					}
				}
				catch (Exception e) 
				{
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to verify the Login fields - Username textbox, Password textbox and Sign in button as " + e.getMessage().substring(0, 40)+ "</br>";
				}
		}

/*************************************************************************.
# 66
**************************************************************************
'* Keyword Name         : verifyBreadCrumbText
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Verify Breadcrumb text
'* Input Parameters     : Xpath and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Usage				: verifyBreadCrumbText(object,  data)
						object:=xpath of the object
						data  :=Data will taken from the Excel sheet e.g:col|data
'* Revision History     :
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'* Comment  : Not Applicable to United.com
**************************************************************************/

	public  String verifyBreadCrumbText(String object, String data) 
	{
		APP_LOGS.debug("Verify Breadcrumb text");
		String objDesc = "";
		try 
		{
			String[] textboxname = object.split("_");
    		int objsize = textboxname.length;
    		objDesc = textboxname[objsize-1];
			if (waitUntilExists(object, "xpath")) 
			{
				String breadCrumbValue = driver.findElement(By.xpath(OR.getProperty(object))).getText();
				String[] aArray =  breadCrumbValue.split(">");
				StringBuilder sb = new StringBuilder();
				for (int i = 0; i < aArray.length; i++) 
				{
					if (i > 0) 
					{
						sb.append(" > ");
					}
					sb.append(aArray[i].replaceAll("\n" , ""));
				}
				if (sb.toString().equals(data)) 
				{
					  return Constants.KEYWORD_PASS + "<br>" + "<b>" + "Actual Breadcrumb text:" + "</b>" + sb.toString() + "<b>" + " Expected Breadcrumb text:" + "</b>" + data +" matched</br>";
				}
				else
					  return Constants.KEYWORD_FAIL + "<br>" + "<b>" + "Expected Breadcrumb text:" + "</b>" + data + " did not match the" + "<b>" + "actual Breadcrumb text:" + "</b>" + sb.toString()+ "</br>";
			} 
			else 
			{
				return Constants.KEYWORD_FAIL + "<br>" + objDesc+ " Breadcrumb does not exist" + "</br>";
			}
		}
		catch (Exception e) 
		{
			return Constants.KEYWORD_FAIL + "<br>" + "Unable to verify the " + objDesc+ " Breadcrumb text as " + e.getMessage().substring(0, 40) + "</br>";
		}
	}

/*************************************************************************.
# 67
**************************************************************************
'* Keyword Name         : verifyWishlistItemDetails
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Verify Wishlist item details
'* Input Parameters     : Xpath and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: verifyWishlistItemDetails(object,  data)
						object:=xpath of the object
						data  :=Data will taken from the Excel sheet e.g:col|data
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'* Comment  : Not Applicable to United.com
**************************************************************************/

	public  String verifyWishlistItemDetails(String object, String data) 
	{
		APP_LOGS.debug("Verify Wishlist item details");
		String objDesc = "";
		boolean isExists = false;
		try 
		{
			String[] textboxname = object.split("_");
    		int objsize = textboxname.length;
    		objDesc = textboxname[objsize-1];
			if (waitUntilExists(object, "xpath")) 
			{
				WebElement table_element = driver.findElement(By.xpath(OR.getProperty(object)));
				List<WebElement> tr_collection = table_element.findElements(By.xpath(OR.getProperty(object) + "/table[2]/tbody/tr/td/table/tbody/tr"));
				String[] aArray =  data.split(",");
			    for (WebElement trElement : tr_collection) 
			    {
			    	List<WebElement> td_collection = trElement.findElements(By.xpath("td"));
			        for (WebElement tdElement : td_collection) 
			        {
			        	for (int i = 0; i < aArray.length; i++) 
			        	{
			        		if (tdElement.getText().contains(aArray[i].trim())) 
			        		{
			        			isExists = true;
			        		}
			            	else
			            		isExists = false;
			        		}
			        	if (isExists) 
			        	{
			        		return Constants.KEYWORD_PASS + "<br>" + objDesc+ "Wishlist item details are found Successfully" + "</br>";
			        	}
			        }
			    }
			}
			else
				return Constants.KEYWORD_FAIL + "<br>" + objDesc+ "Wishlist item Object does not exist" + "</br>";
		}
		catch (Exception e) 
		{
			return Constants.KEYWORD_FAIL + "<br>" + "Unable to verify the" + objDesc+ "Wishlist item details as" + e.getMessage().substring(0, 20) + "<br>";
		}
		return Constants.KEYWORD_FAIL + "<br>" + objDesc+ "Wishlist item Object does not exist" + "</br>";
	}

/*************************************************************************.
# 68
**************************************************************************
'* Keyword Name         : clickOnZoomButtons
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Click on Zoom buttons
'* Input Parameters     : Xpath
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Usage				: clickOnZoomButtons(object,  data)
						object:=xpath of the object
						data  :=NA
'* Revision History     :
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'* Comment  : Not Applicable to United.com
**************************************************************************/

	public  String clickOnZoomButtons(String object, String data) 
	{
		APP_LOGS.debug("Click on Zoom buttons");
		Actions act = new Actions(driver);
		String objDesc = "";
		try 
		{
			String[] textboxname = object.split("_");
    		int objsize = textboxname.length;
    		objDesc = textboxname[objsize-1];
			if (waitUntilExists(object, "xpath")) 
			{
				WebElement devices = driver.findElement(By.xpath(OR.getProperty(object)));
				act.moveToElement(devices).build().perform();
				act.click().build().perform();
				if (data.equals("Zoom In") && data.equals("Zoom Out")) 
				{
					act.click().build().perform();
					return Constants.KEYWORD_PASS + "<br>" + objDesc + "Object is found and successfully clicked on the button" + "</br>";
				}
				else
					return Constants.KEYWORD_FAIL + "<br>" + data + "action cannot be performed on the " + objDesc + " Object" + "</br>";
			}
			else
				return Constants.KEYWORD_FAIL + "<br>" + objDesc + "Object does not exist" + "</br>";
		}
		catch (Exception e) 
		{
			return Constants.KEYWORD_FAIL + "<br>" + "Unable to click on" + objDesc + "zoom button as " + e.getMessage().substring(0, 40) + "</br>";
		}
	}

/*************************************************************************.
# 69
**************************************************************************
'* Keyword Name         : verifyScrollButton
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Verify scroll button position
'* Input Parameters     : Xpath
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Usage				: verifyScrollButton(object,  data)
						object:=xpath of the object
						data  :=NA
'* Revision History     :
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'* Comment  : Not Applicable to United.com
**************************************************************************/

	public  String verifyScrollButton(String object, String data) 
	{
		APP_LOGS.debug("Verify scroll button position");
		String objDesc = "";	
		try 
		{
			String[] textboxname = object.split("_");
    		int objsize = textboxname.length;
    		objDesc = textboxname[objsize-1];
			if (waitUntilExists(object, "xpath")) 
			{
				WebElement scrollButton = driver.findElement(By.xpath(OR.getProperty(object)));
				String style = scrollButton.getAttribute("style");
				if (Float.parseFloat(style.split(";")[1].split(":")[1].replace("%" , "")) > 0) 
				{
					return Constants.KEYWORD_PASS + "<br>" + objDesc + "Scroll Button position is found" + "</br>";
				}
				else 
				{
					return Constants.KEYWORD_FAIL + "<br>" + objDesc + "Scroll Button Object does not exist" + "</br>";
				}
			}
			else
				return Constants.KEYWORD_FAIL + "<br>" + objDesc + "Scroll Button Object does not exist --" + "</br>";
		}
		catch (Exception e) 
		{
			return Constants.KEYWORD_FAIL + "<br>" + "Unable to verify the " + objDesc + " scroll button position as" + e.getMessage().substring(0, 40) + "</br>";
		}
	}

/*************************************************************************.
# 70
**************************************************************************
'* Keyword Name         : mouseHoverNClick
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Mousehover and click the specified object
'* Input Parameters     : Xpath and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Usage				: mouseHoverNClick(object,  data)
						object:=xpath of the object
						data  :=NA
'* Revision History     :
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'* Comment  : Not Applicable to United.com
**************************************************************************/

	public  String mouseHoverNClick(String object, String data) 
	{
		APP_LOGS.debug("Mousehover and click the specified object");	
		String objDesc = "";
		try 
		{
			String[] textboxname = object.split("_");
    		int objsize = textboxname.length;
    		objDesc = textboxname[objsize-1];
			if (waitUntilExists(object, "xpath")) 
			{
				Actions act = new Actions(driver);
				WebElement imgButton = driver.findElement(By.xpath(OR.getProperty(object).split("#")[0]));
				act.moveToElement(imgButton).build().perform();
				WebElement quickView = driver.findElement(By.xpath(OR.getProperty(object).split("#")[1]));
				act.moveToElement(quickView).build().perform();
				act.click().build().perform();
				return Constants.KEYWORD_PASS + "<br>" + "MouseHovered and Successfully clicked on the " + objDesc + " object" + "</br>";
			}
			else
				return Constants.KEYWORD_FAIL + "<br>" + objDesc + "object is not found" + "</br>";
		}
		catch (Exception e) 
		{
			return Constants.KEYWORD_FAIL + "<br>" + "Unable to MouseHover and click on the " + objDesc + " object as " + e.getMessage().substring(0, 40) + "</br>";
		}
	}

/*************************************************************************.
# 71
**************************************************************************
'* Keyword Name         : captureScreenshot
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Capture Screenshot on failure
'* Input Parameters     : Xpath and data
'* Output Parameters    : NA
'* Usage				: captureScreenshot(filename,  keyword_execution_result)
						filename:=filename of the screenshot
						keyword_execution_result  :=keyword_execution_result value is taken from the DriverScript file at runtime
'* Revision History     :
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'* Comment  :
**************************************************************************/

	public void captureScreenshot(String filename, String keyword_execution_result) throws IOException 
	{
		APP_LOGS.debug("Capture Screenshot on failure");
		try 
		{
			// take screen shots
			if (CONFIG.getProperty("screenshot_everystep").equals("Y")) 
			{
				// capturescreen
				File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			    FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir") + "//screenshots//" + filename + ".png"));
			}
			else if (keyword_execution_result.startsWith(Constants.KEYWORD_FAIL) && CONFIG.getProperty("screenshot_error").equals("Y")) 
			{
				// capture screenshot
				File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			    FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir") + "//screenshots//" + filename + ".png"));
			}
		}
		catch (Exception e) 
		{
			System.out.println("Unable to capture screen shot");
			e.getMessage().substring(0, 40);
		}
	}

/*************************************************************************.
# 72
**************************************************************************
'* Keyword Name         : CaptureSID
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Capture SID of old united.com site
'* Input Parameters     : Xpath and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Usage				: CaptureSID(object,  data)
						object:=Xpath of the object
						data  :=data is not required
'* Revision History     :
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'* Comment  : This function used to capture the SID for OLD United.com site
**************************************************************************/

	public  String CaptureSID(String object, String data) 
	{
		APP_LOGS.debug("Capture SID of old united.com site");
		try 
		{
			if (waitUntilExists(object, "xpath")) 
			{
				WebElement SIDobj = driver.findElement(By.xpath(OR.getProperty(object)));
				String SID = SIDobj.getAttribute("value");
				return Constants.KEYWORD_PASS + "<br>" + "Session ID of this iteration is: " + "\"" + "<b>" + SID + "</b>" + "</br>";
			}
			else
				return Constants.KEYWORD_FAIL + "<br>" + "Unable to capture Session ID as the page was not completely loaded" + "</br>";
			}
		catch (Exception e) 
		{
			return Constants.KEYWORD_FAIL + "<br>" + "Unable to Capture session ID as " + e.getMessage().substring(0, 40) + "</br>";
		}
	}

/*************************************************************************.
# 73
**************************************************************************
'* Keyword Name         : WaitAndLoadPage
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Wait for Page Load
'* Input Parameters     : Xpath and data
'* Output Parameters    : NA
'* Usage				: WaitAndLoadPage(Waittime)
						Waittime:=Waittime is taken from the excel sheet col|WaitTimeinSeconds
'* Revision History     :
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'* Comment  :
**************************************************************************/

		public void WaitAndLoadPage(int Waittime) 
		{
			try 
			{
				WebElement myDynamicElement = new WebDriverWait(driver, Waittime).until(new ExpectedCondition<WebElement>() 
						{
						public WebElement apply(WebDriver d) 
						{
							return d.findElement(By.className("PageHeading"));
						}
						});
				System.out.println("'" + (myDynamicElement.getText()) + "' page is displayed");
			}
			catch (Exception e) 
			{
				System.out.println(e.getMessage());
			}
		}

/*************************************************************************.
# 74
**************************************************************************
'* Keyword Name         : GetTextArea
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Get text in the specified area identified by the object
'* Input Parameters     : Xpath
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Usage				: GetTextArea(object,data)
							object:=Xpath of the object
							data:= data is not required
'* Revision History     :
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'* Comment  :
**************************************************************************/

		public  String GetTextArea(String object, String data)throws IOException 
		{
			APP_LOGS.debug("Get text in the specified area identified by the object");
			String objDesc = "";	
			try 
			{
				String[] textboxname = object.split("_");
        		int objsize = textboxname.length;
        		objDesc = textboxname[objsize-1];
				if (waitUntilExists(object, "xpath")) 
				{
					String Actualval = driver.findElement(By.xpath(OR.getProperty(object))).getText();
					return Constants.KEYWORD_PASS + "<br>" + "Successfully Captured text <b> " + Actualval + " </b> from the " + objDesc + "web area </br>";
				}
				else 
				{
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to find the " + objDesc + "web area"+ "</br>";
				}
			}
			catch (Exception e) 
			{
				return Constants.KEYWORD_FAIL + "<br>" + "Unable to get the text from the  " + objDesc + "web area as " + e.getMessage().substring(0, 40) + "</br>";
			}
		}

/*************************************************************************.
# 75
**************************************************************************
'* Keyword Name         : verifyTextBoxLabel
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Verifying the Label of the text box
'* Input Parameters     : Xpath and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Usage				: verifyTextBoxLabel( object,  data)
						object:=Xpath of the object
						data  :=Data will taken from the Excel sheet e.g:col|ExpectedData
'* Revision History     :
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'* Comment  :
'**************************************************************************/

		public  String verifyTextBoxLabel(String object, String data) 
		{
			APP_LOGS.debug("Verifying the Label of the text box");
			String objDesc = "";
			try 
			{
				String[] textboxname = object.split("_");
        		int objsize = textboxname.length;
        		objDesc = textboxname[objsize-1];
				if (waitUntilExists(object, "xpath")) 
				{
					String actual = driver.findElement(By.xpath(OR.getProperty(object))).getAttribute("aria-label");
					String expected = data;
					if (actual.equals(expected)) 
					{
						return Constants.KEYWORD_PASS + "<br>" + "<b>" + "Actual Textbox Label:" + "</b>" + actual + "and " + "<b>" + "Expected Textbox Label:" + "</b>" + expected +"matched </br>";
					}
					else 
					{
						return Constants.KEYWORD_FAIL + "<br>" + "<b>" + "Actual Textbox Label:" + "</b>" + actual + "and " + "<b>" + "Expected Textbox Label:" + "</b>" + expected +"did not match </br>";
					}
				}
				else 
				{
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to find the " + objDesc + " TextBox" + "</br>";
				}
			}
			catch (Exception e) 
			{
				return Constants.KEYWORD_FAIL + "<br>" + "Unable to verify the " + objDesc + " TextBox Label as" + e.getMessage().substring(0, 40) + "</br>";
			}
		}

/*************************************************************************.
# 76
**************************************************************************
'* Keyword Name         : clearText
'* Developed Date 		:
'* Author              	: HCL
'* Purpose            	: To clear the text present in the textbox
'* Input Parameters    	: Xpath
'* Output Parameters  	: Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Usage				: clearText( object,  data)
						object:=Xpath of the object
						data  :=data i not required 
'* Revision History   	:
'*************************************************************************
'* Modified By	:	HCL
'* Reason		:	Was not working properly
'* Date			:	21-Nov-13
'**************************************************************************/

		public  String ClearText(String object, String data) 
		{
			APP_LOGS.debug("To clear the text present in the textbox");
			String objDesc = "";	
			try 
			{
				String[] textboxname = object.split("_");
        		int objsize = textboxname.length;
        		objDesc = textboxname[objsize-1];
				if (waitUntilExists(object, "xpath")) 
				{
					driver.findElement(By.xpath(OR.getProperty(object))).clear();
                }
				else
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to find the " + objDesc + " TextBox" + "</br>"; 
			}
			catch (Exception e) 
			{
				return Constants.KEYWORD_FAIL + "<br>" + "Unable to clear the " + objDesc + " TextBox as " + e.getMessage().substring(0, 40) + "</br>";
			}
			return Constants.KEYWORD_PASS + "<br>" + "Successfully cleared the " + objDesc + " TextBox" + "</br>"; 
		}

/*************************************************************************.
# 77
**************************************************************************
'* Keyword Name         : ChangePOS
'* Developed Date 		:
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To change POS
'* Input Parameters     : Xpath and data
'* Output Parameters    : SID for the Browser

'* Usage				: ChangePOS(String object, String data)
		 				object:=Browser Object
		 				data  :=Data will taken from the Excel sheet e.g:col|POS
'* Revision History     :
'*************************************************************************
'* Modified	:
'* Reason	: To handle Opinion lab pop up
'* Date		: 17-Feb-14
'**************************************************************************/

	public String ChangePOS(String object, String data) 
	{
		APP_LOGS.debug("To change POS");
		try 
		{
			 int maxWaitTime = 20;
			 for (int j = 0; j < maxWaitTime; j++) 
			 {
				 if (driver.findElement(By.xpath("//*[@id='oo_invitation_prompt']")).isDisplayed()) 
				 {
					 driver.findElement(By.xpath("//*[@id='oo_no_thanks']")).click();
					 break;
				 }
				 Thread.sleep(1000);
			 }
			if (waitUntilExists(object, "xpath")) 
			{
				driver.findElement(By.xpath(OR.getProperty(object))).click();
				String posselected = "";
				object = OR.getProperty("Popup_Homepage_ChangePOS");
				//WaitAndLoadPage(5);
				DymamicWait();
				if (driver.findElement(By.xpath("//*[@id='oo_invitation_prompt']")).isDisplayed()) 
				{
					driver.findElement(By.xpath("//*[@id='oo_no_thanks']")).click();
				}
				WebElement regions = driver.findElement(By.xpath("//*[@id='modal-language-pos']/div[1]/div[2]"));
				List<WebElement> regionselection = regions.findElements(By.tagName("a"));
				for (WebElement links:regionselection) 
				{
					links.click();
					//WaitAndLoadPage(5);
					DymamicWait();
					object = OR.getProperty("section_HomePage_POSPopup_Regions");
					WebElement pos = driver.findElement(By.xpath("//*[@id='modal-language-pos']/div[2]"));
					List<WebElement> posselection=pos.findElements(By.tagName("a"));
						for (WebElement poslink:posselection) 
						{
							if (poslink.getText().equalsIgnoreCase(data)) 
							{
								poslink.click();
								//WaitAndLoadPage(5);
								DymamicWait();
								driver.findElement(By.xpath(OR.getProperty("button_ChangePOS_Popup_Change"))).click();
								//WaitAndLoadPage(12);
								DymamicWait();
								posselected = "true";
								break;
							}
						}
					if (posselected.equalsIgnoreCase("true"))
						break;
				}
				if (posselected.equalsIgnoreCase("true")) 
				{
					return Constants.KEYWORD_PASS + "<br>" + "Successfully selected " + "<b>" + data + "</b>" + " as POS" + "</br>";
				}
				else 
				{
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to select " + data + " as POS as the Regions in the Change POS Lightbox did not load" + "</br>";
				}
			}
			else 
			{
				return Constants.KEYWORD_FAIL +"<br>" + data + "Change POS Link is not found" + "</br>";
			}
		}
		catch (Exception e) 
		{
			return Constants.KEYWORD_FAIL + "<br>" + "Unable to change the POS to " + data + " as " + e.getMessage().substring(0, 40)+ "</br>";
		}
	}

/*************************************************************************.
# 78
**************************************************************************
'* Keyword Name         : GetListItems
'* Developed Date 		:
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Fetch all the list elements
'* Input Parameters     : Xpath and data
'* Output Parameters    : Elements in the specified dropdown list
'* Usage				: GetListItems(String object, String data)
		 				object:=Xpath of the Object
		 				data  :=Not required
'* Revision History     :
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

	public String GetListItems(String object, String data) 
	{
		APP_LOGS.debug("Fetch all the list elements");
		String objDesc = "";
		try 
		{
			String[] textboxname = object.split("_");
    		int objsize = textboxname.length;
    		objDesc = textboxname[objsize-1];
			if (waitUntilExists(object, "xpath")) 
			{
				String isExists = "";
				data = "";
				WebElement droplist = driver.findElement(By.xpath(OR.getProperty(object)));
				List<WebElement> droplist_cotents = droplist.findElements(By.tagName("a"));
					for (WebElement option:droplist_cotents) 
					{
						if (option.getText().toString() != null) 
						{
							isExists = isExists + ";" + option.getText().toString();
							data = isExists.substring(1);
						}
					}
					if (isExists == "") 
					{
						return Constants.KEYWORD_FAIL + "<br>" + "There are no items in the " +objDesc+ " Droplist" + "</br>";
					}
			}
			else
				return Constants.KEYWORD_FAIL + "<br>" +objDesc+ " droplist not found" + "</br>";
		}
		catch (Exception e) 
		{
			return Constants.KEYWORD_FAIL + "Unable to fetch the items in the " +objDesc+ " droplist as" + e.getMessage().substring(0, 40)+ "</br>";
		}
		Expectedoutput = data;
		return Constants.KEYWORD_PASS + "<br>" + "Items found in the " +objDesc+ " droplist are:" + "<b>" + data +"</b></br>";	
	}

/*************************************************************************.
# 79
**************************************************************************
'* Keyword Name         : SelectAutoCompleteListItem
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Select an item from the auto complete list
'* Input Parameters     : Xpath and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     :
'* Usage				: SelectAutoCompleteListItem(String object, String data)
						  object:=Xpath of the object
						  data  :=NA
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public String SelectAutoCompleteListItem(String object, String data) 
		{
			APP_LOGS.debug("Select an item from the auto complete list");
			String objDesc = "";	
			try 
			{
				String[] textboxname = object.split("_");
        		int objsize = textboxname.length;
        		objDesc = textboxname[objsize-1];
				if (waitUntilExists(object, "xpath")) 
				{
					String isExists = "";
					WebElement droplist = driver.findElement(By.xpath(OR.getProperty(object)));
					List<WebElement> droplist_cotents = droplist.findElements(By.tagName("a"));
					int listsize = droplist_cotents.size();
					for (int i = 0; i < listsize; i++) {
						String strtemp = droplist_cotents.get(i).getText().toString();
						if (strtemp.equalsIgnoreCase(data)) 
						{
							droplist_cotents.get(i).click();
							isExists = "True";
							break;
						}
					}
					if (isExists != null && isExists.equalsIgnoreCase("True")) {
						return Constants.KEYWORD_PASS + "<br>" + "Selected <b> " + data + "</b> from the " + objDesc + " droplist" + "</br>";
					}
					else 
					{
						return Constants.KEYWORD_FAIL + "<br>" + data + " did not match the items in the " +objDesc+ " droplist" + "</br>";
					}
				}
				else
					return Constants.KEYWORD_FAIL + "<br>" +objDesc+ " droplist is not found" + "</br>";
			}
			catch (Exception e) 
			{
				return Constants.KEYWORD_FAIL + "<br>" + "Unable to select " + data + " from the " +objDesc+ " droplist as " + e.getMessage().substring(0, 40) + "</br>";
			}
		}

/*************************************************************************.
# 80
**************************************************************************
'* Keyword Name         : VerifyAlphabeticalOrderofList
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Verifying Alphabetical Order of all the list elements
'* Input Parameters     : Xpath and data
'* Output Parameters    : Constants.KEYWORD_PASS or Constants.KEYWORD_FAIL
'* Revision History     : 
'* Usage				: VerifyAlphabeticalOrderofList(String Expecteddata, String data)
						Expecteddata:=Return value from GetListItems function
						data :=data is not required
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

	public String VerifyAlphabeticalOrderofList(String Expecteddata, String data) 
	{
		APP_LOGS.debug("Verifying Alphabetical Order of all the list elements");
		try 
		{
			data = "";
			int i = 0;
			char firstchar;
			int firstcharAsci = 0;
			int arrlength = 0;
			// Split the expected values Fetched from the List
			String temp = Expectedoutput;
			String allElements[] = temp.split(";");
			arrlength = allElements.length;
			int[] intArray = new int[arrlength];
			if (arrlength != 0) 
			{
				for (i = 0; i <= arrlength - 1; i++) 
				{
					firstchar = allElements[i].toLowerCase().charAt(0);
					firstcharAsci = (int) firstchar;
					intArray[i] = firstcharAsci;
				}
				for (i = 0; i < intArray.length - 2; i++) 
				{
					if (intArray[i] <= intArray[i + 1]) 
					{
						data = "True";
					}
					else 
					{
						data = "False";
						break;
					}
				}
			}
			else 
			{
				return Constants.KEYWORD_FAIL + "<br>" + "Given list is empty" + "</br>";
			}
		}
		catch (Exception e) 
		{
			return Constants.KEYWORD_FAIL + "<br>" + "Could not verify the alphabetical order of list items as " + e.getMessage().substring(0, 40) + "</br>";
		}
		if (data.equalsIgnoreCase("True")) 
		{
			return Constants.KEYWORD_PASS + "<br>" + "List items " + Expecteddata + " are in alphabetical order" + "</br>";
		}
		else 
		{
			return Constants.KEYWORD_FAIL + "<br>" + "List items " + Expecteddata + " are not in alphabetical order" + "</br>";
		}
	}

/*************************************************************************.
# 81
**************************************************************************
'* Keyword Name         : AlertsHandling
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Handling window alerts using WebDriver
'* Input Parameters     : Xpath and data
'* Output Parameters    : KEYWORD_PASS
'* Revision History     :
'* Usage				: AlertsHandling(object,  data)
						  object:=object is not required
						  data :=data is not required
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public String AlertsHandling(String object, String data) throws IOException {
			try {
				////// Handling window alerts using WebDriver/////////////////////////////
				boolean alertMsg = isAlertPresent();
				boolean alertStatus = true;
			   if (alertMsg == alertStatus) {
				   Alert alert = driver.switchTo().alert();
				   String alertgtext = alert.getText();
				   String alertgtext1 = alertgtext.toUpperCase();
				   String alerttext = data;
				   String alerttext1 = alerttext.toUpperCase();
				   if (alertgtext1.contains(alerttext1)) {
					   alert.accept();
					   return Constants.KEYWORD_PASS + " , Alert is present and handled";
				   }
				   else {
					   return Constants.KEYWORD_PASS + " , Alert not present";
				   }
			   }
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + e.getMessage();
			}
			return Constants.KEYWORD_FAIL + " , Alert not not present";
		}

		public boolean isAlertPresent() {
			try {
				driver.switchTo().alert();
				return true;
			}
			catch (NoAlertPresentException ex) {
				//return Constants.KEYWORD_FAIL+ex.getMessage();
				return false;
			}
		}

/*************************************************************************.
# 82
**************************************************************************
'* Keyword Name         : captureText
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Capture text from specified Xpath
'* Input Parameters     : Xpath and data
'* Output Parameters    : KEYWORD_PASS
'* Revision History     :
'* Usage				: captureText(object,  data)
						  object:=Xpath
						  data :=data is not required
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'
 ***************************************************************************/

	public String captureText(String object, String data) throws InterruptedException {
	APP_LOGS.debug("Capture text from the Xpath");
	try{	
		if (waitUntilExists(object, "xpath")) {
			String text;
			text = driver.findElement(By.xpath(OR.getProperty(object))).getAttribute("value");
			return Constants.KEYWORD_PASS + "<br>" + "The Captured text is :" + text + "</br>";
		}
		else {
			return Constants.KEYWORD_FAIL + "<br>" + "Unable to find the object in the application" + "</br>";
		}
	}
	catch (Exception e) {
		return Constants.KEYWORD_FAIL + "<br>" + "Unable to capture text from the application" + "</br>";
	}
	}

/*************************************************************************.
# 83
**************************************************************************
'* Keyword Name         : verifyFieldFocus
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Verify the focus to the next field
'* Input Parameters     : Xpath and data
'* Output Parameters    : KEYWORD_PASS
'* Revision History     :
'* Usage				: captureText(object,  data)
						  object:=Xpath
						  data :=data from excel sheet
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'
 ***************************************************************************/

	public String verifyFieldFocus(String object, String data) {
		APP_LOGS.debug("Verify the field focus");
		String objDesc = "";
		String[] textboxname = object.split("_");
		int objsize = textboxname.length;
		objDesc = textboxname[objsize-1];
		String cssstylevalue = NULL;
		try {
			if (waitUntilExists(object, "xpath")) {
				cssstylevalue = driver.findElement(By.xpath(OR.getProperty(object))).getAttribute("style");
				if (cssstylevalue.equalsIgnoreCase(data))
					return Constants.KEYWORD_PASS + "<br>" + "Focused to the "+ objDesc +" field" + cssstylevalue + "</br>";
				else
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to focus on the "+ objDesc +" object" + cssstylevalue + "</br>";
			}
			else	
			return Constants.KEYWORD_FAIL + "<br>" + "Unable to find the object" + cssstylevalue + "</br>";
			
		}
		catch (Exception e) {
			return Constants.KEYWORD_FAIL + "<br>" + " - Could not find the object " + e.getMessage().substring(0, 40) + "</br>";
		}
		
	}

/*************************************************************************.
# 84
**************************************************************************
'* Keyword Name         : verifyDateEntered
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Verify Date entered
'* Input Parameters     : Xpath and data
'* Output Parameters    : KEYWORD_PASS
'* Revision History     :
'* Usage				: verifyDateEntered(object,  data)
						  object:=Xpath
						  data :=data from excel sheet
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'
'***************************************************************************/

	public String verifyDateEntered(String object, String data) {
		APP_LOGS.debug("Validate given date against date selected in the Calendar");
        String objDesc = "";
        String[] textboxname = object.split("_");
		int objsize = textboxname.length;
		objDesc = textboxname[objsize-1];
		try {
			if (waitUntilExists(object, "xpath")) {		
        		String actual = driver.findElement(By.xpath(OR.getProperty(object))).getAttribute("value");
				String expected = data;
				if (actual.equalsIgnoreCase(expected))
					return Constants.KEYWORD_PASS + "<br>" +  "<B>" + "Actual Date: " + "</B>" + actual +  "<B>" + " Expected Date: " + "</B>" + expected + "</br>";
				else
					return Constants.KEYWORD_FAIL + "<br>" +  "<B>" + "Actual Date: " + "</B>" + actual +  "<B>" + " Expected Date: " + "</B>" + expected + " Both dates did not match" + "</br>";
			}
			else
				return Constants.KEYWORD_FAIL + "<br>" + "Object " + objDesc + " does not exist" + "</br>";
		}
		catch (Exception e) {
			return Constants.KEYWORD_FAIL + "<br>" + "Unable to verify entered date " + e.getMessage().substring(0, 40) + "</br>";
		}
	}

/*************************************************************************
# 85
**************************************************************************
'* Keyword Name         : verifyCalendarStartDayofWeek
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Validate given day of week against day displayed as starting day of week in the Calendar
'* Input Parameters     : Xpath and data
'* Output Parameters    : KEYWORD_PASS
'* Revision History     :
'* Usage				: verifyDateEntered( object,  data)
						object:=Xpath of the object
						data  :=Data will taken from the Excel sheet e.g:col|DayofWeek
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

	public String verifyCalendarStartDayofWeek(String object, String data) {
		APP_LOGS.debug("Validate given day of week against day displayed as starting day of week in the Calendar");
		String objDesc = "";
		String[] textboxname = object.split("_");
		int objsize = textboxname.length;
		objDesc = textboxname[objsize-1];
		try {
			if (waitUntilExists(object, "xpath")) {				
				String actualExpandedWeek = driver.findElement(By.xpath(OR.getProperty(object))).getAttribute("title");
				String actualWeekshortform = driver.findElement(By.xpath(OR.getProperty(object))).getText();
				String[] strday = data.split(";");
				String expectedWeekshortform = strday[0];
		    	String expectedExpandedWeek = strday[1];
		    	if(actualExpandedWeek.equalsIgnoreCase(expectedExpandedWeek) && actualWeekshortform.equalsIgnoreCase(expectedWeekshortform))
		    		return Constants.KEYWORD_PASS + "<br>" + "<B>" +"Actual Start day of week: " + "</B>" + actualExpandedWeek + "<B>" + " Expected Start day of week: " + "</B>" + expectedExpandedWeek + "</br>";
		    	else
		    		return Constants.KEYWORD_FAIL + "<br>" + "<B>" +"Actual Start day of week: " + "</B>" + actualExpandedWeek + "<B>" + " Expected Start day of week: " + "</B>" + expectedExpandedWeek + ";did not match" + "</br>";
			}
			else
	        	return Constants.KEYWORD_FAIL + "<br>" + "Object " + objDesc + " does not exist" + "</br>";
		}
		catch (Exception e) {
			return Constants.KEYWORD_FAIL + "<br>" + " Unable to validate given day of week against day displayed as starting day of week in the Calendar" + e.getMessage().substring(0, 40) + "</br>";
		}
	}

/*************************************************************************.
# 86
**************************************************************************
'* Keyword Name         : navigateUsingKeyboardArrows
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Navigate using keyboard arrows in the auto complete list
'* Input Parameters     : Xpath and data
'* Output Parameters    : KEYWORD_PASS
'* Revision History     :
'* Usage				: navigateUsingKeyboardArrows( object,  data)
						object:=Xpath of the object
						data  :=NA
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

	public String navigateUsingKeyboardArrows(String object, String data) {
		APP_LOGS.debug("Navigate using keyboard arrows in the auto complete list");
		String objDesc = "";
		String[] textboxname = object.split("_");
		int objsize = textboxname.length;
		objDesc = textboxname[objsize-1];
		try {
			String isExists = "";
			if (waitUntilExists(object, "xpath")) {					      		
				WebElement droplist = driver.findElement(By.xpath(OR.getProperty(object)));
				List<WebElement> droplist_cotents = droplist.findElements(By.tagName("a"));
				int listsize = droplist_cotents.size();
				if (listsize >= 3) {
					listsize = 3;
					for (int i = 1; i <= listsize; i++) {
						droplist.sendKeys(Keys.ARROW_DOWN);
						isExists = "True";
					}
					for (int i = listsize; i >= 1; i--) {
						droplist.sendKeys(Keys.ARROW_UP);
						isExists = "True";
					}
				}
				else {
					for (int i = 1; i <= listsize; i++) {
						droplist.sendKeys(Keys.ARROW_DOWN);
						isExists = "True";
					}
					for (int i = listsize; i >= 1; i--) {
						droplist.sendKeys(Keys.ARROW_UP);
						isExists = "True";
					}
				}
				if (isExists != null && isExists.equalsIgnoreCase("True"))
					return Constants.KEYWORD_PASS + "<br>" + "Able to navigate using keyboard arrows" + "</br>";
				else 
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to navigate using keyboard arrows" + "</br>";
			}
			else
				return Constants.KEYWORD_FAIL + "<br>" + "Not able to find the object " + objDesc + "</br>";
		}
		catch (Exception e) {
			return Constants.KEYWORD_FAIL + "<br>" + "Unable to navigate using keyboard arrows" + e.getMessage().substring(0, 40) + "</br>";
		}
	}

/*************************************************************************.
# 87
**************************************************************************
'* Keyword Name         : verifyAutoCompleteList
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To verify the values in the auto complete list
'* Input Parameters     : Xpath and data
'* Output Parameters    : KEYWORD_PASS
'* Revision History     :
'* Usage				: verifyAutoCompleteList( object,  data)
						object:=Xpath of the object
						data  :=Data will taken from the Excel sheet
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

	public String verifyAutoCompleteList(String object, String data) {
		APP_LOGS.debug("To verify the values in the auto complete list");
		String objDesc = "";
		String[] textboxname = object.split("_");
		int objsize = textboxname.length;
		objDesc = textboxname[objsize-1];
		try {
			String isExists = "";
			if (waitUntilExists(object, "xpath")) {		
				       		
				//String isExists = "";
				WebElement droplist= driver.findElement(By.xpath(OR.getProperty(object)));
				List<WebElement> droplist_cotents = droplist.findElements(By.tagName("a"));
				String testData[] = data.split(";");
				int listsize = droplist_cotents.size();
				//int count = 0;
				if(listsize == 0 && testData[1].equalsIgnoreCase("true")) {
					return Constants.KEYWORD_PASS + "<br>" + "Data does not exist for the given input " + testData[0] + "' in the autopopulated list";
				}
				else if(listsize == 0 && testData[1].equalsIgnoreCase("false")) {
					return Constants.KEYWORD_FAIL + "<br>" + "Data does not exist for the given input '" + testData[0] + "' in the autopopulated list";
				}
				for (int i = 0; i < listsize; i++) {
					String strtemp = droplist_cotents.get(i).getText().toString();
					strtemp = strtemp.toLowerCase();
					data = testData[0].toLowerCase();
					if (strtemp.contains(data)) {
						isExists = "True";
					}
				}
				if (isExists != null && isExists.equalsIgnoreCase("True"))
					return Constants.KEYWORD_PASS + "<br>" + "Sucessfully verified values in the autocomplete list" + "</br>";
				else
					return Constants.KEYWORD_FAIL + "<br>" + "Improper or no data exists in autocomlete list" + "</br>";
			}
			else
				return Constants.KEYWORD_FAIL + "<br>" + "Not able to find the object " + objDesc + "</br>";
		}
		catch (Exception e) {
			return Constants.KEYWORD_FAIL + "<br>" + "Unable to verify auto complete list" + e.getMessage() + "</br>";
		}
	}

/*************************************************************************.
# 88
**************************************************************************
'* Keyword Name         : verifyLinkExists
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To verify the link exists
'* Input Parameters     : Xpath and data
'* Output Parameters    : KEYWORD_PASS
'* Revision History     :
'* Usage				: verifyLinkExists(object,  data)
						object:=Xpath of the object
						data  :=Data will taken from the Excel sheet e.g:col|ExpectedLink
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

	public String verifyLinkExists(String object, String data) {
	    try {
	        List<WebElement> links = driver.findElements(By.tagName("a"));
	        System.out.println(links.size());
	          for (WebElement myElement : links) {
	        	  String link = myElement.getText();
	        	  if (link != "") {
	        		  if (link.equalsIgnoreCase(data)) {
	        			  //WaitAndLoadPage(5);
	        			  DymamicWait();
	        			  return Constants.KEYWORD_PASS + "<br>" + data + " is displayed in the application" + "</br>";
	        		  }
	        	  }
	          }
	          
	          return Constants.KEYWORD_FAIL + "<br>" + data + " is not displayed in the application" + "</br>";
	          
	    }
	    catch (Exception e) {
	        	return Constants.KEYWORD_FAIL + "<br>" + "Not able to verify whether "+ data + "is displayed in the application " + e.getMessage().substring(0, 40) + "</br>";
	    }
	        
	}

/*************************************************************************.***************
# 89
*********************************************************************************
'* Keyword Name         : getTableHeaders
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Retrieves table headers and compares the given data with table headers
'* Input Parameters     :
'* Output Parameters    : KEYWORD_PASS
'* Revision History     :
'* Usage				: getTableHeaders( object,  data)
						object:= Xpath of the table 
						data  :=   To cross check the table headers with the given data
'*-----------------------------------------------------------------------------------
'* Modified	:
'* Reason	:
'* Date	:
'*************************************************************************************************/

		public  String getTableHeaders(String object, String data) {
		    APP_LOGS.debug("Retrieves table headers and compares the given data with table headers");
		    try {
		    	if (waitUntilExists(object, "xpath")) {
		    		List<WebElement> totalHeaders = driver.findElements(By.xpath(OR.getProperty(object) + "/tbody/tr/th"));
		    		String temp = data;
		    		String allElements[] = temp.split(";");
		    		int counter = 0;
		    		int NoOfElements = allElements.length;
		    		for (int i = 0; i <allElements.length; i++) {
		    			for(int j = 0; j <=totalHeaders.size(); j++) {
		    				String name = totalHeaders.get(j).getText();
					 		if (allElements[i].equalsIgnoreCase(name)) {
					 			counter = counter + 1;
					 			break;
					 		}
		    			}
		    		}
		    		if (counter==NoOfElements)
		    			return Constants.KEYWORD_PASS + "<br>" + "Table headers matched exactly with the expected data" + data + "</br>";
		    		else
		    			return Constants.KEYWORD_FAIL + "<br>" + "Table headers did not matched exactly with the expected data"  + data + "</br>";
		    	}
		    	else
		    	 	return Constants.KEYWORD_FAIL + "<br>" + "Not able to find the table or table does not contains any headers" + "</br>";
		    }
		    catch (Exception e) {
		    	return Constants.KEYWORD_FAIL + "<br>" + "Not able to compare the data displayed in the table " + e.getMessage().substring(0, 40) + "</br>";
		    }
		}

/*************************************************************************.
# 90
**************************************************************************
'* Keyword Name         : VerifyCalendarFutureDateIsClick
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To verify whether the user is able to select Future Date from the Calendar
'* Input Parameters     : Xpath and data
'* Output Parameters    : KEYWORD_PASS
'* Revision History     :
'* Usage				: VerifyCalendarFutureDateIsClick( object,  data)
						  object:=Xpath of the object
						  data  :=Data will taken from the Excel sheet e.g:col|Date
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		: 12/11/2013
'**************************************************************************/

		public String VerifyCalendarFutureDateIsClick(String object, String data) {
			APP_LOGS.debug("To verify whether the user is able to select Future Date from the Calendar");
			String objDesc = "";
			String[] textboxname = object.split("_");
			int objsize = textboxname.length;
			objDesc = textboxname[objsize-1];
				try {
					if (waitUntilExists(object, "xpath")) {
						String isSelected = null;
						int date = Integer.parseInt(data);
						Calendar cal = Calendar.getInstance();
				        cal.setTimeZone(TimeZone.getTimeZone("GMT"));
				        cal.add(Calendar.DATE, date);
				        String newdate = cal.getTime().toString();
					    String[] dateconv = newdate.split(" ");
					    String strmonth = dateconv[1];
					    String strday = dateconv[2];
					    String stryear = dateconv[5];
					    String[] montharray = new String[]{"JANUARY" , "FEBRUARY" , "MARCH" , "APRIL" , "MAY" , "JUNE" , "JULY" , "AUGUST" , "SEPTEMBER" , "OCTOBER" , "NOVEMBER" , "DECEMBER"};
					    for (int i = 0; i <montharray.length; i++) {
					    	String strtocmp = montharray[i].substring(0, 3);
					    	if (strtocmp.equalsIgnoreCase(strmonth.toLowerCase())) {
					    		strmonth = montharray[i];
					    		break;
					    	}
					    }
					    String calmonthyear = strmonth + " " + stryear;
					    for (int j = 0; j < 12; j++) {
							 String xpathcalendarone = "";
							 xpathcalendarone = OR.getProperty(object) + "/div[1]/div/div";
							 xpathcalendarone = driver.findElement(By.xpath(xpathcalendarone)).getText();
							 String xpathcalendartwo = "";
							 xpathcalendartwo = OR.getProperty(object) + "/div[2]/div/div";
							 xpathcalendartwo = driver.findElement(By.xpath(xpathcalendartwo)).getText();
							 if (xpathcalendarone.equalsIgnoreCase(calmonthyear)) {
								 WebElement dateWidget = driver.findElement(By.xpath(OR.getProperty("List_HomePage_Flight_DeptDatePickone")));
								//List<WebElement> rows=dateWidget.findElements(By.tagName("tr"));
								List<WebElement> columns = dateWidget.findElements(By.tagName("td"));
								for (WebElement col: columns) {
									if (col.getText().equalsIgnoreCase(strday)) {
										isSelected = col.getAttribute("class");
										isSelected = isSelected.replace(" " , "");
										if(isSelected != null && (isSelected.toLowerCase().indexOf("disabled") > 0)) {
											isSelected = "true";
											break;
										}
										else if(isSelected.equalsIgnoreCase("") || (isSelected.toLowerCase().indexOf("week-end") > 0)) {
											isSelected = "false";
										}
									}
								}
							 }
							 else if (xpathcalendartwo.equalsIgnoreCase(calmonthyear)) {
								 WebElement dateWidget = driver.findElement(By.xpath(OR.getProperty("List_HomePage_Flight_DeptDatePicktwo")));
								 //List<WebElement> rows=dateWidget.findElements(By.tagName("tr"));
								 List<WebElement> columns = dateWidget.findElements(By.tagName("td"));
								 for (WebElement col: columns) {
									 if (col.getText().equalsIgnoreCase(strday)) {
										 isSelected = col.getAttribute("class");
										 isSelected = isSelected.replace(" " , "");
										 VerifyfontColorofSpecificDate(object, data);
										 col.click();
										 return Constants.KEYWORD_PASS + "<br>" + "Able to click on future date in " + objDesc + "calendar field" +(Integer.parseInt(data)) + "Calendar Date is :" + strday + "</br>";
									 }
								 }
							 }
							 else {
								 driver.findElement(By.xpath("//*[@title='Next']")).click();
								 isSelected = "false";
							 }
					    }
					}
				}
				catch (Exception e) {
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to click on future date in " + objDesc + "calendar field" + e.getMessage().substring(0, 40) + "</br>";
				}
				return data;
		}

/*************************************************************************.*************************
# 91
*****************************************************************************************
'* Keyword Name         : VerifyExistenceOfCharacter
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To verify existence of a character within given String
'* Input Parameters     :
'* Output Parameters    : KEYWORD_PASS
'* Revision History     :
'* Usage			    :VerifyExistenceOfCharacter( object,  data)
						object:= Xpath of the object
						data  := Character to search for
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date	:
'****************************************************************************************************/

		public  String VerifyExistenceOfCharacter(String object, String data) {
		    APP_LOGS.debug("To verify existence of a character within given String");
		    String objDesc = "";
			String[] textboxname = object.split("_");
			int objsize = textboxname.length;
			objDesc = textboxname[objsize-1];
		    try {
		    	if (waitUntilExists(object, "xpath")) {
		    		String actual = driver.findElement(By.xpath(OR.getProperty(object))).getText();
		        	int temp = actual.lastIndexOf(data);
		        	if (temp >= 0) {
						return Constants.KEYWORD_PASS + "<br>" + "Expected character found " + data + "</br>";
					} else {
						return Constants.KEYWORD_FAIL + "<br>" + "Expected character did not found " + data + "</br>";
					}
		    	} else {
					return Constants.KEYWORD_FAIL + "<br>" + "Object "+ objDesc +" not found in the application" + "</br>";
				}
		    }
		    catch (Exception e) {
		    	return Constants.KEYWORD_FAIL + "<br>" + "Unable to verify existence of the character with given text " + e.getMessage().substring(0, 40) + "</br>";
		    }
		}

/*************************************************************************.
# 92
**************************************************************************
'* Keyword Name         : VerifyCalendarFutureDateIsNotClickable
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To verify whether the user is able to select Future Date from the Calendar
'* Input Parameters     : Xpath and data
'* Output Parameters    : KEYWORD_PASS
'* Revision History     :
'* Usage				: VerifyCalendarFutureDateIsNotClickable( object,  data)
						object:=Xpath of the object
						data  :=Data will taken from the Excel sheet e.g:col|Date
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		: 12/11/2013
'**************************************************************************/

		public String VerifyCalendarFutureDateIsNotClickable(String object, String data) {
			APP_LOGS.debug("To verify whether the user is able to select Future Date from the Calendar");
			try {
				if (waitUntilExists(object, "xpath")) {
					String isSelected = null;
					int date = Integer.parseInt(data);
					Calendar cal = Calendar.getInstance();
					cal.setTimeZone(TimeZone.getTimeZone("GMT"));
					cal.add(Calendar.DATE, date);
					String newdate = cal.getTime().toString();
					String[] dateconv = newdate.split(" ");
					String strmonth = dateconv[1];
					String strday = dateconv[2];
					String stryear = dateconv[5];
					String[] montharray = new String[]{"JANUARY" , "FEBRUARY" , "MARCH" , "APRIL" , "MAY" , "JUNE" , "JULY" , "AUGUST" , "SEPTEMBER" , "OCTOBER" , "NOVEMBER" , "DECEMBER"};
					for (int i = 0; i <montharray.length; i++) {
						String strtocmp = montharray[i].substring(0, 3);
						if (strtocmp.equalsIgnoreCase(strmonth.toLowerCase())) {
							strmonth = montharray[i];
							break;
						}
					}
					String calmonthyear = strmonth + " " + stryear;
					for (int j = 0; j < 12; j++) {
						String xpathcalendarone = "";
						xpathcalendarone = OR.getProperty(object) + "/div[1]/div/div";
						xpathcalendarone = driver.findElement(By.xpath(xpathcalendarone)).getText();
						String xpathcalendartwo = "";
						xpathcalendartwo = OR.getProperty(object) + "/div[2]/div/div";
						xpathcalendartwo = driver.findElement(By.xpath(xpathcalendartwo)).getText();
						if (xpathcalendarone.equalsIgnoreCase(calmonthyear)) {
							WebElement dateWidget = driver.findElement(By.xpath(OR.getProperty("List_HomePage_Flight_DeptDatePickone")));
							//List<WebElement> rows=dateWidget.findElements(By.tagName("tr"));
							List<WebElement> columns = dateWidget.findElements(By.tagName("td"));
							for (WebElement col: columns) {
								if (col.getText().equalsIgnoreCase(strday)) {
									isSelected = col.getAttribute("class");
									isSelected = isSelected.replace(" " , "");
									if (isSelected != null && (isSelected.toLowerCase().indexOf("disabled") > 0)) {
										isSelected = "true";
										break;
									}
									else if (isSelected.equalsIgnoreCase("") || (isSelected.toLowerCase().indexOf("week-end") > 0)) {
										isSelected = "false";
									}
								}
							}
						}
						else if (xpathcalendartwo.equalsIgnoreCase(calmonthyear)) {
							WebElement dateWidget = driver.findElement(By.xpath(OR.getProperty("List_HomePage_Flight_DeptDatePicktwo")));
							//List<WebElement> rows=dateWidget.findElements(By.tagName("tr"));
							List<WebElement> columns=dateWidget.findElements(By.tagName("td"));
							for (WebElement col: columns) {
								if (col.getText().equalsIgnoreCase(strday)) {
									isSelected = col.getAttribute("class");
									isSelected = isSelected.replace(" " , "");
									if (isSelected != null && (isSelected.toLowerCase().indexOf("disabled") > 0)) {
										isSelected = "true";
										break;
									}
									else if (isSelected.equalsIgnoreCase("") || (isSelected.toLowerCase().indexOf("week-end") > 0)) {
										isSelected = "false";
									}
								}
							}
						}
						else {
							driver.findElement(By.xpath("//*[@title='Next']")).click();
							isSelected = "false";
						}
					}
					if (isSelected != null && (isSelected.equalsIgnoreCase("true"))) {
						return Constants.KEYWORD_PASS + "<br>" + "Unable to Select future date of " + (Integer.parseInt(data)) + " days from the Calendar as the link is disabled" + "</br>";
					}
					else if (isSelected != null && (isSelected.equalsIgnoreCase("false"))) {
						return Constants.KEYWORD_FAIL + "<br>" + "Able to select future date of " + (Integer.parseInt(data)) + " days from the Calendar" + "</br>";
					}
					else {
						return Constants.KEYWORD_FAIL + "<br>" + "Unable to determine whether the given future date " + (Integer.parseInt(data)) + " is selectable in the Calendar " + "</br>";
					}
				}
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>" + "Unable to find Calendar " + e.getMessage().substring(0, 40)  + "</br>";
			}
			return data;
		}

/*************************************************************************.
# 93
**************************************************************************
'* Keyword Name         : getClassAttribute
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To Get class attribute and verify existence of a character within given String
'* Input Parameters     :
'* Output Parameters    : KEYWORD_PASS
'* Revision History     :
'* Usage			    :getClassAttribute( object,  data)
						object:= Xpath of the object
						data  := Character to search for
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date	:
'**************************************************************************/

		public  String getClassAttribute(String object, String data) {
			APP_LOGS.debug("To Get class attribute and verify existence of a character within given String");
			String objDesc = "";
			String[] textboxname = object.split("_");
			int objsize = textboxname.length;
			objDesc = textboxname[objsize-1];
		    try {
		    	if (waitUntilExists(object, "xpath")) {
		        	String actual = driver.findElement(By.xpath(OR.getProperty(object))).getAttribute("Class");
		        	int temp = actual.lastIndexOf(data);
		        	if(temp >= 0)
		        		return Constants.KEYWORD_PASS + "<br>" + "<B>" + data + "</B>" + "Expected character found" + "</br>";
		        	else
		        		return Constants.KEYWORD_FAIL + "<br>" + "<B>" + data + "</B>" + "Expected character did not found" + "</br>";
		    	}
		    	else
		    		return Constants.KEYWORD_FAIL + "<br>" + "Object "+ objDesc + " not found" + "</br>";
		    }
		    catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>" + "Unable to verify existence of the Object with given text " + e.getMessage().substring(0, 40)  + "</br>";
		    }
		}

		
/*************************************************************************.
# 94
**************************************************************************
'* Keyword Name         : verifyLinkInGivenArea
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To verify the link existence in the given list
'* Input Parameters     : Xpath and data
'* Output Parameters    : KEYWORD_PASS
'* Revision History     :
'* Usage				: verifyLinkInGivenArea( object,  data)
						object:=Xpath of the object
						data  :=data will taken from Excel sheet
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String verifyLinkInGivenArea(String object, String data) {
		        APP_LOGS.debug("To verify the link existence in the given list");
		        String objDesc = "";
				String[] textboxname = object.split("_");
	    		int objsize = textboxname.length;
	    		objDesc = textboxname[objsize-1];
		        try {
		        	//pause("3" , "");
		            if (waitUntilExists(object, "xpath")) {
		                // logic to find a random value in list
		                WebElement droplist = driver.findElement(By.xpath(OR.getProperty(object)));
		                List<WebElement> tr_Links = droplist.findElements(By.tagName("a"));
		                List<WebElement> tr_Listvalues = droplist.findElements(By.tagName("li"));
		                String link = "";
		                String text = "";
		                int valueSelected = 0;
		                int count = 0;
		                String linktext = "";
		                String[] allvalues = data.split(";");
		                int valuesize = allvalues.length;
		                String firstelement = allvalues[0];
		                //String allvalues1 = Integer.String(allvalues[0]);
		                if (firstelement.equalsIgnoreCase("true")) {
		                	for (WebElement trElement : tr_Links) {
		                		link = trElement.getAttribute("href");
		                		text = trElement.getText();
			                	for(int i = 1; i < valuesize; i++) {
			                		if (link != "" && text.equalsIgnoreCase(allvalues[i])) {
					                	count = count + 1;
					                }
					            }
			                }
		                	if (count == valuesize - 1)
			                	return Constants.KEYWORD_PASS + "<br>" + "Links are available for the given values in " + objDesc + "</br>";
				        }
		                if (firstelement.equalsIgnoreCase("false")) {
		                	for (WebElement trElement1 : tr_Links) {
		                		text = trElement1.getText();
		                		for (int i = 1; i < valuesize; i++) {
			                		if (text.equalsIgnoreCase(allvalues[i])) {
			                			valueSelected = valueSelected + 1;
			                			linktext = text;
					                }
					            }
	                		}
		                	if (valueSelected == 0) {
		                		for (WebElement trElement : tr_Listvalues) {
		                			text = trElement.getText();
			                		for (int i = 1; i < valuesize; i++) {
				                		if (text.equalsIgnoreCase(allvalues[i])) {
						                	count = count + 1;
						                }
						            }
				                }
		                	}
		                	else
		                		return Constants.KEYWORD_FAIL + "<br>" + "Link is available for " + linktext + "</br>";
		                	if (count == valuesize - 1)
			                	return Constants.KEYWORD_PASS + "<br>" + "Given links are not clickable" + "</br>";
		                }
		            }
		            else
		            	return Constants.KEYWORD_FAIL + "<br>" + objDesc + " object does not exist" + "</br>";
		        }
		        catch (Exception e) {
		            	return Constants.KEYWORD_FAIL + "<br>" + "Improper data " + e.getMessage().substring(0, 40) + "</br>";
		            }
		        return Constants.KEYWORD_FAIL + "<br>" + "Data is mismatched" + "</br>";
		    }
/*************************************************************************.
# 95
**************************************************************************
'* Keyword Name         : selectListUsingDownArrow
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To select the value from the list by down arrow send key 
'* Input Parameters     : Xpath and data
'* Output Parameters    : KEYWORD_PASS
'* Revision History     :
'* Usage				: selectListUsingDownArrow( object,  data)
						  object:=Xpath of the object
						  data  :=NA
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String selectListUsingDownArrow(String object, String data) {
			APP_LOGS.debug("To select the value from the list by down arrow send key");
			String objDesc = "";
			String[] textboxname = object.split("_");
			int objsize = textboxname.length;
			objDesc = textboxname[objsize-1];
			try {
				// logic to find a random value in list
				WebElement droplist = driver.findElement(By.xpath(OR.getProperty(object))); 
				List<WebElement> droplist_cotents = droplist.findElements(By.tagName("option"));
				String valueselected = "";
				//String isExists = "";
				int listsize = droplist_cotents.size();
				driver.findElement(By.xpath(OR.getProperty(object))).click();
				for (int i = 0; i < listsize; i++) {
					String strtemp = droplist_cotents.get(i).getText().toString();
					if (strtemp.equalsIgnoreCase(data)) {
						droplist_cotents.get(i).click();
						valueselected = "True";
						DymamicWait();
						break;
					}
				}
				if (valueselected == "True")
					return Constants.KEYWORD_PASS + "<br>" + "Able to select" + data + "value from" +objDesc+"list box using down arrow" + "</br>";
				else
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to select" + data + "value from" +objDesc+"list box using down arrow" + "</br>";
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>" + "Could not select value from list box using down arrow " + e.getMessage() + "</br>";
			}
			
		}

/*************************************************************************.
# 96
**************************************************************************
'* Keyword Name         : flexibleDatesBeforeDepartDate
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To check whether flexible dates is before depart date
'* Input Parameters     : Xpath and data
'* Output Parameters    : KEYWORD_PASS
'* Revision History     :
'* Usage				: flexibleDatesBeforeDepartDate( object,  data)
						object:=Xpath of the object
						data  :=Data will taken from the Excel sheet e.g:col|WaitForText
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public String flexibleDatesBeforeDepartDate(String object, String data) {
			//WaitAndLoadPage(50);
	        DymamicWait();
	        APP_LOGS.debug("Check box before calendar");
	        String objDesc = "";
			String[] textboxname = object.split("_");
			int objsize = textboxname.length;
			objDesc = textboxname[objsize-1];
	        int index = 0;
		    try {
		    	if (waitUntilExists(object, "xpath")) {
		    		WebElement divisions = driver.findElement(By.xpath(OR.getProperty(object)));
		    		List<WebElement> divisionlist = divisions.findElements(By.tagName("div"));
		    		//int count=divisionlist.size();
		    		for (WebElement div_element : divisionlist) {
		    			if (div_element.getText().equalsIgnoreCase("My dates are flexible")) {
		    				index = 1;
		    			}
		    			if (index == 1 && div_element.getText().contains("open calendar")) {
		    				index = 2;
		    				break;
		    			}
		    		}
		    		if(index == 2) {
		    			return Constants.KEYWORD_PASS + "<br>" + "Flexible dates field is present before depart date field" + "</br>";
		    		}
		    	}
		    }
		    catch (Exception e) {
		    	return Constants.KEYWORD_FAIL + "<br>" + "Unable to find " + objDesc + "object " + e.getMessage().substring(0, 40) + "</br>";
		    }
		    return Constants.KEYWORD_FAIL + "<br>" + "object "+objDesc+" does not exist" + "</br>";
		}

/*************************************************************************.
# 97
**************************************************************************
'* Keyword Name         : verifyDateEnteredagainstCalendar
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Validating the Date Entered in with Visual Display of the Calendar
'* Input Parameters     : Xpath and data
'* Output Parameters    : KEYWORD_PASS
'* Revision History     :
'* Usage				: verifyDateEnteredagainstCalendar( object,  data)
						object:=Xpath of the object
						data  :=Data will taken from the Excel sheet e.g:col|Date
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String verifyDateEnteredagainstCalendar(String object, String data) {
			APP_LOGS.debug("Validating the Date Entered in with Visual Display of the Calendar");
			String objDesc = "";
			String[] textboxname = object.split("_");
			int objsize = textboxname.length;
			objDesc = textboxname[objsize-1];
			try {
				 if (waitUntilExists(object, "xpath")) {
					 String actual = null;
					 String[] datearray = data.split("/");
					 String[] montharray = new String[]{"JANUARY" , "FEBRUARY" , "MARCH" , "APRIL" , "MAY" , "JUNE" , "JULY" , "AUGUST" , "SEPTEMBER" , "OCTOBER" , "NOVEMBER" , "DECEMBER"};
					 String monthselected = null;
					 for(int i = 0; i < montharray.length; i++) {
						 if (Integer.parseInt(datearray[1]) - 1 == i) {
							 monthselected = montharray[i];
						 }
					 }
					 String expected = datearray[3];
					 String monthandyear = monthselected + " " + datearray[2];
					 String xpathcalendarone = OR.getProperty(object) + "/div[1]/div/div";
					 xpathcalendarone = driver.findElement(By.xpath(xpathcalendarone)).getText();
					 String xpathcalendartwo = OR.getProperty(object) + "/div[2]/div/div";
					 xpathcalendartwo = driver.findElement(By.xpath(xpathcalendartwo)).getText();
					 for (int j = 0; j < 12; j++) {
						 if (xpathcalendarone.equalsIgnoreCase(monthandyear) || xpathcalendartwo.equalsIgnoreCase(monthandyear)) {
							 String strtemp = datearray[1] + ";" + "024";
							 VerifyBackColorofDateSelected(object, strtemp);
							 actual = "true";
							 break;
						 }
						 else {
							 driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/div[2]/div/a")).sendKeys(Keys.ENTER);
							 actual = "false";
						 }
					 }
			    	if (actual.equalsIgnoreCase(expected)) {
						return Constants.KEYWORD_PASS + "</br>" + "Date Entered manually matched the date selected in the Calendar " + "<B>" + " Expected Date:" + "</B>" + expected +  "<B>" + " Actual Date:" + "</B>"+ actual + "</br>";
					} else {
						return Constants.KEYWORD_FAIL + "<br>" + "Date Entered manually doesn't match the date selected in the Calendar " + "<B>" + " Expected Date:" + "</B>" + expected +  "<B>" + " Actual Date:" + "</B>"+ actual + "</br>";
					}
				 } else {
					return Constants.KEYWORD_FAIL + "<br>" + "Not able to find the calendar object" + objDesc + "</br>";
				}
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>" + "Unable to verify the date entered in the calendar" + e.getMessage() + "</br>";
			}
		}

/*************************************************************************.
# 98
**************************************************************************
'* Keyword Name         : clickDynamicHoverLink
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To click on dynamic link in the hover text
'* Input Parameters     : data
'* Output Parameters    : KEYWORD_PASS
'* Revision History     :
'* Usage			    :clickDynamicHoverLink( object,  data)
						object:= Xpath of the hover link
						data  := specify the link to be clicked
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date	:
'**************************************************************************/

		public String clickDynamicHoverLink(String object, String data) {
			APP_LOGS.debug("To click on dynamic link in the hover text");
			String objDesc = "";
			String[] textboxname = object.split("_");
			int objsize = textboxname.length;
			objDesc = textboxname[objsize-1];
			try {
				
				//String[] temp=data.split(";");
				String ID = driver.findElement(By.xpath(OR.getProperty(object))).getAttribute("aria-describedby");
				String needpath = "//*[@id='" + ID + data;
				boolean val = driver.findElement(By.xpath(needpath)).isDisplayed();
				if (val == true) {
					driver.findElement(By.xpath(needpath)).click();		
					DymamicWait();
					return Constants.KEYWORD_PASS + "<br>" + "Successfully clicked on the specified link " + data + "</br>";
				} else {
					return Constants.KEYWORD_FAIL + "<br>" + "" + data + " link not found " + "</br>";
				}
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>" + "Not able to click on the "+ objDesc + " object " + e.getMessage().substring(0, 40) + "</br>";
			}
		}

/*************************************************************************.
# 99
**************************************************************************
'* Keyword Name         : verifyDynamicHoverText
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : To capture dynamic text and compare it with the expected
'* Input Parameters     :
'* Output Parameters    : KEYWORD_PASS
'* Revision History     :
'* Usage			    : verifyDynamicHoverText( object,  data)
						object:= Xpath of the hover link
						data  := Static Xpath of the text and text to be verified
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date	:
'**************************************************************************/

		public String verifyDynamicHoverText(String object, String data) {
			APP_LOGS.debug("To capture dynamic text and compare it with the expected");
			String objDesc = "";
			String[] textboxname = object.split("_");
			int objsize = textboxname.length;
			objDesc = textboxname[objsize-1];
			try {
				String[] temp = data.split(";");
				String ID = driver.findElement(By.xpath(OR.getProperty(object))).getAttribute("aria-describedby");
				String needpath = "//*[@id='" + ID + temp[0];
				boolean val = driver.findElement(By.xpath(needpath)).isDisplayed();
				if (val == true) {
					String actual = driver.findElement(By.xpath(needpath)).getText();
					String expected = temp[1];
					if (actual.equals(expected)) {
						return Constants.KEYWORD_PASS + "<br>" +  "<B>" + " Expected text: " + "</B>" + expected + "<B>" + " Actual text: "+ "</B>" + actual  + "</br>";
					}
					else
						return Constants.KEYWORD_FAIL + "<br>" +  "<B>" + " Expected text: " + "</B>" + expected + "<B>" + " Actual text: "+ "</B>" + actual  + " ;did not match" + "</br>";
				}
			else
	    	 	return Constants.KEYWORD_FAIL + "<br>" + "Not able to find the " + objDesc + " object in the application" + "</br>";
	       }
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>" + "Not able to verify dynamic hover text " + e.getMessage().substring(0, 40) + "</br>";
	       }
		}

/*************************************************************************.
# 100
**************************************************************************
'* Keyword Name         : childItemDoesNotExists
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Retrieves table text and compares given data with text present in table
'* Input Parameters     :
'* Output Parameters    : NA
'* Revision History     :
'* Usage			    : childItemDoesNotExists( object,  data)
						object:= Xpath of the table
						data  := Child Item to search for in the table
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date	:
'**************************************************************************/

		public  String childItemDoesNotExists(String object, String data) {
			APP_LOGS.debug("Retrieves table text and compares given data with text present in table");
			String objDesc = "";
			String[] textboxname = object.split("_");
			int objsize = textboxname.length;
			objDesc = textboxname[objsize-1];
			try {
				int q = 0;
				if (waitUntilExists(object, "xpath")) {
					String TableText = driver.findElement(By.xpath(OR.getProperty(object))).getText();
					q = TableText.lastIndexOf(data);
					if (q > 0) {
						return Constants.KEYWORD_FAIL + "<br>" + "Child item" + data + " found " + "</br>";
					} else {
						return Constants.KEYWORD_PASS + "<br>" + "Child item " + data + " did not found" + "</br>";
					}
   				} else {
					return Constants.KEYWORD_FAIL + "<br>" + "Not able to find the " + objDesc + "object" + "</br>";
				}
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>" + "Not able to find the existence of" + objDesc + "object " + e.getMessage().substring(0, 40) + "</br>";
			}
		}

/*************************************************************************.
# 101
**************************************************************************
'* Keyword Name         : linkTextExists
'* Developed Date 		:
'* Author              	: HCL
'* Purpose              : To check the existence of the link with the given text.
'* Input Parameters     : object, data
'* Output Parameters  	: KEYWORD_PASS
'* Revision History     :
'* Usage				: linkTextExists(object, data)
						  object:=Link text
						  data  :=True
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public String linkTextExists(String object, String data) {
			APP_LOGS.debug("Checking existance of element");
			String objDesc = "";
			String[] textboxname = object.split("_");
			int objsize = textboxname.length;
			objDesc = textboxname[objsize-1];
			try {
				if (waitUntilExists(object, "linkText")) {
					boolean isExists = driver.findElement(By.linkText(OR.getProperty(object))).isDisplayed();
					if (data.equalsIgnoreCase("true") && isExists) {
						// Check for existence of Object
	                	return Constants.KEYWORD_PASS + "<br>" + "The link with text name:" + objDesc + " exists " + "</br>";
					}			                                    
					else if (data.equalsIgnoreCase("false") && !(isExists)) {
						// Check for non-existence of Object
						return Constants.KEYWORD_PASS + "<br>" + "The link with text name:" + objDesc + " does not exists " + "</br>";
					} else {
						return Constants.KEYWORD_FAIL + "<br>" + "The link with text name:" + objDesc + " exists " + "</br>";
					}
				} else {
					return Constants.KEYWORD_FAIL + "<br>" + "Object" + objDesc + " does not exist in the application " + "</br>";
				}
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>" + " Unable to verify the existence of link with the given text " + e.getMessage().substring(0, 40) + "</br>";
			}
		}

/*************************************************************************.
# 102
**************************************************************************
'* Keyword Name         : selectTabKey
'* Developed Date 		:
'* Author              	: HCL
'* Purpose            	: To perform tab keyboard operation
'* Input Parameters    	: NA
'* Output Parameters  	: KEYWORD_PASS
'* Revision History   	:
'* Usage				: selectTabKey( object,  data)
						  object:= Xpath of the object
						  data  := NULL
'*************************************************************************
'* Modified By	:	HCL
'* Reason		:
'* Date			:	31-Dec-13
'**************************************************************************/

		public  String selectTabKey(String object, String data) {
			APP_LOGS.debug("To perform tab keyboard operation");
			try {
				driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(Keys.TAB);
				return Constants.KEYWORD_PASS + "<br>" + "Successfully performed the tab keyboard operation" + "</br>";
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>" + "Unable to perform tab keyboard operation " + e.getMessage().substring(0, 40) + "</br>";
			}
		}

/*************************************************************************.
# 103
**************************************************************************
'* Keyword Name         : VerifyExistenceOfString
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Verifying existence of an Object with text
'* Input Parameters     : Xpath and data
'* Output Parameters    : KEYWORD_PASS
'* Revision History     :
'* Usage				: VerifyExistenceOfString( object,  data)
						object:=Xpath of the object
						data  :=Data will taken from the Excel sheet e.g:col|TextExistence 
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public  String VerifyExistenceOfString(String object, String data) {
			APP_LOGS.debug("Verifying existence of an Object with text");
			String objDesc = "";
			String[] textboxname = object.split("_");
			int objsize = textboxname.length;
			objDesc = textboxname[objsize-1];
		    try {
		    	if (waitUntilExists(object, "xpath")) {
		    		String actual = driver.findElement(By.xpath(OR.getProperty(object))).getText();
		        	String expected = data;
		        	if (actual.contains(expected))
		        		return Constants.KEYWORD_PASS + "<br>" + "The expected data " + "<B>" + expected + "</B>"+ " is present in the actual value " +  "<B>" + actual + "</B>" + "</br>";
		        	else
		        		return Constants.KEYWORD_FAIL + "<br>" + "The expected data " + "<B>" + expected + "</B>"+ " is not present in the actual value " +  "<B>" + actual + "</B>" + "</br>";
		    	}
		    	else
		    		return Constants.KEYWORD_FAIL + "<br>" + "Object " + objDesc + " not found in the application" + "</br>";
		    }
		    catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>" + "Unable to verify existence of the string " + e.getMessage().substring(0, 40) + "</br>";
		    }
		   }

/*************************************************************************.
# 104
**************************************************************************
'* Keyword Name         : datesplitter
'* Developed Date 		:
'* Author               : HCL
'* Purpose              : Verifies the month and year
'* Input Parameters     : Xpath of the object and data
'* Output Parameters    : Constants.KEYWORD_PASS
'* Revision History     :
'* Usage				: monthaandyearcomparision(object, data)
						  object:=Xpath of the object
						  data  :=Data will be taken from the Excel sheet e.g:col|No.of Days to be incremented;True or False
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
'**************************************************************************/

		public static String datesplitter(Date inputdata, String val) throws IOException {
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
			String date = formatter.format(inputdata);
			String[] elements = date.split("-");
			//int elm[] = Integer.valueOf(elements[]);
			String retval = NULL;
			if (val.equals("dd")) {
				retval = elements[0];
				//return Constants.KEYWORD_PASS+"-- The date is --"+retval;
			}
			else if (val.equals("mm")) {
				int monthno = Integer.parseInt(elements[1]);
				retval=getMonthForInt(monthno);
				//return Constants.KEYWORD_PASS+"-- The Month is --"+retval;
			}
			else if(val.equals("yy")) {
				retval=elements[2];
				//return Constants.KEYWORD_PASS+"-- The Year is --"+retval;
			}
			/*else {
			  	return Constants.KEYWORD_FAIL;
		     }*/
			return retval;
		}

/*************************************************************************.
# 105
**************************************************************************
'* Keyword Name         : DymamicWait
'* Developed Date 		: 03-Feb-14
'* Author               : HCL
'* Purpose              : This method will wait till the ajax and page is loaded completely
'* Input Parameters     : data
'* Output Parameters    :
'* Revision History     :
'* Usage				: Give maximum wait time in config.properties
						Ex: DynamicWaitTime=120
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
**************************************************************************/

		public void DymamicWait() {
			try {
			   String getWaitTime;
			   getWaitTime = CONFIG.getProperty("DynamicWaitTime");
			   int maxWaitTime = Integer.parseInt(getWaitTime);
			   for (int j = 0; j < maxWaitTime; j++) {
				   String ajaxComplete = ((JavascriptExecutor)driver).executeScript("return jQuery.active == 0").toString();
				   System.out.println("ajaxComplete=" + ajaxComplete);
				   if (ajaxComplete.equalsIgnoreCase("true")) {
						break;
				   }
				   Thread.sleep(1000);
			   }
			   for (int j = 0; j < maxWaitTime; j++) {
				   String pageLoad = ((JavascriptExecutor)driver).executeScript("return document.readyState").toString();
				   System.out.println("pageLoad=" + pageLoad);
				   if (pageLoad.equalsIgnoreCase("complete")) {
					   break;
				   }
				   Thread.sleep(1000);
			   }
			   System.out.println("page is completely loaded");
			}
			catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}

/*************************************************************************.
# 106
**************************************************************************
'* Keyword Name         : LoginQA
'* Developed Date 		: 03-Feb-14
'* Author               : HCL
'* Purpose              : To login into accounts on QA site
'* Input Parameters     : data
'* Output Parameters    : Constants.KEYWORD_PASS
'* Revision History     :
'* Usage				: Login(object, data)
						object:=object is not required
						data  :=Data will be taken from the Excel sheet e.g:col|MPAccount;Pswd
'*************************************************************************
'* Modified	:
'* Reason	:
'* Date		:
**************************************************************************/

		public String LoginQA(String object, String data) {
			APP_LOGS.debug("Login to the QA site");
			try {
				String [] searchdata = data.split(";");
				driver.findElement(By.id("MpNumber")).clear();
				driver.findElement(By.id("MpNumber")).sendKeys(searchdata[0]);
				driver.findElement(By.id("Password")).clear();
				driver.findElement(By.id("Password")).sendKeys(searchdata[1]);
				driver.findElement(By.id("btnSignIn")).click();
				DymamicWait();
				driver.findElement(By.id("btn-continue")).click();
				DymamicWait();
				boolean isexists = driver.findElement(By.xpath(OR.getProperty("Webelement_HomePage_TileContainer"))).isDisplayed();
				if (isexists) {
					return Constants.KEYWORD_PASS + "<br>" + "Successfully logged into the account: " + searchdata[0] + "</br>";
				} else {
					return Constants.KEYWORD_FAIL + "<br>" + "Unable to navigate to Home page" + "</br>";
				}
			}
			catch (Exception e) {
				return Constants.KEYWORD_FAIL + "<br>" + "Unable to login into the account " + e.getMessage().substring(0, 40) + "</br>";
			}
		}

/*************************************************************************.
# 107
**********************************************************************
'* Keyword Name         : ChangeEnvironment
'* Developed Date 		: 10-Feb-14
'* Author               : HCL
'* Purpose              : To set the environment to CSSI database
'* Input Parameters     : Xpath of the object
'* Output Parameters    : Constants.KEYWORD_PASS
'* Revision History     :
'* Usage				: Login(object, data)
					object:=xpath of the object
					data  :=NULL
'*********************************************************************
'* Modified	:
'* Reason	:
'* Date		:
***********************************************************************/

	public String ChangeEnvironment(String object, String data) {
		APP_LOGS.debug("To set the database to CSSI environment");
		try {
			if (driver.findElement(By.xpath("//*[@id='oo_invitation_prompt']")).isDisplayed()) {
				driver.findElement(By.xpath("//*[@id='oo_no_thanks']")).click();
			}
			if (driver.findElement(By.xpath("//*[@id='DbEnvironment_Prod']")).isEnabled()) {
				driver.findElement(By.xpath("//*[@id='DbEnvironment_Prod']")).click();
			    driver.findElement(By.xpath("//*[@id='DbEnvironment_Prod']")).sendKeys(Keys.ARROW_UP);
			    return Constants.KEYWORD_PASS + "<br>" + "Successfully Changed environment to CSSI " + "</br>";
			} else {
				return Constants.KEYWORD_PASS + "<br>" + "Already environment is set to CSSI " + "</br>";
			}
		 }
		catch (Exception e) {
			return Constants.KEYWORD_FAIL + "<br>" + "Unable to change environment " + e.getMessage().substring(0, 40) + "</br>";
		}
	}

//*********************************************************************************
	public String SelectTripType(String object, String data)
	 {
		APP_LOGS.debug("To Select trip type");
		try
		 {			
				WebElement objectArea = driver.findElement(By.xpath(OR.getProperty(object)));
				List<WebElement> buttonText = objectArea.findElements(By.tagName("label"));				
				
				for (WebElement myElement : buttonText)
				{
					String link = myElement.getText(); 
					if (link !="")
					{
						if (link.equalsIgnoreCase(data))
						{
							myElement.click();											  
							return Constants.KEYWORD_PASS+"-- Selected trip type as: "+data;
						}
					}
					
				 }
				return Constants.KEYWORD_FAIL+"-- Unable to find specified object";
			}	
		
		catch (Exception e)
		{
	      	return Constants.KEYWORD_FAIL+"-- Unable to select specified object --"+e.getMessage().substring(0, 20);
	    }
	   
	 }

	
	
	
	public String SelectAward(String object, String data)
	 {
		APP_LOGS.debug("To Award as reservatin type");
		try
		 {			
				WebElement objectArea = driver.findElement(By.xpath(OR.getProperty(object)));
				List<WebElement> buttonText = objectArea.findElements(By.tagName("label"));				
				
				for (WebElement myElement : buttonText)
				{
					String link = myElement.getText(); 
					if (link !="")
					{
						if (link.equalsIgnoreCase(data))
						{
							myElement.click();											  
							return Constants.KEYWORD_PASS+"-- Selected reservation type as Award";
						}
					}
					
				 }
				return Constants.KEYWORD_FAIL+"-- Unable to find specified object";
			}	
		
		catch (Exception e)
		{
	      	return Constants.KEYWORD_FAIL+"-- Unable to select specified object --"+e.getMessage().substring(0, 20);
	    }
	   
	 }
	
	
	
	public String SelectButtons(String object, String data)
	 {
		APP_LOGS.debug("To click on buttons in given area");
		try
		 {		
				String[] objArrary = data.split(";");
				int arraySize = objArrary.length;
				String selectObject;
				int counter=0;
				for(int i=0; i<arraySize; i++)
				{
					selectObject = objArrary[i];
					WebElement objectArea = driver.findElement(By.xpath(OR.getProperty(object)));
					List<WebElement> buttonText = objectArea.findElements(By.tagName("label"));		
					
					for (WebElement myElement : buttonText)
					{
						String link = myElement.getText();
						if (link !="")
						{
							if (link.equalsIgnoreCase(selectObject))
							{
								myElement.click();
								counter = counter + 1;
							}
						}
						
					 }
				}
				
				if(counter == arraySize)
				return Constants.KEYWORD_PASS+"-- Sucessfully clicked on the specified buttons";
				else
				return Constants.KEYWORD_FAIL+"-- Unable to click on the specified buttons";
			}
		
		catch (Exception e)
		{
	      	return Constants.KEYWORD_FAIL+"-- Unable to select specified object --"+e.getMessage().substring(0, 20);
	    }
	   
	 }
	
	

	public String SelectListBoxes(String object, String data)
	 {
		APP_LOGS.debug("To select list boxes in given area");
		try
		 {		
				String[] objArrary = data.split(";");
				int arraySize = objArrary.length;
				String selectObject;
				int counter=0;
				for(int i=0; i<arraySize; i++)
				{
					selectObject = objArrary[i];
					WebElement objectArea = driver.findElement(By.xpath(OR.getProperty(object)));
					List<WebElement> buttonText = objectArea.findElements(By.tagName("option"));		
					
					for (WebElement myElement : buttonText)
					{
						String link = myElement.getText(); 
						if (link !="")
						{
							if (link.equalsIgnoreCase(selectObject))
							{
								myElement.click();
								counter = counter + 1;
							}
						}
						
					 }
				}
				
				if(counter == arraySize)
				return Constants.KEYWORD_PASS+"-- Sucessfully selected all the list boxes";
				else
				return Constants.KEYWORD_FAIL+"-- Unable to select specified list boxes";
			}	
		
		catch (Exception e)
		{
	      	return Constants.KEYWORD_FAIL+"-- Unable to select specified object --"+e.getMessage().substring(0, 30);
	    }
	   
	 }

	
	
	public String EnterText(String object, String data)
	 {
		APP_LOGS.debug("To enter text in edit boxes");
		try
		 {						
				String[] excelData = data.split("#");			
			    String[] objArrary = excelData[0].split(";");
				int arraySize = objArrary.length;				
				String[] inputData = excelData[1].split(":");
								
				String selectObject;
				int counter=0;
				for(int i=0; i<arraySize; i++)
				{
						selectObject = objArrary[i];
						WebElement objectArea = driver.findElement(By.xpath(OR.getProperty(object)));
						List<WebElement> EditBox = objectArea.findElements(By.tagName("input"));
						
						for (WebElement myElement : EditBox)
						{
							String link = myElement.getAttribute("id");
							if (link !="")
							{
								if (link.equalsIgnoreCase(selectObject))
								{
									myElement.sendKeys(inputData[i]);
									//Thread.sleep(5000);
									counter = counter + 1;
								}
							}
							
						 }
				}
				
				if(counter == arraySize)
				return Constants.KEYWORD_PASS+"-- Sucessfully entered text in all the edit boxes";
				else
				return Constants.KEYWORD_FAIL+"-- Unable to enter text in the edit boxes";
			}	
		
		catch (Exception e)
		{
	      	return Constants.KEYWORD_FAIL+"-- Unable to select specified objects --"+e.getMessage().substring(0, 30);
	    }
	   
	 }
	public String SelectCheckBoxes(String object, String data)
	 {
		APP_LOGS.debug("To select check boxes in given area");
		try
		 {		
				String[] objArrary = data.split(";");
				int arraySize = objArrary.length;
				String selectObject;
				int counter=0;
				for(int i=0; i<arraySize; i++)
				{
					selectObject = objArrary[i];
					WebElement objectArea = driver.findElement(By.xpath(OR.getProperty(object)));
					List<WebElement> buttonText = objectArea.findElements(By.tagName("label"));		
					
					for (WebElement myElement : buttonText)
					{
						String link = myElement.getText(); 
						if (link !="")
						{
							if (link.equalsIgnoreCase(selectObject))
							{
								myElement.click();
								counter = counter + 1;
							}
						}
						
					 }
				}
				
				if(counter == arraySize)
				return Constants.KEYWORD_PASS+"-- Sucessfully selected all the list boxes";
				else
				return Constants.KEYWORD_FAIL+"-- Unable to select specified list boxes";
			}	
		
		catch (Exception e)
		{
	      	return Constants.KEYWORD_FAIL+"-- Unable to select specified object --"+e.getMessage().substring(0, 30);
	    }
	   
	 }


	
	
	public String SelectRadioButtons(String object, String data)
	 {
		APP_LOGS.debug("To select radio buttons in given area");
		try
		 {		
				String[] objArrary = data.split(";");
				int arraySize = objArrary.length;
				String selectObject;
				int counter=0;
				for(int i=0; i<arraySize; i++)
				{
					selectObject = objArrary[i];
					WebElement objectArea = driver.findElement(By.xpath(OR.getProperty(object)));
					List<WebElement> buttonText = objectArea.findElements(By.tagName("label"));		
					
					for (WebElement myElement : buttonText)
					{
						String link = myElement.getText(); 
						if (link !="")
						{
							if (link.equalsIgnoreCase(selectObject))
							{
								myElement.click();
								counter = counter + 1;
							}
						}
						
					 }
				}
				
				if(counter == arraySize)
				return Constants.KEYWORD_PASS+"-- Sucessfully selected all the radio buttons";
				else
				return Constants.KEYWORD_FAIL+"-- Unable to select specified radio buttons";
			}	
		
		catch (Exception e)
		{
	      	return Constants.KEYWORD_FAIL+"-- Unable to select specified object --"+e.getMessage().substring(0, 30);
	    }
	   
	 }
	
//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

public String enterText(String object,String data) throws InvocationTargetException,InterruptedException {
	APP_LOGS.debug("Writing in text box");
	try
	{
		String locatorType=ObjectLocator.getLocatorType(object);
		if (waitUntilExists(object, locatorType)) 
		{
			WebElement element = null;
//			String locator = getElementLocator(objectLogicalName);
//			 ObjectLocator ObjectLocator = new ObjectLocator();
//			 element = ObjectLocator.findElement(locator,selenium);
			 GetInstance elmInstance = new GetInstance();
			 element=elmInstance.getInstanceObj(object, driver);
			 element.clear();
			 element.sendKeys(data);
			
		}else
			return Constants.KEYWORD_FAIL + "<br>" + object + " does not exist" + "</br>";
	}
    catch (Exception e) {
    	return Constants.KEYWORD_FAIL + "<br>" + "Unable to write in the Input box " + e.getMessage().substring(0, 40) + "</br>";
    }
    return Constants.KEYWORD_PASS + "<br>" + "Entered input " + data + " in " + object + "</br>";
}
public boolean findObject(String object) throws InvocationTargetException,InterruptedException
{
	//String locator = getElementLocator(objectLogicalName);
	    ObjectLocator objectLocator = new ObjectLocator();
	WebElement element = objectLocator.findElement(object,driver);
	  
	boolean isObjectFound = false;
	//int counter = 1;
	isObjectFound = element.isDisplayed();
	/*while ((element.isDisplayed() != true) && (counter < 15))
	{
		//Thread.sleep(ApplicationConstants.minTimeoutMS);
		@SuppressWarnings("unused")
		WebElement isObjectFound1 = element.findElement(By.name(objectLogicalName));
		
		counter++;
	}*/
	/*if (isObjectFound) 
	{
		//selenium.highlight(locator);
		ReportGenerator.writeLog("Object " + "\"" + objectLogicalName + "\"" + " Verification ", "Object " + "\"" + objectLogicalName + "\"" + " is found", "Pass");
	} 
	else 
	{
		//ReportGenerator.writeLog("Object " + "\"" + objectLogicalName + "\"" + " Verification ", "Object " + "\"" + objectLogicalName + "\"" + " not found.Please verify the object in the object repository.","Fail");
	}*/
	return isObjectFound;
}




}






