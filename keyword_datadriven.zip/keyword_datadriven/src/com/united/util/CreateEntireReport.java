package com.united.util;
//Reads the xlsx files and generates corresponding HTML reports

import java.io.*;
import java.util.Date;
import java.util.Properties;

import com.united.test.Constants;
import com.united.test.DriverScript;
import com.united.xls.read.Xls_Reader;

public class CreateEntireReport 
{
	Date d = new Date();
	public String result_FolderNamePath=System.getProperty("user.dir")+"\\Execution_Results\\";
	public static String result_FolderName=null;
	
	//Main method
	/**
	 * The main method.
	 *
	 * @param args the arguments
	 * @throws Exception the exception
	 */
	public static void main(String[] args) throws Exception
	{
		CreateEntireReport test = new CreateEntireReport();
		test.GenerateReport("Generate Test Result");
	}
	
	/**
	 * Generate report.
	 *
	 * @param arg the arg
	 * @throws Exception the exception
	 */
	public void GenerateReport(String arg) throws Exception 
	{
		int totalTestCount=0;
		int totalPassCount=0;
		int totalFailCount=0;
		int loopCount=0;
		int loopCount1=0;
		long totaltime=0;
		long individualtime=0;
		String inditime=null;
		String batchtotalTimenew=null;
		int rcnt=0;
		System.out.println("Generating Consolidated Report");
		Date d = new Date();
		String date=d.toString().replaceAll(" ", "_");
		date=date.replaceAll(":", "_");
		date=date.replaceAll("\\+", "_");
		System.out.println(date);
		result_FolderName=result_FolderNamePath+date.substring(0, 10)+"\\ENTIRE_TESTSUITE_REPORT"+"_"+date;
		
		new File(result_FolderName).mkdirs();
		FileInputStream fs = new FileInputStream(System.getProperty("user.dir")+"//src//com//united//config//config.properties");
		Properties CONFIG= new Properties();
		CONFIG.load(fs);
		
		try{
			String environment=CONFIG.getProperty("environment");
			String release=CONFIG.getProperty("release");
			String indexHtmlPath=result_FolderName+"\\Batch_Execution_Summary.html";
			new File(indexHtmlPath).createNewFile();
			Xls_Reader suiteXLS = new Xls_Reader(System.getProperty("user.dir")+"//src//com//united//xls//UnitedSuite.xlsx");
			
			int totalTestSuites=suiteXLS.getRowCount(Constants.TEST_SUITE_SHEET);
			  FileWriter fstream = new FileWriter(indexHtmlPath);
			  BufferedWriter out = new BufferedWriter(fstream);
			  StringBuffer mailout= new StringBuffer();
			  StringBuffer mailoutindex= new StringBuffer();
			  
			  StringBuffer moduleresult=new StringBuffer();
			  StringBuffer indexresult=new StringBuffer();
			  StringBuffer stepsresult=new StringBuffer();
			  
			  String imageone=System.getProperty("user.dir")+"\\src\\com\\united\\util\\CSClogo.png";
			  String imagetwo=System.getProperty("user.dir")+"\\src\\com\\united\\util\\UALOGO.gif";
			  moduleresult.append("<html><HEAD><script type='text/javascript'>function toggleIn(){var id = document.getElementById('Image1');id.style.display = 'block';}function toggleOut(){var id = document.getElementById('Image1');id.style.display = 'none';}</script><TITLE>Modules</TITLE></HEAD><body><h4 align=center><FONT COLOR=660066 FACE=AriaL SIZE=6><b><u>United.com Automation - Batch Execution Results</u></b></h4><image vspace=3 src="+imageone+" align=left></img><image vspace=3 src="+imagetwo+" align=right></img><br></br><table  border=1 cellspacing=1 cellpadding=1 ><tr><h4> <FONT COLOR=660000 FACE=Arial SIZE=4.5> <u>Test Details :</u></h4><td width=150 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run Date</b></td><td width=150 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>");
			  mailout.append("<html><HEAD><script type='text/javascript'>function toggleIn(){var id = document.getElementById('Image1');id.style.display = 'block';}function toggleOut(){var id = document.getElementById('Image1');id.style.display = 'none';}</script><TITLE>Modules</TITLE></HEAD><body><h4 align=center><FONT COLOR=660066 FACE=AriaL SIZE=6><b><u>United.com Automation - Batch Execution Results</u></b></h4><table  border=1 cellspacing=1 cellpadding=1 ><tr><h4> <FONT COLOR=660000 FACE=Arial SIZE=4.5> <u>Test Details :</u></h4></tr><tr><td width=150 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run Date</b></td><td width=150 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>");
			  moduleresult.append(d.toString());
			  mailout.append(d.toString());
			  moduleresult.append("</b></td></tr><tr><td width=150 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run Environment</b></td><td width=150 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>");
			  mailout.append("</b></td></tr><tr><td width=150 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run Environment</b></td><td width=150 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>");
			  moduleresult.append(environment);
			  mailout.append(environment);
			  moduleresult.append("</b></td></tr><tr><td width=150 align= left  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Release</b></td><td width=150 align= left ><FONT COLOR=#153E7E FACE= Arial  SIZE=2.75><b>");
			  mailout.append("</b></td></tr><tr><td width=150 align= left  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Release</b></td><td width=150 align= left ><FONT COLOR=#153E7E FACE= Arial  SIZE=2.75><b>");
			  moduleresult.append(release);
			  mailout.append(release);
			  
			  for(int currentSuiteNo=2;currentSuiteNo<= totalTestSuites;currentSuiteNo++)
			  {
				  String currentSuite = suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.SUITE_ID,currentSuiteNo);
				  Xls_Reader current_xls=new Xls_Reader(System.getProperty("user.dir")+"//src//com//united//xls//"+currentSuite+".xlsx");
				  rcnt=current_xls.getRowCount(Constants.TEST_CASES_SHEET);
				  for (int i=0;i<=rcnt;i++)
				  {
					  if(current_xls.getCellData(Constants.TEST_CASES_SHEET, Constants.RUNMODE, i).equalsIgnoreCase("Y"))
					  {
						  inditime=current_xls.getCellData(Constants.TEST_CASES_SHEET, Constants.ExecutionTime, i);
						  int timecount=(inditime.length())%11;
						  String batchtime[]=new String[timecount];
						  batchtime=inditime.split("<br></br>");
						  for(int cnt=0;cnt<batchtime.length;cnt++)
						  {
							  String newinditime=batchtime[cnt];
							  String time[]=new String[3];
							  time=newinditime.split(":");
							  int arrlen=time.length;
							  if(arrlen==3)
							  {
								  for (int j=0;j<=arrlen-1;j++)
								  {
									  individualtime=0;
									  if (j==0)
									  {
										  	individualtime=Integer.parseInt(time[j]);
									  		individualtime=individualtime*1000*60*60;
									  }
									  else if (j==1)
									  {
										  	individualtime=Integer.parseInt(time[j]);
									  		individualtime=individualtime*1000*60;
									  }
									  else if(j==2)
									  {
										  	individualtime=Integer.parseInt(time[j]);
									  		individualtime=individualtime*1000;
									  }
									  totaltime=totaltime+individualtime;
								  }
							  }
							  else if(arrlen==4)
							  {
								  for (int j=0;j<=arrlen-1;j++)
								  {
									  individualtime=0;
									  if (j==0)
									  {
										  	individualtime=Integer.parseInt(time[j]);
									  		individualtime=individualtime*1000*60*60*24;
									  }
									  else if (j==1)
									  {
										  	individualtime=Integer.parseInt(time[j]);
									  		individualtime=individualtime*1000*60*60;
									  }
									  else if(j==2)
									  {
										  	individualtime=Integer.parseInt(time[j]);
									  		individualtime=individualtime*1000*60;
									  }
									  else if(j==3)
									  {
										  	individualtime=Integer.parseInt(time[j]);
									  		individualtime=individualtime*1000;
									  }
									  totaltime=totaltime+individualtime;
								  }
							  }
						  }	  
					  }

					  //Capture Batch Execution Time
					  long batchsecond = (totaltime/1000) % 60;
					  long batchminute = (totaltime / (1000 * 60)) % 60;
					  long batchhour = (totaltime / (1000 * 60 * 60)) % 24;
					  long batchdays= ((totaltime / (1000 * 60 * 60 * 24)) % 7);
					  String bseconda=String.valueOf(batchsecond);
					  String bminutea=String.valueOf(batchminute);
					  String bhoura=String.valueOf(batchhour);
					  String batchdaysa=String.valueOf(batchdays);
							
					  if(bseconda.length()==1)
						bseconda="0"+bseconda;
					  if(bminutea.length()==1)
						bminutea="0"+bminutea;
					  if(bhoura.length()==1)
						bhoura="0"+bhoura;
					  if(batchdaysa.length()==1)
						batchdaysa="0"+batchdaysa;
					  batchtotalTimenew=batchdaysa+":"+bhoura+":"+bminutea+":"+bseconda;
				  }
			  }
			  rcnt=0;
			  totaltime=0;
			  moduleresult.append("</b></td></tr><tr><td width=150 align= left  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Execution Time [dd:hh:mm:ss]</b></td><td width=150 align= left ><FONT COLOR=#153E7E FACE= Arial  SIZE=2.75><b>");
			  mailout.append("</b></td></tr><tr><td width=150 align= left  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Execution Time [dd:hh:mm:ss]</b></td><td width=150 align= left ><FONT COLOR=#153E7E FACE= Arial  SIZE=2.75><b>");
			  moduleresult.append(batchtotalTimenew);
			  mailout.append(batchtotalTimenew);
			  batchtotalTimenew=null;
			  moduleresult.append("</b></td></tr></table><h4> <FONT COLOR=660000 FACE= Arial  SIZE=4.5> <u>Modules Report :</u></h4><table  border=1 cellspacing=1 cellpadding=1 width=100%><tr><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>SUITE NAME</b></td><td width=20% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>DESCRIPTION</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b># TESTS EXECUTED</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b># PASS</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b># FAIL</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>RESULT</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>EXECUTION TIME</b></td></tr>");
			  mailout.append("</b></td></tr></table><h4> <FONT COLOR=660000 FACE= Arial  SIZE=4.5> <u>Modules Report :</u></h4><table  border=1 cellspacing=1 cellpadding=1 width=100%><tr><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>SUITE NAME</b></td><td width=20% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>DESCRIPTION</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b># TESTS EXECUTED</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b># PASS</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b># FAIL</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>RESULT</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>EXECUTION TIME</b></td></tr>");
			  
			  String currentTestSuite=null;
			  Xls_Reader current_suite_xls=null;
			  int Failflag=0;
			  int Failflag2=0;
			  for(int currentSuiteID =2;currentSuiteID<= totalTestSuites;currentSuiteID++)
			  {
				  totalTestCount=0;
				  totalPassCount=0;
				  totalFailCount=0;
				  currentTestSuite=null;
				  current_suite_xls=null;
				  if (suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.RUNMODE, currentSuiteID).equals(Constants.RUNMODE_YES)){
				  currentTestSuite = suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.SUITE_ID,currentSuiteID);
				  current_suite_xls=new Xls_Reader(System.getProperty("user.dir")+"//src//com//united//xls//"+currentTestSuite+".xlsx");
				}
			
				  String currentTestName=null;
				  String currentTestRunmode=null;
				  String currentTestDescription=null;
				  String currentTestBrowser=null;
				  String currentTestExecutionTime=null;
				  batchtotalTimenew=null;
				  //###############################################################################################
				  // create index file for this suite
				  if (currentTestSuite!= null)
				  {
				    String moduleindex=currentTestSuite+"_Test_Results";

				    // add basic format to suite xls Test
					indexresult.append("<html><HEAD><script type='text/javascript'>function toggleIn(){var id = document.getElementById('Image1');id.style.display = 'block';}function toggleOut(){var id = document.getElementById('Image1');id.style.display = 'none';}</script><TITLE>"+currentTestSuite+" Test Results</TITLE></HEAD><body><br></br><h5 align=center><FONT COLOR=660066 FACE=AriaL SIZE=5 align=center><b><FONT COLOR=660066 FACE=AriaL SIZE=5><a id="+moduleindex+" href=Batch_Execution_Summary.html>"+currentTestSuite+" Test Results</a></b></h5>");
					mailoutindex.append("<html><HEAD><script type='text/javascript'>function toggleIn(){var id = document.getElementById('Image1');id.style.display = 'block';}function toggleOut(){var id = document.getElementById('Image1');id.style.display = 'none';}</script><TITLE>"+currentTestSuite+" Test Results</TITLE></HEAD><body><br></br><h5 align=center><FONT COLOR=660066 FACE=AriaL SIZE=5 align=center><b><FONT COLOR=660066 FACE=AriaL SIZE=5><u> "+currentTestSuite+" Test Results</u></b></h5>");
					  
					//Generate Module wise execution time	
					rcnt=current_suite_xls.getRowCount(Constants.TEST_CASES_SHEET);
					totaltime=0;
					for (int i=0;i<=rcnt;i++)
					{
					  if(current_suite_xls.getCellData(Constants.TEST_CASES_SHEET, Constants.RUNMODE, i).equalsIgnoreCase("Y"))
					  {
						  inditime=current_suite_xls.getCellData(Constants.TEST_CASES_SHEET, Constants.ExecutionTime, i);
						  int timecount=(inditime.length())%11;
						  String batchtime[]=new String[timecount];
						  batchtime=inditime.split("<br></br>");
						  for(int cnt=0;cnt<batchtime.length;cnt++)
						  {
							  String newinditime=batchtime[cnt];
							  String time[]=new String[3];
							  time=newinditime.split(":");
							  int arrlen=time.length;
							  if(arrlen==3)
							  {
								  for (int j=0;j<=arrlen-1;j++)
								  {
									  individualtime=0;
									  if (j==0)
									  {
										  	individualtime=Integer.parseInt(time[j]);
									  		individualtime=individualtime*1000*60*60;
									  }
									  else if (j==1)
									  {
										  	individualtime=Integer.parseInt(time[j]);
									  		individualtime=individualtime*1000*60;
									  }
									  else if(j==2)
									  {
										  	individualtime=Integer.parseInt(time[j]);
									  		individualtime=individualtime*1000;
									  }
									  totaltime=totaltime+individualtime;
								  }
							  }
							  else if(arrlen==4)
							  {
								  for (int j=0;j<=arrlen-1;j++)
								  {
									  individualtime=0;
									  if (j==0)
									  {
										  	individualtime=Integer.parseInt(time[j]);
									  		individualtime=individualtime*1000*60*60*24;
									  }
									  else if (j==1)
									  {
										  	individualtime=Integer.parseInt(time[j]);
									  		individualtime=individualtime*1000*60*60;
									  }
									  else if(j==2)
									  {
										  	individualtime=Integer.parseInt(time[j]);
									  		individualtime=individualtime*1000*60;
									  }
									  else if(j==3)
									  {
										  	individualtime=Integer.parseInt(time[j]);
									  		individualtime=individualtime*1000;
									  }
									  totaltime=totaltime+individualtime;
								  }
							  }
						  }
					  }

					  //Capture Batch Execution Time
					  long batchsecond = (totaltime/1000) % 60;
					  long batchminute = (totaltime / (1000 * 60)) % 60;
					  long batchhour = (totaltime / (1000 * 60 * 60)) % 24;
					  long batchdays= ((totaltime / (1000 * 60 * 60 * 24)) % 7);
					  String bseconda=String.valueOf(batchsecond);
					  String bminutea=String.valueOf(batchminute);
					  String bhoura=String.valueOf(batchhour);
					  String batchdaysa=String.valueOf(batchdays);
							
					  if(bseconda.length()==1)
						  bseconda="0"+bseconda;
						  if(bminutea.length()==1)
							bminutea="0"+bminutea;
						  if(bhoura.length()==1)
							bhoura="0"+bhoura;
						  if(batchdaysa.length()==1)
							batchdaysa="0"+batchdaysa;
								
					  batchtotalTimenew=batchdaysa+":"+bhoura+":"+bminutea+":"+bseconda;
				}
					  
					indexresult.append("<h4> <FONT COLOR=660000 FACE= Arial  SIZE=4> <u>Test cases Report :</u></h4><a id="+currentTestName+" href=Batch_Execution_Summary.html><b><FONT COLOR=#153E7E FACE= Arial  SIZE=1.5 align=left>GoTo Modules Report<b></a><br></br><table  border=1 cellspacing=1 cellpadding=1 width=100%><tr><td width=20% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>TEST NAME</b></td><td width=40% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>DESCRIPTION</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>ENVIRONMENT</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>EXECUTION TIME</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>RESULT</b></td></tr>");
					mailoutindex.append("<table  border=1 cellspacing=1 cellpadding=1 width=100%><tr><td width=20% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>TEST NAME</b></td><td width=40% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>DESCRIPTION</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>ENVIRONMENT</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>EXECUTION TIME</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>RESULT</b></td></tr>");
					//add basic format to Steps Header xls Test
										  
					//###################################################################################################
					for(int currentTestCaseID=2;currentTestCaseID<=current_suite_xls.getRowCount(Constants.TEST_CASES_SHEET);currentTestCaseID++)
					{  
						  if (currentTestCaseID==2)
						  {
							  stepsresult.append("<html><HEAD><script type='text/javascript'>function toggleIn(){var id = document.getElementById('Image1');id.style.display = 'block';}function toggleOut(){var id = document.getElementById('Image1');id.style.display = 'none';}</script><TITLE>"+currentTestSuite+" Test Results</TITLE></HEAD><body><br></br><h5 align=center><FONT COLOR=660066 FACE=AriaL SIZE=4 align=center><b><u> "+currentTestSuite+" Detailed Test Results</u></b></h5>"+"<table width=100% border=1 cellspacing=1 cellpadding=1 >");
					      }
					      else
					      {
					    	  stepsresult.append("<html><HEAD><script type='text/javascript'>function toggleIn(){var id = document.getElementById('Image1');id.style.display = 'block';}function toggleOut(){var id = document.getElementById('Image1');id.style.display = 'none';}</script><TITLE></TITLE></HEAD><body><table width=100% border=2 cellspacing=1 cellpadding=1>"); 
					      }
						  if(current_suite_xls.getCellData(Constants.TEST_CASES_SHEET, Constants.RUNMODE, currentTestCaseID).equals(Constants.RUNMODE_YES))
						  {
							  currentTestName = current_suite_xls.getCellData(Constants.TEST_CASES_SHEET, Constants.TCID, currentTestCaseID);
							  currentTestDescription = current_suite_xls.getCellData(Constants.TEST_CASES_SHEET, Constants.DESCRIPTION, currentTestCaseID);
							  currentTestBrowser=current_suite_xls.getCellData(Constants.TEST_CASES_SHEET, Constants.BrowserName, currentTestCaseID);
							  currentTestRunmode = current_suite_xls.getCellData(Constants.TEST_CASES_SHEET, Constants.RUNMODE, currentTestCaseID);
							  currentTestExecutionTime=current_suite_xls.getCellData(Constants.TEST_CASES_SHEET, Constants.ExecutionTime, currentTestCaseID);
							  System.out.println(currentTestSuite + " -- "+currentTestName );
							  // make the file corresponding to test Steps
							  int rows= current_suite_xls.getRowCount(Constants.TEST_STEPS_SHEET);
							  int cols = current_suite_xls.getColumnCount(Constants.TEST_STEPS_SHEET);
							  totalTestCount=totalTestCount+1;
						  
							  stepsresult.append("<tr><br></br>");
							  stepsresult.append("<a id="+currentTestName+" href=Batch_Execution_Summary.html><b><FONT COLOR=#153E7E FACE= Arial  SIZE=1.5 align=left>GoTo Modules Report<b></a><b><--------------------------------------------------------------------------------------------------------></b><a id=ModuleReport href=#"+moduleindex+"><b><FONT COLOR=#153E7E FACE= Arial  SIZE=1.5 align=right>GoTo Test cases Report<b></a></tr>");
							  stepsresult.append("<br></br><tr>");
							  
							  for(int colNum=0;colNum<8;colNum++)
							  {
								  String Colval=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, colNum, 1);
								  if ((!Colval.toString().equalsIgnoreCase("Keyword"))&& !Colval.toString().equalsIgnoreCase("Object")&& !Colval.toString().equalsIgnoreCase("Data")&&!Colval.toString().equalsIgnoreCase("Proceed_on_Fail"))
								  {
									  stepsresult.append("<td align= center bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
									  stepsresult.append(current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, colNum, 1));
								  }
							  }	//for(int colNum=0;colNum<cols;colNum++) closed
							  int itrno=0;
							  int newstep=6;
							  for(int step=8;step<cols;step++)
								{
									String Colval=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, step, 1);
									int Result_val=current_suite_xls.getCellRowNum(Constants.TEST_STEPS_SHEET, Constants.TCID, currentTestName);
									String iteration=null;
									
									if (Colval.toString().length()==(newstep))
									{
										iteration=Colval.toString().charAt(newstep)+"";
										itrno=Integer.parseInt(iteration);
									}
									else if(Colval.toString().length()>(newstep))
									{
										iteration=Colval.toString().charAt(newstep)+"";
										itrno=Integer.parseInt(iteration);
									}
									String cellvalue=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, ("Result"+itrno), Result_val);
									if((Colval.toString().indexOf("Result"+itrno)>=0) && !(cellvalue.equalsIgnoreCase("")))
									{
										stepsresult.append("<td align= Left bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
										stepsresult.append(current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, Colval.toString(), 1));
									}
								}
							  
							  // fill the whole sheet
							  boolean result_col=false;
							  boolean TC_Break=false;
						  
							  for(int rowNum=2;rowNum<=rows;rowNum++)
							  {
								  int flag=0;
								  itrno=0;
								  newstep=6;
								  if (current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, 0, rowNum).contains(currentTestName)){
									  stepsresult.append("<tr>");
									  for(int colNum=0;colNum<cols;colNum++)
									  {
										  String iteration=null;
										  	String Colval=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, colNum, 1);
										  	int Result_val=current_suite_xls.getCellRowNum(Constants.TEST_STEPS_SHEET, Constants.TCID, currentTestName);
										  	if(Colval.toString().indexOf("Result")>=0)
										  	{
											  	if (Colval.toString().length()==(newstep))
												{
													iteration=Colval.toString().charAt(newstep)+"";
													if(iteration!=null)
														itrno=Integer.parseInt(iteration);
												}
												
											  	else if(Colval.toString().length()>(newstep))
												{
													iteration=Colval.toString().charAt(newstep)+"";
													if(iteration!=null)
														itrno=Integer.parseInt(iteration);
												}
											  	
										  	}
										  	
										  String cellvalue=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, ("Result"+itrno), Result_val);
										  String data=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, colNum, rowNum); 							  
										  TC_Break=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET,0, rowNum).equalsIgnoreCase("END");
										  result_col=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, colNum, 1).startsWith(Constants.RESULT);
										  if (!((colNum>=4)) || !(cellvalue.equalsIgnoreCase("")) || (colNum>(7+itrno)))
										  {
								   
													  if( TC_Break)
													  {
														  if (flag==0)
														  {
															  flag=flag+1;
															  for (int k=0;k<=cols;k++)
															  {
																  data="#";
																  stepsresult.append("<td align=Left(Indent) bgcolor=GREY><FONT COLOR=#000000 FACE= Arial  SIZE=1>");}
														  	  }	   
													  		} 
											  				if((data.startsWith("Pass") || data.startsWith("PASS")) && result_col)
											  				{
											  					stepsresult.append("<td align=Left(Indent) bgcolor=#CCFFCC><FONT COLOR=#000000 FACE= Arial  SIZE=1>");
											  					loopCount=loopCount+1;
											  				}
											  				else  if((data.startsWith("Fail") || data.startsWith("FAIL")) && result_col)
											  				{
											  					loopCount=0;
											  					stepsresult.append("<td align=Left(Indent) bgcolor=#FFCCCC><FONT COLOR=#000000 FACE= Arial  SIZE=1>");
											  					loopCount1=loopCount1+1;
											  					Failflag=Failflag+1;
											  				}
											  				else if ((data.startsWith("Warning") || data.startsWith("WARNING"))) {
											  					stepsresult.append("<td align=Left bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=1>");
											  				}
											  				else if((data.startsWith("Skip") || data.startsWith("SKIP")) && result_col)
											  					stepsresult.append("<td align=Left(Indent) bgcolor=#FFFFC2><FONT COLOR=#000000 FACE= Arial  SIZE=1>");
											  				else if((data.startsWith("Step_") || data.startsWith("STEP_")))
											  					stepsresult.append("<td align=Left(Indent) bgcolor=white><FONT COLOR=#9400D3 FACE= Arial  SIZE=1>");
											  				else 
											  					stepsresult.append("<td align= Left(Indent) bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=1>");
											  				stepsresult.append(data);
										  				}
									  			}
								  }
								  stepsresult.append("</tr>");
							  }//for(int colNum=0;colNum<cols;colNum++) close
							  if (loopCount>0 && loopCount1==0)
							  {
								  totalPassCount=totalPassCount+1;
								  loopCount=0;
							  }
							  else if (loopCount1>0 )
							  {
								  totalFailCount=totalFailCount+1; 
								  loopCount1=0;
							  }
							  stepsresult.append("</tr>");
							  stepsresult.append("</table></body></html>");  
						  						
						//############################################################################################# 
						  String scriptname=currentTestName+"_index";
						  indexresult.append("<tr><td width=20% align= Left(Indent)><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b><a id="+moduleindex+" href=Batch_Execution_Summary.html></a>");
						  mailoutindex.append("<tr><td width=20% align= Left(Indent)><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
						  indexresult.append("<FONT COLOR=#ff349a FACE=Arial SIZE=2><a id="+scriptname+" href=#"+currentTestName+">"+currentTestName+"</a>");
						  mailoutindex.append(currentTestName+"<FONT COLOR=#ff349a FACE=Arial SIZE=2>");
						  indexresult.append("</b></td><td width=40% align= Left(Indent)><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
						  mailoutindex.append("</b></td><td width=40% align= Left(Indent)><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
						  indexresult.append(currentTestDescription);
						  mailoutindex.append(currentTestDescription);
						  indexresult.append("</b></td><td width=40% align= Left(Indent)><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
						  mailoutindex.append("</b></td><td width=40% align= Left(Indent)><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
						  indexresult.append(currentTestBrowser);
						  mailoutindex.append(currentTestBrowser);
						  indexresult.append("<td width=40% align= Left(Indent)><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
						  mailoutindex.append("<td width=40% align= Left(Indent)><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
						  indexresult.append(currentTestExecutionTime);
						  mailoutindex.append(currentTestExecutionTime);
						  indexresult.append("</b></td><td width=10% align=center  bgcolor=");
						  mailoutindex.append("</b></td><td width=10% align=center  bgcolor=");
							
						//###############################################################################################
						//copy the screenshots to entire report
							
						String dirPath=System.getProperty("user.dir")+"//screenshots";
						File f = new File(dirPath);
						File[] files  = f.listFiles();
						if(files != null)
						{
							for(int i=0; i < files.length; i++)
							{
								String Expected = dirPath+"//"+files[i].getName();
								String[] Actual= Expected.split("screenshots//");
								DriverScript.copyFile(dirPath+"//"+files[i].getName(),result_FolderName+"//"+Actual[1]);
							}
						}  
						
						if(currentTestRunmode.equalsIgnoreCase(Constants.RUNMODE_YES))
						{
							 String strtcstatus=current_suite_xls.getCellData(Constants.TEST_CASES_SHEET, Constants.ExecutionStatus,currentTestCaseID);
							 if(Failflag>0)
							 {
								 indexresult.append("red><FONT COLOR=#FFCCCC FACE=Arial SIZE=2><b>"+strtcstatus+"</b></td>");
								 mailoutindex.append("red><FONT COLOR=#FFCCCC FACE=Arial SIZE=2><b>"+strtcstatus+"</b></td>");
								 Failflag2=Failflag2+1;
							     Failflag=0;
							 }
							 else
							 {
								 indexresult.append("green><FONT COLOR=#CCFFCC FACE=Arial SIZE=2><b>"+strtcstatus+"</b></td>");
								 mailoutindex.append("green><FONT COLOR=#CCFFCC FACE=Arial SIZE=2><b>"+strtcstatus+"</b></td>");
							 }
						 }
						 else
						 {
							 indexresult.append("yellow><FONT COLOR=#D6D600 FACE=Arial SIZE=2><b>SKIP</b></td>");
							mailoutindex.append("yellow><FONT COLOR=#D6D600 FACE=Arial SIZE=2><b>SKIP</b></td>");
						 }//else close
					}
						  
				}// for(int rowNum=2;rowNum<=rows;rowNum++) Close
		  	//###########################################################################################################	 
			indexresult.append("</table></body></html>"); 
			mailoutindex.append("</table></body></html>");
			
			//##########################################################################################################
			moduleresult.append("<tr><td width=20% align= Left(Indent)><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
			mailout.append("<tr><td width=20% align= Left(Indent)><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
			moduleresult.append("<a id="+currentTestSuite+" href=#"+moduleindex+">"+currentTestSuite+"<FONT COLOR=#ff349a FACE=Arial SIZE=2>"+"</a>");
			mailout.append(currentTestSuite+"<FONT COLOR=#ff349a FACE=Arial SIZE=2>");
			moduleresult.append("</b></td><td width=20% align= Left(Indent)><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
			mailout.append("</b></td><td width=20% align= Left(Indent)><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
			moduleresult.append(suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.DESCRIPTION,currentSuiteID));
			mailout.append(suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.DESCRIPTION,currentSuiteID));
			moduleresult.append("</b></td><td width=10% align=center  bgcolor=Lavender><FONT COLOR=#153E7E FACE=Arial SIZE=2><b>"+totalTestCount);
			mailout.append("</b></td><td width=10% align=center  bgcolor=Lavender><FONT COLOR=#153E7E FACE=Arial SIZE=2><b>"+totalTestCount);
			moduleresult.append("</b></td><td width=10% align=center  bgcolor=green><FONT COLOR=#CCFFCC FACE=Arial SIZE=2><b>"+totalPassCount);
			mailout.append("</b></td><td width=10% align=center  bgcolor=green><FONT COLOR=#CCFFCC FACE=Arial SIZE=2><b>"+totalPassCount);
			moduleresult.append("</b></td><td width=10% align=center  bgcolor=red><FONT COLOR=#FFCCCC FACE=Arial SIZE=2><b>"+totalFailCount);
			mailout.append("</b></td><td width=10% align=center  bgcolor=red><FONT COLOR=#FFCCCC FACE=Arial SIZE=2><b>"+totalFailCount);
			moduleresult.append("</b></td><td width=10% align=center  bgcolor=");
			mailout.append("</b></td><td width=10% align=center  bgcolor=");
			if(suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.RUNMODE,currentSuiteID).equalsIgnoreCase(Constants.RUNMODE_YES))
			{	
				if(Failflag2>0)
				{
					moduleresult.append("red><FONT COLOR=#FFCCCC FACE=Arial SIZE=2><b>FAIL</b></td>");
				  	mailout.append("red><FONT COLOR=#FFCCCC FACE=Arial SIZE=2><b>FAIL</b></td>");
				  	Failflag2=0;
				}
				else
				{
					moduleresult.append("green><FONT COLOR=#CCFFCC FACE=Arial SIZE=2><b>PASS</b></td>");
					mailout.append("green><FONT COLOR=#CCFFCC FACE=Arial SIZE=2><b>PASS</b></td>");
				}
			}
			else
			{
				moduleresult.append("yellow><FONT COLOR=#D6D600 FACE=Arial SIZE=2><b>SKIP</b></td></tr>");
			  	mailout.append("yellow><FONT COLOR=#D6D600 FACE=Arial SIZE=2><b>SKIP</b></td>");
			}
			moduleresult.append("<td width=10% align= Center(Indent) bgcolor=white><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
			mailout.append("<td width=10% align= Center(Indent) bgcolor=white><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
			moduleresult.append(batchtotalTimenew);
			mailout.append(batchtotalTimenew);
			moduleresult.append("</b></td></tr>");
			mailout.append("</b></td></tr>");
		}
	}//}//first for loop close and //Close the output stream
	mailout.append("</table></body></html>");	
	indexresult.append(stepsresult);
	mailout.append(mailoutindex);
	moduleresult.append("</table>");
	moduleresult.append(indexresult);
	moduleresult.append("<br></br><h6 align=left><FONT COLOR=#0000FF FACE=Arial SIZE=1.5>� Copyright 2014 Computer Sciences Corporation. All rights reserved.</h6>");
	moduleresult.append("</body></html>");
	out.write(moduleresult.toString());
	out.close();
	Failflag=0;

	//To send Entire Execution report as email
	SendMail.execute(result_FolderName,CONFIG.getProperty("report_file_name"),mailout.toString());
	//SendMail.execute(result_FolderName,CONFIG.getProperty("report_file_name"));
			  
	}//Try Close
	catch (Exception e){//Catch exception if any
		System.err.println("Error: " + e.getMessage());
		e.printStackTrace();
		}//Catch looop
	}//Function close
}
