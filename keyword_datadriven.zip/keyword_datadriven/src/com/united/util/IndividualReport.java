package com.united.util;
//Reads the xlsx files and generates corresponding HTML reports

import java.io.*;
import java.util.Date;
import java.util.Properties;

import com.united.test.Constants;
import com.united.test.DriverScript;
import com.united.test.Keywords;
import com.united.xls.read.Xls_Reader;

public class IndividualReport 
{
	public String result_FolderNamePath=System.getProperty("user.dir")+"\\Execution_Results\\";
	public static String result_FolderName=null;
	String broVer=Keywords.var;
	org.openqa.selenium.Platform Plat=Keywords.platfrom;
	public static void main(String[] args) throws Exception	{
		IndividualReport Ind = new IndividualReport();
		Ind.GenerateIndividualReport("Generate individual Result");
	}
public void GenerateIndividualReport(String arg) throws Exception
  {
	//Read Test suite xlsx
	System.out.println("Generating Individual Report");
	Date d = new Date();
	String date=d.toString().replaceAll(" ", "_");
	date=date.replaceAll(":", "_");
	date=date.replaceAll("\\+", "_");
	System.out.println(date);
	Xls_Reader current_suite_xls=null;
	String imageone=System.getProperty("user.dir")+"\\src\\com\\united\\util\\CSClogo.png";
	String imagetwo=System.getProperty("user.dir")+"\\src\\com\\united\\util\\UALOGO.gif";
	
	try
	{
		Xls_Reader suiteXLS = new Xls_Reader(System.getProperty("user.dir")+"//src//com//united//xls//UnitedSuite.xlsx");
		int totalTestSuites=suiteXLS.getRowCount(Constants.TEST_SUITE_SHEET);
		for(int currentSuiteID =2;currentSuiteID<= totalTestSuites;currentSuiteID++)//need to close
		{
			current_suite_xls=null;
			if (suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.RUNMODE, currentSuiteID).equals(Constants.RUNMODE_YES))
			{//need to close
				String currentTestSuite = suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.SUITE_ID,currentSuiteID);
				current_suite_xls=new Xls_Reader(System.getProperty("user.dir")+"//src//com//united//xls//"+currentTestSuite+".xlsx");
				for(int currentTestScriptID=2;currentTestScriptID<=current_suite_xls.getRowCount(Constants.TEST_CASES_SHEET);currentTestScriptID++)
				{//need to close
					if(current_suite_xls.getCellData(Constants.TEST_CASES_SHEET, Constants.RUNMODE, currentTestScriptID).equals(Constants.RUNMODE_YES))
					{
						String  CurrentScript= current_suite_xls.getCellData(Constants.TEST_CASES_SHEET, Constants.TCID, currentTestScriptID);
						result_FolderName=result_FolderNamePath+date.substring(0, 10)+"//"+CurrentScript+"_Reports"+"_"+date;
			
						new File(result_FolderName).mkdirs();
						new File(result_FolderName).mkdirs();
						
						String dirPath=System.getProperty("user.dir")+"//screenshots";
						File f = new File(dirPath);
						File[] files  = f.listFiles();
						if(files != null)
						{
							for(int i=0; i < files.length; i++)
							{
								String actualfilename=files[i].getName();
								if(actualfilename.indexOf(currentTestSuite+"_"+CurrentScript+"_TS")>=0)
								{
									String Expected = dirPath+"//"+files[i].getName();
									String[] Actual= Expected.split("screenshots//");
									DriverScript.copyFile(dirPath+"//"+files[i].getName(),result_FolderName+"//"+Actual[1]);
								}
							}
						}
			
						//Creation of FileInputStream object to Fetch required values from config.properties
						FileInputStream fs = new FileInputStream(System.getProperty("user.dir")+"//src//com//united//config//config.properties");
						Properties CONFIG= new Properties();
						CONFIG.load(fs);
						String environment=CONFIG.getProperty("environment");
						String release=CONFIG.getProperty("release");

						StringBuffer mailout= new StringBuffer();
						StringBuffer mailoutsteps= new StringBuffer();
											  
						totalTestSuites=suiteXLS.getRowCount(Constants.TEST_SUITE_SHEET);

						String suite_result="";
						int Failflag=0;
						int Failflag2=0;

						suite_result="";
						current_suite_xls=new Xls_Reader(System.getProperty("user.dir")+"//src//com//united//xls//"+currentTestSuite+".xlsx");

						String currentTestDescription=null;
						String currentTestBrowser=null;
													
						//###############################################################################################
						//To create index file for current Test Suite
						String suiteIndexFile=result_FolderName+"\\"+CurrentScript+"_Status.html";
						new File(suiteIndexFile).createNewFile();
						//To add basic format to HTML that would be generated from current Test Suite
						FileWriter fstream_suite_index= new FileWriter(suiteIndexFile);
						BufferedWriter out_suite_index= new BufferedWriter(fstream_suite_index);
						mailout.append("<html><HEAD><script type='text/javascript'>function toggleIn(){var id = document.getElementById('Image1');id.style.display = 'block';}function toggleOut(){var id = document.getElementById('Image1');id.style.display = 'none';}</script><TITLE>"+CurrentScript+" Test Result</TITLE></HEAD><body><h4 align=center><FONT COLOR=660066 FACE=AriaL SIZE=6><b><u> "+CurrentScript+" Test Result</u></b></h4><image vspace=3 src="+imageone+" align=left></img><image vspace=3 src="+imagetwo+" align=right></img><br></br><table  border=1 cellspacing=1 cellpadding=1 ><tr><h4> <FONT COLOR=660000 FACE=Arial SIZE=4.5> <u>Test Details :</u></h4></tr><tr><td width=150 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run Date</b></td><td width=150 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>");
						mailout.append(d.toString());
						mailout.append("</b></td></tr><tr><td width=150 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run Environment</b></td><td width=150 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>");
						mailout.append(environment);
						mailout.append("</b></td></tr><tr><td width=150 align= left  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Release</b></td><td width=150 align= left ><FONT COLOR=#153E7E FACE= Arial  SIZE=2.75><b>");
						mailout.append(release);
						mailout.append("</b></td></tr><tr><td width=150 align= left  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Execution Time [dd:hh:mm:ss]</b></td><td width=150 align= left ><FONT COLOR=#153E7E FACE= Arial  SIZE=2.75><b>");
						String totalTimenew=current_suite_xls.getCellData(Constants.TEST_CASES_SHEET, Constants.ExecutionTime, currentTestScriptID);
						mailout.append(totalTimenew);
						mailout.append("</b></td></tr></table><h4> <FONT COLOR=660000 FACE= Arial  SIZE=4.5> <u>Test Report :</u></h4><table  border=1 cellspacing=1 cellpadding=1 width=100%><tr><td width=20% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>TEST NAME</b></td><td width=40% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>DESCRIPTION</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Executed Browsers List</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>RESULT</b></td></tr>");
						//###################################################################################################
						//for(int currentTestCaseID=2;currentTestCaseID<=current_suite_xls.getRowCount(Constants.TEST_CASES_SHEET);currentTestCaseID++)
						//{
							System.out.println(currentTestSuite + " -- "+CurrentScript );
						  
							int rows= current_suite_xls.getRowCount(Constants.TEST_STEPS_SHEET);
							int cols = current_suite_xls.getColumnCount(Constants.TEST_STEPS_SHEET);
							mailoutsteps.append("<html><HEAD><script type='text/javascript'>function toggleIn(){var id = document.getElementById('Image1');id.style.display = 'block';}function toggleOut(){var id = document.getElementById('Image1');id.style.display = 'none';}</script><TITLE>"+CurrentScript+" Detailed Test Results</TITLE></HEAD><body><h6 align=center><FONT COLOR=660066 FACE=AriaL SIZE=5><b><u> "+CurrentScript+" Detailed Test Results</u></b></h6><table width=100% border=1 cellspacing=1 cellpadding=1 >");
							mailoutsteps.append("<tr>");
							for(int colNum=0;colNum<8;colNum++)
							{
								String Colval=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, colNum, 1);
								if ((!Colval.toString().equalsIgnoreCase("Keyword"))&& !Colval.toString().equalsIgnoreCase("Object")&& !Colval.toString().equalsIgnoreCase("Data")&&!Colval.toString().equalsIgnoreCase("Proceed_on_Fail")){
									mailoutsteps.append("<td align= Left bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
									mailoutsteps.append(current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, colNum, 1));
								}
							}
							
							int itrno=0;
							  int newstep=6;
							  for(int step=8;step<cols;step++)
								{
									String Colval=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, step, 1);
									int Result_val=current_suite_xls.getCellRowNum(Constants.TEST_STEPS_SHEET, Constants.TCID, CurrentScript);
									String iteration=null;
									
									if (Colval.toString().length()==(newstep))
									{
										iteration=Colval.toString().charAt(newstep)+"";
										itrno=Integer.parseInt(iteration);
									}
									else if(Colval.toString().length()>(newstep))
									{
										iteration=Colval.toString().charAt(newstep)+"";
										itrno=Integer.parseInt(iteration);
									}
									String cellvalue=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, ("Result"+itrno), Result_val);
									if((Colval.toString().indexOf("Result"+itrno)>=0) && !(cellvalue.equalsIgnoreCase("")))
									{
										mailoutsteps.append("<td align= Left bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
										mailoutsteps.append(current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, Colval.toString(), 1));
									}
								}
							mailoutsteps.append("</b></tr>");
				
							//To fill the whole sheet
							boolean result_col=false;
							boolean TC_Break=false;
							for(int rowNum=2;rowNum<=rows;rowNum++)
							{
								int flag=0;
								itrno=0;
								newstep=6;
								if  (current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, 0, rowNum).contains(CurrentScript))
								{
									currentTestDescription = current_suite_xls.getCellData(Constants.TEST_CASES_SHEET, Constants.DESCRIPTION, currentTestScriptID);
									String Value = Plat.toString();
									if (Value.equals("XP"))
									{
										Value="WINDOWS";
									}
									currentTestBrowser=current_suite_xls.getCellData(Constants.TEST_CASES_SHEET, Constants.BrowserName, currentTestScriptID);
									mailoutsteps.append("<tr>");
									for(int colNum=0;colNum<cols;colNum++)
									{
										String iteration=null;
									  	String Colval=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, colNum, 1);
									  	//int Result_val=current_suite_xls.getCellRowNum(Constants.TEST_STEPS_SHEET, Constants.TCID, CurrentScript);
									  	if(Colval.toString().indexOf("Result")>=0)
									  	{
										  	if (Colval.toString().length()==(newstep))
											{
												iteration=Colval.toString().charAt(newstep)+"";
												if(iteration!=null)
													itrno=Integer.parseInt(iteration);
											}
											
										  	else if(Colval.toString().length()>(newstep))
											{
												iteration=Colval.toString().charAt(newstep)+"";
												if(iteration!=null)
													itrno=Integer.parseInt(iteration);
											}
										  	
									  	}
									  	//String cellvalue=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, ("Result"+itrno), Result_val);
										String data=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, colNum, rowNum); 							  
										TC_Break=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET,0, rowNum).equalsIgnoreCase("END");
										result_col=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, colNum, 1).startsWith((Constants.RESULT)); 
										if (!((colNum>=4) && (colNum<=7)) || (colNum>(7+itrno)))
										{
											//To break the test cases with different color
											if( TC_Break)
											{
												if (flag==0)
												{
													//for (int k=0;k<=cols;k++)
													//{
														data="#";
														mailoutsteps.append("<td align=center bgcolor=GREY><FONT COLOR=#000000 FACE= Arial  SIZE=1>");
														break;
													//}
												}
											} 
											if((data.startsWith("Pass") || data.startsWith("PASS")) && result_col)
											{
												mailoutsteps.append("<td align=Left bgcolor=#CCFFCC><FONT COLOR=#000000 FACE= Arial  SIZE=1>");
											}
											else if((data.startsWith("Fail") || data.startsWith("FAIL")) && result_col)
											{
												mailoutsteps.append("<td align=Left bgcolor=#FFCCCC><FONT COLOR=#000000 FACE= Arial  SIZE=1>");
												if(suite_result.equals(""))
												{
													suite_result="FAIL";
													Failflag=Failflag+1;
												}
											}
											else if ((data.startsWith("Warning") || data.startsWith("WARNING"))) {
												mailoutsteps.append("<td align=Left bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=1>");
											}
											else if((data.startsWith("Skip") || data.startsWith("SKIP")) && result_col)
											{
												mailoutsteps.append("<td align=Left bgcolor=#FFFFC2><FONT COLOR=#000000 FACE= Arial  SIZE=1>");
											}
											else if((data.startsWith("Step_") || data.startsWith("STEP_")))
											{
												mailoutsteps.append("<td align=Left bgcolor=white><FONT COLOR=#9400D3 FACE= Arial  SIZE=1>");
											}
											else
											{
												mailoutsteps.append("<td align= Left bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=1>");
											}
											
											mailoutsteps.append(data);
											data=null;
										}
									}
									mailoutsteps.append("</tr>");
								}
							}
							
							//############################################################################################# 
							mailout.append("<tr><td width=20% align= Left(Indent)><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
							mailout.append(CurrentScript+"<FONT COLOR=#ff349a FACE=Arial SIZE=2>");
							mailout.append("</b></td><td width=40% align= Left(Indent)><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
							mailout.append(currentTestDescription);
							mailout.append("</b></td><td width=40% align= Left(Indent)><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
							mailout.append(currentTestBrowser);
							mailout.append("</b></td><td width=10% align=center  bgcolor=");
					 		//###############################################################################################
							if(current_suite_xls.getCellData(Constants.TEST_CASES_SHEET, Constants.RUNMODE,currentTestScriptID).equalsIgnoreCase(Constants.RUNMODE_YES))
							{
								if(Failflag>0)
								{
									Failflag2=Failflag2+1;
									suite_result="FAIL";
									mailout.append("red><FONT COLOR=#FFCCCC FACE=Arial SIZE=2><b>FAIL</b></td></tr>");
								}
								else
								{
									suite_result="PASS";
									mailout.append("green><FONT COLOR=#CCFFCC FACE=Arial SIZE=2><b>PASS</b></td></tr>");
								}
							}
							else
							{
								suite_result="SKIP";
								mailout.append("yellow><FONT COLOR=#FF9900 FACE=Arial SIZE=2><b>SKIP</b></td></tr>");
							}
							
							String excelresulttemp=current_suite_xls.getCellData(Constants.TEST_CASES_SHEET, Constants.ExecutionStatus, currentTestScriptID);
							String outputresulttemp=null;
							
							if(suite_result.indexOf("FAIL")>=0)
							{
								outputresulttemp="FAIL";
							}
							else if(suite_result.indexOf("PASS")>=0)
							{
								outputresulttemp="PASS";
							}
							else
							{
								outputresulttemp="SKIP";
							}
							
							if(excelresulttemp.indexOf(outputresulttemp)>=0)
							{
								excelresulttemp=excelresulttemp+"<br></br>"+outputresulttemp;
								current_suite_xls.setCellData(Constants.TEST_CASES_SHEET, Constants.ExecutionStatus, currentTestScriptID, excelresulttemp);              	
							}
							else
							{
								if(outputresulttemp.indexOf("FAIL")>=0)
								{
									current_suite_xls.setCellData(Constants.TEST_CASES_SHEET, Constants.ExecutionStatus, currentTestScriptID, "FAIL");
								}
								else if(outputresulttemp.indexOf("PASS")>=0)
								{
									current_suite_xls.setCellData(Constants.TEST_CASES_SHEET, Constants.ExecutionStatus, currentTestScriptID, "PASS");
								}
								else
									current_suite_xls.setCellData(Constants.TEST_CASES_SHEET, Constants.ExecutionStatus, currentTestScriptID, outputresulttemp);
							}
							
							//###########################################################################################################
							mailoutsteps.append("</table></body></html>");
							//break;
						//}
						mailout.append("</table></body></html>");
						mailoutsteps.append("<html><head><script type='text/javascript'>function toggleIn(){var id = document.getElementById('Image1');id.style.display = 'block';}function toggleOut(){var id = document.getElementById('Image1');id.style.display = 'none';}</script></head><body><br></br><h6 align=left><FONT COLOR=#0000FF FACE=Arial SIZE=1.5>� Copyright 2014 Computer Sciences Corporation. All rights reserved.</h6></body></html>");
						mailout.append(mailoutsteps);
						out_suite_index.write(mailout.toString());
						out_suite_index.close();	
						//##########################################################################################################
						String Filepath=result_FolderNamePath+date.substring(0, 10)+"//"+CurrentScript+"_Reports"+"_"+date;
						String reportFileName=Filepath+"Test_Reports.zip";
						Zip.zip(Filepath,reportFileName);
						
						Failflag=0;
						suite_result=null;
					}
				}
			}
		}
	}
	catch (Exception e)	//Catch exception if any
	{
		System.err.println("Error: " + e.getMessage());
		e.printStackTrace();
	}
	
  }
}