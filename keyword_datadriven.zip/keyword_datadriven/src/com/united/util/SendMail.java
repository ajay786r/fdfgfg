package com.united.util;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
//import javax.mail.*;

//import javax.mail.internet.*;
import java.io.FileInputStream;
import java.util.*;

/**
 * The Class SendMail.
 */
public class SendMail {

	/**
	 * Execute.
	 *
	 * @param Filepath the filepath
	 * @param reportFileName the report file name
	 * @param MailBody the mail body
	 * @throws Exception the exception
	 */
	public static void execute(String Filepath, String reportFileName, String MailBody) throws Exception {
		String path = Filepath;
		FileInputStream fs = new FileInputStream(System.getProperty("user.dir") + "//src//com//united//config//config.properties");
		Properties CONFIG = new Properties();
		CONFIG.load(fs);

		Zip.zip(Filepath, Filepath + reportFileName);
		Date d = new Date();
		String date = d.toString().replaceAll(" ", "_");
		date = date.replaceAll(":", "_");
		date = date.replaceAll("\\+", "_");

		String[] to = {CONFIG.getProperty("mailTo")};
		String[] cc = {CONFIG.getProperty("mailCC")};
		String[] bcc = {CONFIG.getProperty("mailBCC")};
		String message = MailBody;

		// This is for google
		SendMail.sendMail(CONFIG.getProperty("mailuserName"), CONFIG.getProperty("mailPWD"), "smtp.gmail.com", "465", "true", "true", true, "javax.net.ssl.SSLSocketFactory",
				"false", to, cc, bcc, CONFIG.getProperty("mailSubject"), message, path + reportFileName, "Digital2.0_AutomationEmailReports_" + date + ".zip");
	}

	/**
	 * Send mail.
	 *
	 * @param userName the user name
	 * @param passWord the pass word
	 * @param host the host
	 * @param port the port
	 * @param starttls the starttls
	 * @param auth the auth
	 * @param debug the debug
	 * @param socketFactoryClass the socket factory class
	 * @param fallback the fallback
	 * @param to the to
	 * @param cc the cc
	 * @param bcc the bcc
	 * @param subject the subject
	 * @param text the text
	 * @param attachmentPath the attachment path
	 * @param attachmentName the attachment name
	 * @return true, if successful
	 */
	public static boolean sendMail(String userName, String passWord, String host, String port, String starttls, String auth, boolean debug, String socketFactoryClass,
			String fallback, String[] to, String[] cc, String[] bcc, String subject, String text, String attachmentPath, String attachmentName) {
				return debug;

	/*	// Get system properties
		Properties properties = System.getProperties();

		properties.put("mail.smtp.user", userName);
		// properties.put("mail.smtp.password", passWord);

		// Setup mail server
		properties.put("mail.smtp.host", host);

		if (!"".equals(port))

			properties.put("mail.smtp.port", port);

		if (!"".equals(starttls))

			properties.put("mail.smtp.starttls.enable", starttls);

		properties.put("mail.smtp.auth", auth);

		if (!"".equals(port))

			properties.put("mail.smtp.socketFactory.port", port);

		if (!"".equals(socketFactoryClass))

			properties.put("mail.smtp.socketFactory.class", socketFactoryClass);

		if (!"".equals(fallback))

			properties.put("mail.smtp.socketFactory.fallback", fallback);

		// Get the default Session object.
		Session session = Session.getDefaultInstance(properties, null);

		try {
			// Create a default MimeMessage object.
			MimeMessage message = new MimeMessage(session);

			message.setFrom(new InternetAddress("bvinay57@gmail.com"));

			for (int i = 0; i < to.length; i++) {

				message.addRecipient(Message.RecipientType.TO, new InternetAddress(to[i]));

			}

			for (int i = 0; i < cc.length; i++) {

				message.addRecipient(Message.RecipientType.CC, new InternetAddress(cc[i]));

			}

			for (int i = 0; i < bcc.length; i++) {

				message.addRecipient(Message.RecipientType.BCC, new InternetAddress(bcc[i]));

			}

			// Set Subject: header field
			message.setSubject("UnitedDotCom Automation(Selenium) Test Reports");

			// Create the message part
			BodyPart messageBodyPart = new MimeBodyPart();

			// Fill the message
			messageBodyPart.setText("***AUTO GENERATED EMAIL - PLEASE DO NOT RESPOND***\n\nPlease find the attached automation execution reports."
					+ "\n\nRegards\nDigital 2.0 - DotCom Automation Team.\n\n");

			// Creates html message
			BodyPart bodyHtml = new MimeBodyPart();
			bodyHtml.setContent(text, "text/html");

			// Create a multipart message
			Multipart multipart = new MimeMultipart();

			// Set text message part
			multipart.addBodyPart(messageBodyPart);
			multipart.addBodyPart(bodyHtml);

			// Part two is attachment
			messageBodyPart = new MimeBodyPart();
			DataSource source = new FileDataSource(attachmentPath);
			messageBodyPart.setDataHandler(new DataHandler(source));
			messageBodyPart.setFileName(attachmentName);
			multipart.addBodyPart(messageBodyPart);

			// Send the complete message parts
			message.setContent(multipart);

			message.saveChanges();

			Transport transport = session.getTransport("smtp");

			transport.connect(host, userName, passWord);

			transport.sendMessage(message, message.getAllRecipients());

			transport.close();

			// return true;
			System.out.println("Sent Test Results Email Alert successfully with attachment!");

			return true;
		}

		catch (Exception mex) {
			mex.printStackTrace();
			return false;
		}
*/
	}
}
